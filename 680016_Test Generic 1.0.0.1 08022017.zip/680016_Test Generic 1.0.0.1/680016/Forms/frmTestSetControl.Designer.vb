﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmTestSetControl
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmTestSetControl))
        Me.dlgBqEVSW = New System.Windows.Forms.OpenFileDialog()
        Me.SendI2CUnsealCodesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.LocateBqEVSWExecutableFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.I2COperationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SmbShutdownToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendSMBUnsealToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FuelGaugeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenBqEVSWToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SMBusOperationsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowBq76940ControlScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CommunicationTraceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EV2300CommToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DAQCommToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PowerSupply1ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PowerSupply2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElectronicLoadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.I2C5VControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VEnableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VDisableToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.mnuScanAllItems = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenConfigDialog = New System.Windows.Forms.OpenFileDialog()
        Me.SaveCSVFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.SaveXMLFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ctxMonitor = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuScanAllItemsContext = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSetRefreshIntervalTop = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtRefreshInterval = New System.Windows.Forms.ToolStripTextBox()
        Me.ctzMeterGrid = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.mnuResetDaqGrid = New System.Windows.Forms.ToolStripMenuItem()
        Me.SelectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UnselectAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveUncheckedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DeleteSelectedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToClipboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.txtMessaqeLog = New System.Windows.Forms.RichTextBox()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenConfigurationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.TestingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnSendDaqConfig = New System.Windows.Forms.Button()
        Me.btnResetDAQ = New System.Windows.Forms.Button()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tpgTesting = New System.Windows.Forms.TabPage()
        Me.tpgEnvironment = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.dgvEnvPallet1 = New System.Windows.Forms.DataGridView()
        Me.tpgMonitor = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanelEquipmentControl = New System.Windows.Forms.TableLayoutPanel()
        Me.gbxELoadPack = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel16 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox30 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel17 = New System.Windows.Forms.TableLayoutPanel()
        Me.radELPackModeCC = New System.Windows.Forms.RadioButton()
        Me.radELPackModeCV = New System.Windows.Forms.RadioButton()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.radELPackModeCP = New System.Windows.Forms.RadioButton()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.radELPackModeCR = New System.Windows.Forms.RadioButton()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.udELPackCRohms = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.udELPackCCamps = New System.Windows.Forms.NumericUpDown()
        Me.udELPackCVvolts = New System.Windows.Forms.NumericUpDown()
        Me.udELPackCPwatts = New System.Windows.Forms.NumericUpDown()
        Me.TableLayoutPanel18 = New System.Windows.Forms.TableLayoutPanel()
        Me.chkELPackShort = New System.Windows.Forms.CheckBox()
        Me.btnELPackEnabled = New System.Windows.Forms.Button()
        Me.TableLayoutPanel19 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox31 = New System.Windows.Forms.GroupBox()
        Me.txtELPackRin = New System.Windows.Forms.TextBox()
        Me.GroupBox32 = New System.Windows.Forms.GroupBox()
        Me.txtELPackPin = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.txtELPackVin = New System.Windows.Forms.TextBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.txtELPackIin = New System.Windows.Forms.TextBox()
        Me.gbxELoadCell = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel11 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel12 = New System.Windows.Forms.TableLayoutPanel()
        Me.radELCellModeCC = New System.Windows.Forms.RadioButton()
        Me.radELCellModeCV = New System.Windows.Forms.RadioButton()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.radELCellModeCP = New System.Windows.Forms.RadioButton()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.radELCellModeCR = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.udELCellCRohms = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.udELCellCCamps = New System.Windows.Forms.NumericUpDown()
        Me.udELCellCVvolts = New System.Windows.Forms.NumericUpDown()
        Me.udELCellCPwatts = New System.Windows.Forms.NumericUpDown()
        Me.TableLayoutPanel13 = New System.Windows.Forms.TableLayoutPanel()
        Me.chkELCellShort = New System.Windows.Forms.CheckBox()
        Me.btnELCellEnabled = New System.Windows.Forms.Button()
        Me.TableLayoutPanel15 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox25 = New System.Windows.Forms.GroupBox()
        Me.txtELCellRin = New System.Windows.Forms.TextBox()
        Me.GroupBox24 = New System.Windows.Forms.GroupBox()
        Me.txtELCellPin = New System.Windows.Forms.TextBox()
        Me.GroupBox23 = New System.Windows.Forms.GroupBox()
        Me.txtELCellVin = New System.Windows.Forms.TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.txtELCellIin = New System.Windows.Forms.TextBox()
        Me.gbxPowerSupplyPack = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox21 = New System.Windows.Forms.GroupBox()
        Me.txtPSPackVout = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.txtPSPackIout = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel14 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.udPSPackOCP = New System.Windows.Forms.NumericUpDown()
        Me.udPSPackIlimit = New System.Windows.Forms.NumericUpDown()
        Me.udPSPackVLimit = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.udPSPackOVP = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.btnPSPackEnabled = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.gbxPowerSupplyAux = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel20 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.txtPsAuxVout = New System.Windows.Forms.TextBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.txtPsAuxIout = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel21 = New System.Windows.Forms.TableLayoutPanel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.udPSAuxOCP = New System.Windows.Forms.NumericUpDown()
        Me.udPSAuxIlimit = New System.Windows.Forms.NumericUpDown()
        Me.udPSAuxVLimit = New System.Windows.Forms.NumericUpDown()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.udPSAuxOVP = New System.Windows.Forms.NumericUpDown()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.btnPsAuxEnabled = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.gbxPowerSupplyCell = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.udPSCellOCP = New System.Windows.Forms.NumericUpDown()
        Me.udPSCellILimit = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.udPSCellVlimit = New System.Windows.Forms.NumericUpDown()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.btnPSCellEnabled = New System.Windows.Forms.Button()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.udPSCellOVP = New System.Windows.Forms.NumericUpDown()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtPSCellVout = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtPSCellIout = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.dgvDaq200a = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.dgvDaq200b = New System.Windows.Forms.DataGridView()
        Me.DataGridViewComboBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.State = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.tlpRelayIndi = New System.Windows.Forms.TableLayoutPanel()
        Me.btnRelayBit18 = New System.Windows.Forms.Button()
        Me.btnRelayBit17 = New System.Windows.Forms.Button()
        Me.btnRelayBit16 = New System.Windows.Forms.Button()
        Me.btnRelayBit8 = New System.Windows.Forms.Button()
        Me.btnRelayBit7 = New System.Windows.Forms.Button()
        Me.btnRelayBit9 = New System.Windows.Forms.Button()
        Me.btnRelayBit4 = New System.Windows.Forms.Button()
        Me.btnRelayBit10 = New System.Windows.Forms.Button()
        Me.btnRelayBit6 = New System.Windows.Forms.Button()
        Me.btnRelayBit11 = New System.Windows.Forms.Button()
        Me.btnRelayBit19 = New System.Windows.Forms.Button()
        Me.btnRelayBit14 = New System.Windows.Forms.Button()
        Me.btnRelayBit12 = New System.Windows.Forms.Button()
        Me.btnRelayBit20 = New System.Windows.Forms.Button()
        Me.btnRelayBit13 = New System.Windows.Forms.Button()
        Me.btnRelayBit21 = New System.Windows.Forms.Button()
        Me.btnRelayBit5 = New System.Windows.Forms.Button()
        Me.btnRelayBit2 = New System.Windows.Forms.Button()
        Me.btnRelayBit22 = New System.Windows.Forms.Button()
        Me.btnRelayBit1 = New System.Windows.Forms.Button()
        Me.btnRelayBit23 = New System.Windows.Forms.Button()
        Me.btnRelayBit15 = New System.Windows.Forms.Button()
        Me.btnRelayBit3 = New System.Windows.Forms.Button()
        Me.btnRelayBit0 = New System.Windows.Forms.Button()
        Me.tpgMeter = New System.Windows.Forms.TabPage()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.tlpDaqMonitor = New System.Windows.Forms.TableLayoutPanel()
        Me.btnScanDaq = New System.Windows.Forms.Button()
        Me.tpgDataComm = New System.Windows.Forms.TabPage()
        Me.SplitContainer3 = New System.Windows.Forms.SplitContainer()
        Me.dgvUtility = New System.Windows.Forms.DataGridView()
        Me.btnBreak = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.btnDisplayI2CCommands = New System.Windows.Forms.Button()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtPass = New System.Windows.Forms.TextBox()
        Me.txtFail = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gbxStartIndicators = New System.Windows.Forms.GroupBox()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.btnTestStuff = New System.Windows.Forms.Button()
        Me.tmrScanInstruments = New System.Windows.Forms.Timer(Me.components)
        Me.DaqControlDataSet = New _680016_Generic.DaqControlDataSet()
        Me.ctxMonitor.SuspendLayout()
        Me.ctzMeterGrid.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tpgEnvironment.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.dgvEnvPallet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tpgMonitor.SuspendLayout()
        Me.TableLayoutPanelEquipmentControl.SuspendLayout()
        Me.gbxELoadPack.SuspendLayout()
        Me.TableLayoutPanel16.SuspendLayout()
        Me.GroupBox30.SuspendLayout()
        Me.TableLayoutPanel17.SuspendLayout()
        CType(Me.udELPackCRohms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELPackCCamps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELPackCVvolts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELPackCPwatts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel18.SuspendLayout()
        Me.TableLayoutPanel19.SuspendLayout()
        Me.GroupBox31.SuspendLayout()
        Me.GroupBox32.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.gbxELoadCell.SuspendLayout()
        Me.TableLayoutPanel11.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TableLayoutPanel12.SuspendLayout()
        CType(Me.udELCellCRohms, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELCellCCamps, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELCellCVvolts, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udELCellCPwatts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel13.SuspendLayout()
        Me.TableLayoutPanel15.SuspendLayout()
        Me.GroupBox25.SuspendLayout()
        Me.GroupBox24.SuspendLayout()
        Me.GroupBox23.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.gbxPowerSupplyPack.SuspendLayout()
        Me.TableLayoutPanel10.SuspendLayout()
        Me.GroupBox21.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel14.SuspendLayout()
        CType(Me.udPSPackOCP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSPackIlimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSPackVLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSPackOVP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxPowerSupplyAux.SuspendLayout()
        Me.TableLayoutPanel20.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        Me.GroupBox14.SuspendLayout()
        Me.TableLayoutPanel21.SuspendLayout()
        CType(Me.udPSAuxOCP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSAuxIlimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSAuxVLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSAuxOVP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxPowerSupplyCell.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        CType(Me.udPSCellOCP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSCellILimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSCellVlimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.udPSCellOVP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        CType(Me.dgvDaq200a, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvDaq200b, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox12.SuspendLayout()
        Me.tlpRelayIndi.SuspendLayout()
        Me.tpgMeter.SuspendLayout()
        Me.GroupBox15.SuspendLayout()
        Me.tlpDaqMonitor.SuspendLayout()
        Me.tpgDataComm.SuspendLayout()
        Me.SplitContainer3.Panel1.SuspendLayout()
        Me.SplitContainer3.Panel2.SuspendLayout()
        Me.SplitContainer3.SuspendLayout()
        CType(Me.dgvUtility, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.DaqControlDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dlgBqEVSW
        '
        Me.dlgBqEVSW.FileName = "OpenFileDialog1"
        Me.dlgBqEVSW.Filter = "bqEvaluation Application (bqEVSW.exe) |bqEVSW.exe|All Files (*.*)|*.*"
        '
        'SendI2CUnsealCodesToolStripMenuItem
        '
        Me.SendI2CUnsealCodesToolStripMenuItem.Name = "SendI2CUnsealCodesToolStripMenuItem"
        Me.SendI2CUnsealCodesToolStripMenuItem.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.SendI2CUnsealCodesToolStripMenuItem.Size = New System.Drawing.Size(248, 22)
        Me.SendI2CUnsealCodesToolStripMenuItem.Text = "Send Unseal Codes"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(228, 6)
        '
        'LocateBqEVSWExecutableFileToolStripMenuItem
        '
        Me.LocateBqEVSWExecutableFileToolStripMenuItem.Name = "LocateBqEVSWExecutableFileToolStripMenuItem"
        Me.LocateBqEVSWExecutableFileToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.LocateBqEVSWExecutableFileToolStripMenuItem.Text = "Locate bqEvaluation Software"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(189, 6)
        '
        'I2COperationsToolStripMenuItem
        '
        Me.I2COperationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SendI2CUnsealCodesToolStripMenuItem})
        Me.I2COperationsToolStripMenuItem.Name = "I2COperationsToolStripMenuItem"
        Me.I2COperationsToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.I2COperationsToolStripMenuItem.Text = "I2C Operations"
        '
        'SmbShutdownToolStripMenuItem
        '
        Me.SmbShutdownToolStripMenuItem.Name = "SmbShutdownToolStripMenuItem"
        Me.SmbShutdownToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.SmbShutdownToolStripMenuItem.Text = "Shutdown"
        '
        'SendSMBUnsealToolStripMenuItem
        '
        Me.SendSMBUnsealToolStripMenuItem.Name = "SendSMBUnsealToolStripMenuItem"
        Me.SendSMBUnsealToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.U), System.Windows.Forms.Keys)
        Me.SendSMBUnsealToolStripMenuItem.Size = New System.Drawing.Size(216, 22)
        Me.SendSMBUnsealToolStripMenuItem.Text = "Send Unseal Codes"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FuelGaugeToolStripMenuItem, Me.ToolStripSeparator2, Me.CommunicationTraceToolStripMenuItem, Me.I2C5VControlToolStripMenuItem, Me.ToolStripSeparator5, Me.mnuScanAllItems})
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
        Me.UtilityToolStripMenuItem.Text = "Utility"
        '
        'FuelGaugeToolStripMenuItem
        '
        Me.FuelGaugeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenBqEVSWToolStripMenuItem, Me.SMBusOperationsToolStripMenuItem, Me.I2COperationsToolStripMenuItem, Me.ToolStripSeparator4, Me.LocateBqEVSWExecutableFileToolStripMenuItem, Me.ShowBq76940ControlScreenToolStripMenuItem})
        Me.FuelGaugeToolStripMenuItem.Name = "FuelGaugeToolStripMenuItem"
        Me.FuelGaugeToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.FuelGaugeToolStripMenuItem.Text = "Fuel Gauging"
        '
        'OpenBqEVSWToolStripMenuItem
        '
        Me.OpenBqEVSWToolStripMenuItem.Name = "OpenBqEVSWToolStripMenuItem"
        Me.OpenBqEVSWToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.OpenBqEVSWToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.OpenBqEVSWToolStripMenuItem.Text = "Open bqEVSW"
        '
        'SMBusOperationsToolStripMenuItem
        '
        Me.SMBusOperationsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SendSMBUnsealToolStripMenuItem, Me.SmbShutdownToolStripMenuItem})
        Me.SMBusOperationsToolStripMenuItem.Name = "SMBusOperationsToolStripMenuItem"
        Me.SMBusOperationsToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.SMBusOperationsToolStripMenuItem.Text = "SMBus Operations"
        '
        'ShowBq76940ControlScreenToolStripMenuItem
        '
        Me.ShowBq76940ControlScreenToolStripMenuItem.CheckOnClick = True
        Me.ShowBq76940ControlScreenToolStripMenuItem.Name = "ShowBq76940ControlScreenToolStripMenuItem"
        Me.ShowBq76940ControlScreenToolStripMenuItem.Size = New System.Drawing.Size(231, 22)
        Me.ShowBq76940ControlScreenToolStripMenuItem.Text = "Show bq76940 Control Screen"
        Me.ShowBq76940ControlScreenToolStripMenuItem.ToolTipText = "Display bq76940 AFE Control Screen"
        '
        'CommunicationTraceToolStripMenuItem
        '
        Me.CommunicationTraceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EV2300CommToolStripMenuItem, Me.DAQCommToolStripMenuItem, Me.PowerSupply1ToolStripMenuItem, Me.PowerSupply2ToolStripMenuItem, Me.ElectronicLoadToolStripMenuItem})
        Me.CommunicationTraceToolStripMenuItem.Name = "CommunicationTraceToolStripMenuItem"
        Me.CommunicationTraceToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.CommunicationTraceToolStripMenuItem.Text = "Communication Trace"
        '
        'EV2300CommToolStripMenuItem
        '
        Me.EV2300CommToolStripMenuItem.CheckOnClick = True
        Me.EV2300CommToolStripMenuItem.Name = "EV2300CommToolStripMenuItem"
        Me.EV2300CommToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.EV2300CommToolStripMenuItem.Text = "EV2300 Comm"
        '
        'DAQCommToolStripMenuItem
        '
        Me.DAQCommToolStripMenuItem.CheckOnClick = True
        Me.DAQCommToolStripMenuItem.Name = "DAQCommToolStripMenuItem"
        Me.DAQCommToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.DAQCommToolStripMenuItem.Text = "DAQ Comm"
        '
        'PowerSupply1ToolStripMenuItem
        '
        Me.PowerSupply1ToolStripMenuItem.CheckOnClick = True
        Me.PowerSupply1ToolStripMenuItem.Name = "PowerSupply1ToolStripMenuItem"
        Me.PowerSupply1ToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.PowerSupply1ToolStripMenuItem.Text = "Power Supply 1"
        '
        'PowerSupply2ToolStripMenuItem
        '
        Me.PowerSupply2ToolStripMenuItem.CheckOnClick = True
        Me.PowerSupply2ToolStripMenuItem.Name = "PowerSupply2ToolStripMenuItem"
        Me.PowerSupply2ToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.PowerSupply2ToolStripMenuItem.Text = "Power Supply 2"
        '
        'ElectronicLoadToolStripMenuItem
        '
        Me.ElectronicLoadToolStripMenuItem.CheckOnClick = True
        Me.ElectronicLoadToolStripMenuItem.Name = "ElectronicLoadToolStripMenuItem"
        Me.ElectronicLoadToolStripMenuItem.Size = New System.Drawing.Size(155, 22)
        Me.ElectronicLoadToolStripMenuItem.Text = "Electronic Load"
        '
        'I2C5VControlToolStripMenuItem
        '
        Me.I2C5VControlToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VEnableToolStripMenuItem, Me.VDisableToolStripMenuItem})
        Me.I2C5VControlToolStripMenuItem.Name = "I2C5VControlToolStripMenuItem"
        Me.I2C5VControlToolStripMenuItem.Size = New System.Drawing.Size(192, 22)
        Me.I2C5VControlToolStripMenuItem.Text = "EV2300 5V Control"
        '
        'VEnableToolStripMenuItem
        '
        Me.VEnableToolStripMenuItem.Name = "VEnableToolStripMenuItem"
        Me.VEnableToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.VEnableToolStripMenuItem.Text = "5V Enable"
        '
        'VDisableToolStripMenuItem
        '
        Me.VDisableToolStripMenuItem.Name = "VDisableToolStripMenuItem"
        Me.VDisableToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.VDisableToolStripMenuItem.Text = "5V Disable"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(189, 6)
        '
        'mnuScanAllItems
        '
        Me.mnuScanAllItems.CheckOnClick = True
        Me.mnuScanAllItems.Name = "mnuScanAllItems"
        Me.mnuScanAllItems.Size = New System.Drawing.Size(192, 22)
        Me.mnuScanAllItems.Text = "Scan All Items"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(126, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'OpenConfigDialog
        '
        Me.OpenConfigDialog.Filter = "Config (*.xls)|*.xls|All Files (*.*)|*.*"
        Me.OpenConfigDialog.Title = "Open Configuration File"
        '
        'SaveCSVFileDialog
        '
        Me.SaveCSVFileDialog.Filter = "CSV Files (*.csv)|*.csv)|All Files (*.*)|*.*"
        Me.SaveCSVFileDialog.Title = "Save CSV Data File"
        '
        'SaveXMLFileDialog
        '
        Me.SaveXMLFileDialog.Filter = "XML Files (*.xml)|*.xml)|All Files (*.*)|*.*"
        Me.SaveXMLFileDialog.Title = "Save XML Data File"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'ctxMonitor
        '
        Me.ctxMonitor.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuScanAllItemsContext, Me.mnuSetRefreshIntervalTop})
        Me.ctxMonitor.Name = "cmsFrmTSControl"
        Me.ctxMonitor.Size = New System.Drawing.Size(195, 48)
        '
        'mnuScanAllItemsContext
        '
        Me.mnuScanAllItemsContext.Name = "mnuScanAllItemsContext"
        Me.mnuScanAllItemsContext.Size = New System.Drawing.Size(194, 22)
        Me.mnuScanAllItemsContext.Text = "Auto Scan Instruments"
        '
        'mnuSetRefreshIntervalTop
        '
        Me.mnuSetRefreshIntervalTop.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.txtRefreshInterval})
        Me.mnuSetRefreshIntervalTop.Name = "mnuSetRefreshIntervalTop"
        Me.mnuSetRefreshIntervalTop.Size = New System.Drawing.Size(194, 22)
        Me.mnuSetRefreshIntervalTop.Text = "Set Refresh Interval"
        '
        'txtRefreshInterval
        '
        Me.txtRefreshInterval.Name = "txtRefreshInterval"
        Me.txtRefreshInterval.Size = New System.Drawing.Size(152, 23)
        Me.txtRefreshInterval.Text = "1000"
        '
        'ctzMeterGrid
        '
        Me.ctzMeterGrid.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuResetDaqGrid, Me.SelectAllToolStripMenuItem, Me.UnselectAllToolStripMenuItem, Me.RemoveUncheckedToolStripMenuItem, Me.DeleteSelectedToolStripMenuItem, Me.CopyToClipboardToolStripMenuItem})
        Me.ctzMeterGrid.Name = "cmsFrmTSControl"
        Me.ctzMeterGrid.Size = New System.Drawing.Size(223, 136)
        '
        'mnuResetDaqGrid
        '
        Me.mnuResetDaqGrid.Name = "mnuResetDaqGrid"
        Me.mnuResetDaqGrid.Size = New System.Drawing.Size(222, 22)
        Me.mnuResetDaqGrid.Text = "Reset Grid"
        '
        'SelectAllToolStripMenuItem
        '
        Me.SelectAllToolStripMenuItem.Name = "SelectAllToolStripMenuItem"
        Me.SelectAllToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.SelectAllToolStripMenuItem.Text = "Check All"
        '
        'UnselectAllToolStripMenuItem
        '
        Me.UnselectAllToolStripMenuItem.Name = "UnselectAllToolStripMenuItem"
        Me.UnselectAllToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.UnselectAllToolStripMenuItem.Text = "Uncheck All"
        '
        'RemoveUncheckedToolStripMenuItem
        '
        Me.RemoveUncheckedToolStripMenuItem.Name = "RemoveUncheckedToolStripMenuItem"
        Me.RemoveUncheckedToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.RemoveUncheckedToolStripMenuItem.Text = "Delete Unchecked"
        '
        'DeleteSelectedToolStripMenuItem
        '
        Me.DeleteSelectedToolStripMenuItem.Name = "DeleteSelectedToolStripMenuItem"
        Me.DeleteSelectedToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.DeleteSelectedToolStripMenuItem.Text = "Delete Selected"
        '
        'CopyToClipboardToolStripMenuItem
        '
        Me.CopyToClipboardToolStripMenuItem.Name = "CopyToClipboardToolStripMenuItem"
        Me.CopyToClipboardToolStripMenuItem.Size = New System.Drawing.Size(222, 22)
        Me.CopyToClipboardToolStripMenuItem.Text = "Copy Selection to Clipboard"
        '
        'txtMessaqeLog
        '
        Me.txtMessaqeLog.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtMessaqeLog.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMessaqeLog.Location = New System.Drawing.Point(0, 0)
        Me.txtMessaqeLog.Margin = New System.Windows.Forms.Padding(4)
        Me.txtMessaqeLog.Name = "txtMessaqeLog"
        Me.txtMessaqeLog.Size = New System.Drawing.Size(494, 459)
        Me.txtMessaqeLog.TabIndex = 4
        Me.txtMessaqeLog.Text = ""
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(205, 6)
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'OpenConfigurationToolStripMenuItem
        '
        Me.OpenConfigurationToolStripMenuItem.Name = "OpenConfigurationToolStripMenuItem"
        Me.OpenConfigurationToolStripMenuItem.Size = New System.Drawing.Size(208, 22)
        Me.OpenConfigurationToolStripMenuItem.Text = "Import Configuration File"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.OpenConfigurationToolStripMenuItem, Me.ToolStripSeparator1, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.TestingToolStripMenuItem, Me.UtilityToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1474, 24)
        Me.MenuStrip1.TabIndex = 18
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'TestingToolStripMenuItem
        '
        Me.TestingToolStripMenuItem.Name = "TestingToolStripMenuItem"
        Me.TestingToolStripMenuItem.Size = New System.Drawing.Size(57, 20)
        Me.TestingToolStripMenuItem.Text = "Testing"
        '
        'btnSendDaqConfig
        '
        Me.btnSendDaqConfig.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSendDaqConfig.Location = New System.Drawing.Point(45, 25)
        Me.btnSendDaqConfig.Name = "btnSendDaqConfig"
        Me.btnSendDaqConfig.Size = New System.Drawing.Size(202, 39)
        Me.btnSendDaqConfig.TabIndex = 2
        Me.btnSendDaqConfig.Text = "Configure DAQ"
        Me.ToolTip1.SetToolTip(Me.btnSendDaqConfig, "Send Configuration to DAQ")
        Me.btnSendDaqConfig.UseVisualStyleBackColor = True
        '
        'btnResetDAQ
        '
        Me.btnResetDAQ.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnResetDAQ.Location = New System.Drawing.Point(631, 25)
        Me.btnResetDAQ.Name = "btnResetDAQ"
        Me.btnResetDAQ.Size = New System.Drawing.Size(202, 39)
        Me.btnResetDAQ.TabIndex = 3
        Me.btnResetDAQ.Text = "Reset DAQ"
        Me.ToolTip1.SetToolTip(Me.btnResetDAQ, "Send *RST to DAQ")
        Me.btnResetDAQ.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 24)
        Me.SplitContainer1.Margin = New System.Windows.Forms.Padding(4)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.TabControl1)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Panel2.Padding = New System.Windows.Forms.Padding(0, 65, 15, 15)
        Me.SplitContainer1.Size = New System.Drawing.Size(1474, 963)
        Me.SplitContainer1.SplitterDistance = 960
        Me.SplitContainer1.SplitterWidth = 5
        Me.SplitContainer1.TabIndex = 17
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tpgTesting)
        Me.TabControl1.Controls.Add(Me.tpgEnvironment)
        Me.TabControl1.Controls.Add(Me.tpgMonitor)
        Me.TabControl1.Controls.Add(Me.tpgMeter)
        Me.TabControl1.Controls.Add(Me.tpgDataComm)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(4)
        Me.TabControl1.Multiline = True
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.Padding = New System.Drawing.Point(6, 10)
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(960, 963)
        Me.TabControl1.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight
        Me.TabControl1.TabIndex = 14
        '
        'tpgTesting
        '
        Me.tpgTesting.Location = New System.Drawing.Point(4, 40)
        Me.tpgTesting.Name = "tpgTesting"
        Me.tpgTesting.Size = New System.Drawing.Size(952, 919)
        Me.tpgTesting.TabIndex = 7
        Me.tpgTesting.Tag = "Testing"
        Me.tpgTesting.Text = "Testing"
        Me.tpgTesting.UseVisualStyleBackColor = True
        '
        'tpgEnvironment
        '
        Me.tpgEnvironment.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tpgEnvironment.Controls.Add(Me.TableLayoutPanel1)
        Me.tpgEnvironment.Location = New System.Drawing.Point(4, 40)
        Me.tpgEnvironment.Margin = New System.Windows.Forms.Padding(4)
        Me.tpgEnvironment.Name = "tpgEnvironment"
        Me.tpgEnvironment.Padding = New System.Windows.Forms.Padding(4)
        Me.tpgEnvironment.Size = New System.Drawing.Size(952, 919)
        Me.tpgEnvironment.TabIndex = 0
        Me.tpgEnvironment.Tag = "Relay"
        Me.tpgEnvironment.Text = "Environment"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.dgvEnvPallet1, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(4, 4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(944, 911)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'dgvEnvPallet1
        '
        Me.dgvEnvPallet1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvEnvPallet1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvEnvPallet1.Location = New System.Drawing.Point(3, 3)
        Me.dgvEnvPallet1.Name = "dgvEnvPallet1"
        Me.dgvEnvPallet1.Size = New System.Drawing.Size(466, 449)
        Me.dgvEnvPallet1.TabIndex = 1
        '
        'tpgMonitor
        '
        Me.tpgMonitor.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.tpgMonitor.Controls.Add(Me.TableLayoutPanelEquipmentControl)
        Me.tpgMonitor.Location = New System.Drawing.Point(4, 40)
        Me.tpgMonitor.Margin = New System.Windows.Forms.Padding(4)
        Me.tpgMonitor.Name = "tpgMonitor"
        Me.tpgMonitor.Padding = New System.Windows.Forms.Padding(4)
        Me.tpgMonitor.Size = New System.Drawing.Size(952, 919)
        Me.tpgMonitor.TabIndex = 2
        Me.tpgMonitor.Tag = "Mon"
        Me.tpgMonitor.Text = "Equipment Control"
        '
        'TableLayoutPanelEquipmentControl
        '
        Me.TableLayoutPanelEquipmentControl.ColumnCount = 3
        Me.TableLayoutPanelEquipmentControl.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.ContextMenuStrip = Me.ctxMonitor
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.gbxELoadPack, 1, 1)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.gbxELoadCell, 0, 1)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.gbxPowerSupplyPack, 1, 0)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.gbxPowerSupplyAux, 2, 0)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.gbxPowerSupplyCell, 0, 0)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.GroupBox7, 2, 2)
        Me.TableLayoutPanelEquipmentControl.Controls.Add(Me.GroupBox12, 0, 2)
        Me.TableLayoutPanelEquipmentControl.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanelEquipmentControl.Location = New System.Drawing.Point(4, 4)
        Me.TableLayoutPanelEquipmentControl.Name = "TableLayoutPanelEquipmentControl"
        Me.TableLayoutPanelEquipmentControl.RowCount = 3
        Me.TableLayoutPanelEquipmentControl.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanelEquipmentControl.Size = New System.Drawing.Size(944, 911)
        Me.TableLayoutPanelEquipmentControl.TabIndex = 7
        '
        'gbxELoadPack
        '
        Me.gbxELoadPack.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gbxELoadPack.Controls.Add(Me.TableLayoutPanel16)
        Me.gbxELoadPack.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxELoadPack.Location = New System.Drawing.Point(317, 305)
        Me.gbxELoadPack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxELoadPack.Name = "gbxELoadPack"
        Me.gbxELoadPack.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxELoadPack.Size = New System.Drawing.Size(308, 299)
        Me.gbxELoadPack.TabIndex = 9
        Me.gbxELoadPack.TabStop = False
        Me.gbxELoadPack.Text = "Pack Electronic Load"
        '
        'TableLayoutPanel16
        '
        Me.TableLayoutPanel16.ColumnCount = 1
        Me.TableLayoutPanel16.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel16.Controls.Add(Me.GroupBox30, 0, 1)
        Me.TableLayoutPanel16.Controls.Add(Me.TableLayoutPanel19, 0, 0)
        Me.TableLayoutPanel16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel16.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel16.Location = New System.Drawing.Point(3, 24)
        Me.TableLayoutPanel16.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel16.Name = "TableLayoutPanel16"
        Me.TableLayoutPanel16.RowCount = 2
        Me.TableLayoutPanel16.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.30584!))
        Me.TableLayoutPanel16.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.69416!))
        Me.TableLayoutPanel16.Size = New System.Drawing.Size(302, 273)
        Me.TableLayoutPanel16.TabIndex = 1
        '
        'GroupBox30
        '
        Me.GroupBox30.Controls.Add(Me.TableLayoutPanel17)
        Me.GroupBox30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox30.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox30.Location = New System.Drawing.Point(3, 60)
        Me.GroupBox30.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox30.Name = "GroupBox30"
        Me.GroupBox30.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox30.Size = New System.Drawing.Size(296, 211)
        Me.GroupBox30.TabIndex = 5
        Me.GroupBox30.TabStop = False
        Me.GroupBox30.Text = "Operating Mode"
        '
        'TableLayoutPanel17
        '
        Me.TableLayoutPanel17.ColumnCount = 3
        Me.TableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.01174!))
        Me.TableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.27661!))
        Me.TableLayoutPanel17.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.71165!))
        Me.TableLayoutPanel17.Controls.Add(Me.radELPackModeCC, 0, 0)
        Me.TableLayoutPanel17.Controls.Add(Me.radELPackModeCV, 0, 1)
        Me.TableLayoutPanel17.Controls.Add(Me.Label13, 2, 3)
        Me.TableLayoutPanel17.Controls.Add(Me.radELPackModeCP, 0, 2)
        Me.TableLayoutPanel17.Controls.Add(Me.Label14, 2, 2)
        Me.TableLayoutPanel17.Controls.Add(Me.radELPackModeCR, 0, 3)
        Me.TableLayoutPanel17.Controls.Add(Me.Label15, 2, 1)
        Me.TableLayoutPanel17.Controls.Add(Me.udELPackCRohms, 1, 3)
        Me.TableLayoutPanel17.Controls.Add(Me.Label16, 2, 0)
        Me.TableLayoutPanel17.Controls.Add(Me.udELPackCCamps, 1, 0)
        Me.TableLayoutPanel17.Controls.Add(Me.udELPackCVvolts, 1, 1)
        Me.TableLayoutPanel17.Controls.Add(Me.udELPackCPwatts, 1, 2)
        Me.TableLayoutPanel17.Controls.Add(Me.TableLayoutPanel18, 0, 4)
        Me.TableLayoutPanel17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel17.Location = New System.Drawing.Point(3, 20)
        Me.TableLayoutPanel17.Name = "TableLayoutPanel17"
        Me.TableLayoutPanel17.RowCount = 5
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03806!))
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel17.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.85271!))
        Me.TableLayoutPanel17.Size = New System.Drawing.Size(290, 189)
        Me.TableLayoutPanel17.TabIndex = 0
        '
        'radELPackModeCC
        '
        Me.radELPackModeCC.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELPackModeCC.AutoSize = True
        Me.radELPackModeCC.Location = New System.Drawing.Point(3, 6)
        Me.radELPackModeCC.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELPackModeCC.Name = "radELPackModeCC"
        Me.radELPackModeCC.Size = New System.Drawing.Size(122, 22)
        Me.radELPackModeCC.TabIndex = 0
        Me.radELPackModeCC.TabStop = True
        Me.radELPackModeCC.Tag = "CCH"
        Me.radELPackModeCC.Text = "Select CC Mode"
        Me.radELPackModeCC.UseVisualStyleBackColor = True
        '
        'radELPackModeCV
        '
        Me.radELPackModeCV.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELPackModeCV.AutoSize = True
        Me.radELPackModeCV.Location = New System.Drawing.Point(3, 41)
        Me.radELPackModeCV.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELPackModeCV.Name = "radELPackModeCV"
        Me.radELPackModeCV.Size = New System.Drawing.Size(123, 22)
        Me.radELPackModeCV.TabIndex = 0
        Me.radELPackModeCV.TabStop = True
        Me.radELPackModeCV.Tag = "CV"
        Me.radELPackModeCV.Text = "Select CV Mode"
        Me.radELPackModeCV.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(235, 113)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(45, 18)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Ohms"
        '
        'radELPackModeCP
        '
        Me.radELPackModeCP.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELPackModeCP.AutoSize = True
        Me.radELPackModeCP.Location = New System.Drawing.Point(3, 76)
        Me.radELPackModeCP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELPackModeCP.Name = "radELPackModeCP"
        Me.radELPackModeCP.Size = New System.Drawing.Size(121, 22)
        Me.radELPackModeCP.TabIndex = 0
        Me.radELPackModeCP.TabStop = True
        Me.radELPackModeCP.Tag = "CP"
        Me.radELPackModeCP.Text = "Select CP Mode"
        Me.radELPackModeCP.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(237, 78)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(41, 18)
        Me.Label14.TabIndex = 8
        Me.Label14.Text = "Watts"
        '
        'radELPackModeCR
        '
        Me.radELPackModeCR.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELPackModeCR.AutoSize = True
        Me.radELPackModeCR.Location = New System.Drawing.Point(3, 111)
        Me.radELPackModeCR.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELPackModeCR.Name = "radELPackModeCR"
        Me.radELPackModeCR.Size = New System.Drawing.Size(122, 22)
        Me.radELPackModeCR.TabIndex = 0
        Me.radELPackModeCR.TabStop = True
        Me.radELPackModeCR.Tag = "CR"
        Me.radELPackModeCR.Text = "Select CR Mode"
        Me.radELPackModeCR.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(238, 43)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(40, 18)
        Me.Label15.TabIndex = 8
        Me.Label15.Text = "Volts"
        '
        'udELPackCRohms
        '
        Me.udELPackCRohms.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELPackCRohms.AutoSize = True
        Me.udELPackCRohms.DecimalPlaces = 3
        Me.udELPackCRohms.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELPackCRohms.Location = New System.Drawing.Point(145, 108)
        Me.udELPackCRohms.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELPackCRohms.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.udELPackCRohms.Name = "udELPackCRohms"
        Me.udELPackCRohms.Size = New System.Drawing.Size(78, 29)
        Me.udELPackCRohms.TabIndex = 6
        Me.udELPackCRohms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(236, 8)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(44, 18)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Amps"
        '
        'udELPackCCamps
        '
        Me.udELPackCCamps.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELPackCCamps.AutoSize = True
        Me.udELPackCCamps.DecimalPlaces = 3
        Me.udELPackCCamps.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELPackCCamps.Increment = New Decimal(New Integer() {5, 0, 0, 131072})
        Me.udELPackCCamps.Location = New System.Drawing.Point(145, 3)
        Me.udELPackCCamps.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELPackCCamps.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.udELPackCCamps.Name = "udELPackCCamps"
        Me.udELPackCCamps.Size = New System.Drawing.Size(78, 29)
        Me.udELPackCCamps.TabIndex = 3
        Me.udELPackCCamps.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udELPackCVvolts
        '
        Me.udELPackCVvolts.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELPackCVvolts.AutoSize = True
        Me.udELPackCVvolts.DecimalPlaces = 3
        Me.udELPackCVvolts.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELPackCVvolts.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udELPackCVvolts.Location = New System.Drawing.Point(145, 38)
        Me.udELPackCVvolts.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELPackCVvolts.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.udELPackCVvolts.Name = "udELPackCVvolts"
        Me.udELPackCVvolts.Size = New System.Drawing.Size(78, 29)
        Me.udELPackCVvolts.TabIndex = 6
        Me.udELPackCVvolts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udELPackCPwatts
        '
        Me.udELPackCPwatts.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELPackCPwatts.AutoSize = True
        Me.udELPackCPwatts.DecimalPlaces = 3
        Me.udELPackCPwatts.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELPackCPwatts.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udELPackCPwatts.Location = New System.Drawing.Point(145, 73)
        Me.udELPackCPwatts.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELPackCPwatts.Maximum = New Decimal(New Integer() {400, 0, 0, 0})
        Me.udELPackCPwatts.Name = "udELPackCPwatts"
        Me.udELPackCPwatts.Size = New System.Drawing.Size(78, 29)
        Me.udELPackCPwatts.TabIndex = 6
        Me.udELPackCPwatts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TableLayoutPanel18
        '
        Me.TableLayoutPanel18.ColumnCount = 3
        Me.TableLayoutPanel17.SetColumnSpan(Me.TableLayoutPanel18, 3)
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.4058!))
        Me.TableLayoutPanel18.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.55072!))
        Me.TableLayoutPanel18.Controls.Add(Me.chkELPackShort, 2, 0)
        Me.TableLayoutPanel18.Controls.Add(Me.btnELPackEnabled, 0, 0)
        Me.TableLayoutPanel18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel18.Location = New System.Drawing.Point(3, 143)
        Me.TableLayoutPanel18.Name = "TableLayoutPanel18"
        Me.TableLayoutPanel18.RowCount = 1
        Me.TableLayoutPanel18.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel18.Size = New System.Drawing.Size(284, 43)
        Me.TableLayoutPanel18.TabIndex = 10
        '
        'chkELPackShort
        '
        Me.chkELPackShort.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.chkELPackShort.AutoSize = True
        Me.chkELPackShort.Location = New System.Drawing.Point(179, 10)
        Me.chkELPackShort.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkELPackShort.Name = "chkELPackShort"
        Me.chkELPackShort.Size = New System.Drawing.Size(100, 22)
        Me.chkELPackShort.TabIndex = 9
        Me.chkELPackShort.Text = "Apply Short"
        Me.chkELPackShort.UseVisualStyleBackColor = True
        '
        'btnELPackEnabled
        '
        Me.TableLayoutPanel18.SetColumnSpan(Me.btnELPackEnabled, 2)
        Me.btnELPackEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnELPackEnabled.Location = New System.Drawing.Point(9, 8)
        Me.btnELPackEnabled.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.btnELPackEnabled.Name = "btnELPackEnabled"
        Me.btnELPackEnabled.Size = New System.Drawing.Size(156, 27)
        Me.btnELPackEnabled.TabIndex = 2
        Me.btnELPackEnabled.Tag = "A"
        Me.btnELPackEnabled.Text = "Button2"
        Me.btnELPackEnabled.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel19
        '
        Me.TableLayoutPanel19.ColumnCount = 4
        Me.TableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel19.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel19.Controls.Add(Me.GroupBox31, 3, 0)
        Me.TableLayoutPanel19.Controls.Add(Me.GroupBox32, 2, 0)
        Me.TableLayoutPanel19.Controls.Add(Me.GroupBox5, 1, 0)
        Me.TableLayoutPanel19.Controls.Add(Me.GroupBox6, 0, 0)
        Me.TableLayoutPanel19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel19.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel19.Location = New System.Drawing.Point(3, 2)
        Me.TableLayoutPanel19.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel19.Name = "TableLayoutPanel19"
        Me.TableLayoutPanel19.RowCount = 1
        Me.TableLayoutPanel19.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel19.Size = New System.Drawing.Size(296, 54)
        Me.TableLayoutPanel19.TabIndex = 2
        '
        'GroupBox31
        '
        Me.GroupBox31.Controls.Add(Me.txtELPackRin)
        Me.GroupBox31.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox31.Location = New System.Drawing.Point(225, 2)
        Me.GroupBox31.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox31.Name = "GroupBox31"
        Me.GroupBox31.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox31.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox31.TabIndex = 3
        Me.GroupBox31.TabStop = False
        Me.GroupBox31.Text = "Ohms"
        '
        'txtELPackRin
        '
        Me.txtELPackRin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELPackRin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELPackRin.Location = New System.Drawing.Point(2, 20)
        Me.txtELPackRin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELPackRin.Name = "txtELPackRin"
        Me.txtELPackRin.ReadOnly = True
        Me.txtELPackRin.Size = New System.Drawing.Size(64, 29)
        Me.txtELPackRin.TabIndex = 1
        Me.txtELPackRin.Text = "88.888"
        Me.txtELPackRin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox32
        '
        Me.GroupBox32.Controls.Add(Me.txtELPackPin)
        Me.GroupBox32.Dock = System.Windows.Forms.DockStyle.Right
        Me.GroupBox32.Location = New System.Drawing.Point(151, 2)
        Me.GroupBox32.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox32.Name = "GroupBox32"
        Me.GroupBox32.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox32.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox32.TabIndex = 2
        Me.GroupBox32.TabStop = False
        Me.GroupBox32.Text = "Watts"
        '
        'txtELPackPin
        '
        Me.txtELPackPin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELPackPin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELPackPin.Location = New System.Drawing.Point(2, 20)
        Me.txtELPackPin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELPackPin.Name = "txtELPackPin"
        Me.txtELPackPin.ReadOnly = True
        Me.txtELPackPin.Size = New System.Drawing.Size(64, 29)
        Me.txtELPackPin.TabIndex = 1
        Me.txtELPackPin.Text = "88.888"
        Me.txtELPackPin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.txtELPackVin)
        Me.GroupBox5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox5.Location = New System.Drawing.Point(77, 2)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox5.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Volts"
        '
        'txtELPackVin
        '
        Me.txtELPackVin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELPackVin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELPackVin.Location = New System.Drawing.Point(2, 20)
        Me.txtELPackVin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELPackVin.Name = "txtELPackVin"
        Me.txtELPackVin.ReadOnly = True
        Me.txtELPackVin.Size = New System.Drawing.Size(64, 29)
        Me.txtELPackVin.TabIndex = 1
        Me.txtELPackVin.Text = "88.888"
        Me.txtELPackVin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.txtELPackIin)
        Me.GroupBox6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.Location = New System.Drawing.Point(3, 2)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox6.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox6.TabIndex = 0
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Amps"
        '
        'txtELPackIin
        '
        Me.txtELPackIin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELPackIin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELPackIin.Location = New System.Drawing.Point(2, 20)
        Me.txtELPackIin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELPackIin.Name = "txtELPackIin"
        Me.txtELPackIin.ReadOnly = True
        Me.txtELPackIin.Size = New System.Drawing.Size(64, 29)
        Me.txtELPackIin.TabIndex = 1
        Me.txtELPackIin.Text = "88.888"
        Me.txtELPackIin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gbxELoadCell
        '
        Me.gbxELoadCell.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gbxELoadCell.Controls.Add(Me.TableLayoutPanel11)
        Me.gbxELoadCell.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxELoadCell.Location = New System.Drawing.Point(3, 305)
        Me.gbxELoadCell.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxELoadCell.Name = "gbxELoadCell"
        Me.gbxELoadCell.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxELoadCell.Size = New System.Drawing.Size(308, 299)
        Me.gbxELoadCell.TabIndex = 8
        Me.gbxELoadCell.TabStop = False
        Me.gbxELoadCell.Text = "Cell Electronic Load"
        '
        'TableLayoutPanel11
        '
        Me.TableLayoutPanel11.ColumnCount = 1
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel11.Controls.Add(Me.GroupBox4, 0, 1)
        Me.TableLayoutPanel11.Controls.Add(Me.TableLayoutPanel15, 0, 0)
        Me.TableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel11.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel11.Location = New System.Drawing.Point(3, 24)
        Me.TableLayoutPanel11.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel11.Name = "TableLayoutPanel11"
        Me.TableLayoutPanel11.RowCount = 2
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 21.30584!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 78.69416!))
        Me.TableLayoutPanel11.Size = New System.Drawing.Size(302, 273)
        Me.TableLayoutPanel11.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TableLayoutPanel12)
        Me.GroupBox4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox4.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(3, 60)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox4.Size = New System.Drawing.Size(296, 211)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Operating Mode"
        '
        'TableLayoutPanel12
        '
        Me.TableLayoutPanel12.ColumnCount = 3
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.85246!))
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.18033!))
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.63935!))
        Me.TableLayoutPanel12.Controls.Add(Me.radELCellModeCC, 0, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.radELCellModeCV, 0, 1)
        Me.TableLayoutPanel12.Controls.Add(Me.Label9, 2, 3)
        Me.TableLayoutPanel12.Controls.Add(Me.radELCellModeCP, 0, 2)
        Me.TableLayoutPanel12.Controls.Add(Me.Label10, 2, 2)
        Me.TableLayoutPanel12.Controls.Add(Me.radELCellModeCR, 0, 3)
        Me.TableLayoutPanel12.Controls.Add(Me.Label11, 2, 1)
        Me.TableLayoutPanel12.Controls.Add(Me.udELCellCRohms, 1, 3)
        Me.TableLayoutPanel12.Controls.Add(Me.Label12, 2, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.udELCellCCamps, 1, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.udELCellCVvolts, 1, 1)
        Me.TableLayoutPanel12.Controls.Add(Me.udELCellCPwatts, 1, 2)
        Me.TableLayoutPanel12.Controls.Add(Me.TableLayoutPanel13, 0, 4)
        Me.TableLayoutPanel12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel12.Location = New System.Drawing.Point(3, 20)
        Me.TableLayoutPanel12.Name = "TableLayoutPanel12"
        Me.TableLayoutPanel12.RowCount = 5
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03806!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.03641!))
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 23.85271!))
        Me.TableLayoutPanel12.Size = New System.Drawing.Size(290, 189)
        Me.TableLayoutPanel12.TabIndex = 0
        '
        'radELCellModeCC
        '
        Me.radELCellModeCC.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELCellModeCC.AutoSize = True
        Me.radELCellModeCC.Location = New System.Drawing.Point(3, 6)
        Me.radELCellModeCC.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELCellModeCC.Name = "radELCellModeCC"
        Me.radELCellModeCC.Size = New System.Drawing.Size(122, 22)
        Me.radELCellModeCC.TabIndex = 0
        Me.radELCellModeCC.TabStop = True
        Me.radELCellModeCC.Tag = "CCH"
        Me.radELCellModeCC.Text = "Select CC Mode"
        Me.radELCellModeCC.UseVisualStyleBackColor = True
        '
        'radELCellModeCV
        '
        Me.radELCellModeCV.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELCellModeCV.AutoSize = True
        Me.radELCellModeCV.Location = New System.Drawing.Point(3, 41)
        Me.radELCellModeCV.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELCellModeCV.Name = "radELCellModeCV"
        Me.radELCellModeCV.Size = New System.Drawing.Size(123, 22)
        Me.radELCellModeCV.TabIndex = 0
        Me.radELCellModeCV.TabStop = True
        Me.radELCellModeCV.Tag = "CV"
        Me.radELCellModeCV.Text = "Select CV Mode"
        Me.radELCellModeCV.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(235, 113)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 18)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Ohms"
        '
        'radELCellModeCP
        '
        Me.radELCellModeCP.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELCellModeCP.AutoSize = True
        Me.radELCellModeCP.Location = New System.Drawing.Point(3, 76)
        Me.radELCellModeCP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELCellModeCP.Name = "radELCellModeCP"
        Me.radELCellModeCP.Size = New System.Drawing.Size(121, 22)
        Me.radELCellModeCP.TabIndex = 0
        Me.radELCellModeCP.TabStop = True
        Me.radELCellModeCP.Tag = "CP"
        Me.radELCellModeCP.Text = "Select CP Mode"
        Me.radELCellModeCP.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(237, 78)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 18)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Watts"
        '
        'radELCellModeCR
        '
        Me.radELCellModeCR.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.radELCellModeCR.AutoSize = True
        Me.radELCellModeCR.Location = New System.Drawing.Point(3, 111)
        Me.radELCellModeCR.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.radELCellModeCR.Name = "radELCellModeCR"
        Me.radELCellModeCR.Size = New System.Drawing.Size(122, 22)
        Me.radELCellModeCR.TabIndex = 0
        Me.radELCellModeCR.TabStop = True
        Me.radELCellModeCR.Tag = "CR"
        Me.radELCellModeCR.Text = "Select CR Mode"
        Me.radELCellModeCR.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(238, 43)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(40, 18)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Volts"
        '
        'udELCellCRohms
        '
        Me.udELCellCRohms.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELCellCRohms.AutoSize = True
        Me.udELCellCRohms.DecimalPlaces = 3
        Me.udELCellCRohms.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELCellCRohms.Location = New System.Drawing.Point(145, 108)
        Me.udELCellCRohms.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELCellCRohms.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.udELCellCRohms.Name = "udELCellCRohms"
        Me.udELCellCRohms.Size = New System.Drawing.Size(78, 29)
        Me.udELCellCRohms.TabIndex = 6
        Me.udELCellCRohms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label12
        '
        Me.Label12.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(236, 8)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 18)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "Amps"
        '
        'udELCellCCamps
        '
        Me.udELCellCCamps.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELCellCCamps.AutoSize = True
        Me.udELCellCCamps.DecimalPlaces = 3
        Me.udELCellCCamps.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELCellCCamps.Increment = New Decimal(New Integer() {5, 0, 0, 131072})
        Me.udELCellCCamps.Location = New System.Drawing.Point(145, 3)
        Me.udELCellCCamps.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELCellCCamps.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
        Me.udELCellCCamps.Name = "udELCellCCamps"
        Me.udELCellCCamps.Size = New System.Drawing.Size(78, 29)
        Me.udELCellCCamps.TabIndex = 3
        Me.udELCellCCamps.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udELCellCVvolts
        '
        Me.udELCellCVvolts.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELCellCVvolts.AutoSize = True
        Me.udELCellCVvolts.DecimalPlaces = 3
        Me.udELCellCVvolts.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELCellCVvolts.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udELCellCVvolts.Location = New System.Drawing.Point(145, 38)
        Me.udELCellCVvolts.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELCellCVvolts.Maximum = New Decimal(New Integer() {80, 0, 0, 0})
        Me.udELCellCVvolts.Name = "udELCellCVvolts"
        Me.udELCellCVvolts.Size = New System.Drawing.Size(78, 29)
        Me.udELCellCVvolts.TabIndex = 6
        Me.udELCellCVvolts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udELCellCPwatts
        '
        Me.udELCellCPwatts.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.udELCellCPwatts.AutoSize = True
        Me.udELCellCPwatts.DecimalPlaces = 3
        Me.udELCellCPwatts.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.udELCellCPwatts.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udELCellCPwatts.Location = New System.Drawing.Point(145, 73)
        Me.udELCellCPwatts.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udELCellCPwatts.Maximum = New Decimal(New Integer() {400, 0, 0, 0})
        Me.udELCellCPwatts.Name = "udELCellCPwatts"
        Me.udELCellCPwatts.Size = New System.Drawing.Size(78, 29)
        Me.udELCellCPwatts.TabIndex = 6
        Me.udELCellCPwatts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TableLayoutPanel13
        '
        Me.TableLayoutPanel13.ColumnCount = 3
        Me.TableLayoutPanel12.SetColumnSpan(Me.TableLayoutPanel13, 3)
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.4058!))
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.55072!))
        Me.TableLayoutPanel13.Controls.Add(Me.chkELCellShort, 2, 0)
        Me.TableLayoutPanel13.Controls.Add(Me.btnELCellEnabled, 0, 0)
        Me.TableLayoutPanel13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel13.Location = New System.Drawing.Point(3, 143)
        Me.TableLayoutPanel13.Name = "TableLayoutPanel13"
        Me.TableLayoutPanel13.RowCount = 1
        Me.TableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel13.Size = New System.Drawing.Size(284, 43)
        Me.TableLayoutPanel13.TabIndex = 10
        '
        'chkELCellShort
        '
        Me.chkELCellShort.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.chkELCellShort.AutoSize = True
        Me.chkELCellShort.Location = New System.Drawing.Point(179, 10)
        Me.chkELCellShort.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.chkELCellShort.Name = "chkELCellShort"
        Me.chkELCellShort.Size = New System.Drawing.Size(100, 22)
        Me.chkELCellShort.TabIndex = 9
        Me.chkELCellShort.Text = "Apply Short"
        Me.chkELCellShort.UseVisualStyleBackColor = True
        '
        'btnELCellEnabled
        '
        Me.TableLayoutPanel13.SetColumnSpan(Me.btnELCellEnabled, 2)
        Me.btnELCellEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnELCellEnabled.Location = New System.Drawing.Point(9, 8)
        Me.btnELCellEnabled.Margin = New System.Windows.Forms.Padding(9, 8, 9, 8)
        Me.btnELCellEnabled.Name = "btnELCellEnabled"
        Me.btnELCellEnabled.Size = New System.Drawing.Size(156, 27)
        Me.btnELCellEnabled.TabIndex = 2
        Me.btnELCellEnabled.Tag = "A"
        Me.btnELCellEnabled.Text = "Button2"
        Me.btnELCellEnabled.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel15
        '
        Me.TableLayoutPanel15.ColumnCount = 4
        Me.TableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel15.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.TableLayoutPanel15.Controls.Add(Me.GroupBox25, 3, 0)
        Me.TableLayoutPanel15.Controls.Add(Me.GroupBox24, 2, 0)
        Me.TableLayoutPanel15.Controls.Add(Me.GroupBox23, 1, 0)
        Me.TableLayoutPanel15.Controls.Add(Me.GroupBox9, 0, 0)
        Me.TableLayoutPanel15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel15.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel15.Location = New System.Drawing.Point(3, 2)
        Me.TableLayoutPanel15.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel15.Name = "TableLayoutPanel15"
        Me.TableLayoutPanel15.RowCount = 1
        Me.TableLayoutPanel15.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel15.Size = New System.Drawing.Size(296, 54)
        Me.TableLayoutPanel15.TabIndex = 2
        '
        'GroupBox25
        '
        Me.GroupBox25.Controls.Add(Me.txtELCellRin)
        Me.GroupBox25.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox25.Location = New System.Drawing.Point(225, 2)
        Me.GroupBox25.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox25.Name = "GroupBox25"
        Me.GroupBox25.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox25.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox25.TabIndex = 3
        Me.GroupBox25.TabStop = False
        Me.GroupBox25.Text = "Ohms"
        '
        'txtELCellRin
        '
        Me.txtELCellRin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELCellRin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELCellRin.Location = New System.Drawing.Point(2, 20)
        Me.txtELCellRin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELCellRin.Name = "txtELCellRin"
        Me.txtELCellRin.ReadOnly = True
        Me.txtELCellRin.Size = New System.Drawing.Size(64, 29)
        Me.txtELCellRin.TabIndex = 1
        Me.txtELCellRin.Text = "88.888"
        Me.txtELCellRin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox24
        '
        Me.GroupBox24.Controls.Add(Me.txtELCellPin)
        Me.GroupBox24.Dock = System.Windows.Forms.DockStyle.Right
        Me.GroupBox24.Location = New System.Drawing.Point(151, 2)
        Me.GroupBox24.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox24.Name = "GroupBox24"
        Me.GroupBox24.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox24.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox24.TabIndex = 2
        Me.GroupBox24.TabStop = False
        Me.GroupBox24.Text = "Watts"
        '
        'txtELCellPin
        '
        Me.txtELCellPin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELCellPin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELCellPin.Location = New System.Drawing.Point(2, 20)
        Me.txtELCellPin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELCellPin.Name = "txtELCellPin"
        Me.txtELCellPin.ReadOnly = True
        Me.txtELCellPin.Size = New System.Drawing.Size(64, 29)
        Me.txtELCellPin.TabIndex = 1
        Me.txtELCellPin.Text = "88.888"
        Me.txtELCellPin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox23
        '
        Me.GroupBox23.Controls.Add(Me.txtELCellVin)
        Me.GroupBox23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox23.Location = New System.Drawing.Point(77, 2)
        Me.GroupBox23.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox23.Name = "GroupBox23"
        Me.GroupBox23.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox23.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox23.TabIndex = 1
        Me.GroupBox23.TabStop = False
        Me.GroupBox23.Text = "Volts"
        '
        'txtELCellVin
        '
        Me.txtELCellVin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELCellVin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELCellVin.Location = New System.Drawing.Point(2, 20)
        Me.txtELCellVin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELCellVin.Name = "txtELCellVin"
        Me.txtELCellVin.ReadOnly = True
        Me.txtELCellVin.Size = New System.Drawing.Size(64, 29)
        Me.txtELCellVin.TabIndex = 1
        Me.txtELCellVin.Text = "88.888"
        Me.txtELCellVin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.txtELCellIin)
        Me.GroupBox9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox9.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.Location = New System.Drawing.Point(3, 2)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox9.Size = New System.Drawing.Size(68, 50)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Amps"
        '
        'txtELCellIin
        '
        Me.txtELCellIin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtELCellIin.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtELCellIin.Location = New System.Drawing.Point(2, 20)
        Me.txtELCellIin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtELCellIin.Name = "txtELCellIin"
        Me.txtELCellIin.ReadOnly = True
        Me.txtELCellIin.Size = New System.Drawing.Size(64, 29)
        Me.txtELCellIin.TabIndex = 1
        Me.txtELCellIin.Text = "88.888"
        Me.txtELCellIin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'gbxPowerSupplyPack
        '
        Me.gbxPowerSupplyPack.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gbxPowerSupplyPack.Controls.Add(Me.TableLayoutPanel10)
        Me.gbxPowerSupplyPack.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxPowerSupplyPack.Location = New System.Drawing.Point(317, 9)
        Me.gbxPowerSupplyPack.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxPowerSupplyPack.Name = "gbxPowerSupplyPack"
        Me.gbxPowerSupplyPack.Padding = New System.Windows.Forms.Padding(7)
        Me.gbxPowerSupplyPack.Size = New System.Drawing.Size(308, 285)
        Me.gbxPowerSupplyPack.TabIndex = 7
        Me.gbxPowerSupplyPack.TabStop = False
        Me.gbxPowerSupplyPack.Text = "Pack Power Supply"
        '
        'TableLayoutPanel10
        '
        Me.TableLayoutPanel10.ColumnCount = 2
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel10.Controls.Add(Me.GroupBox21, 0, 0)
        Me.TableLayoutPanel10.Controls.Add(Me.GroupBox1, 1, 0)
        Me.TableLayoutPanel10.Controls.Add(Me.TableLayoutPanel14, 0, 1)
        Me.TableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel10.Location = New System.Drawing.Point(7, 29)
        Me.TableLayoutPanel10.Name = "TableLayoutPanel10"
        Me.TableLayoutPanel10.RowCount = 2
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.90763!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.09237!))
        Me.TableLayoutPanel10.Size = New System.Drawing.Size(294, 249)
        Me.TableLayoutPanel10.TabIndex = 0
        '
        'GroupBox21
        '
        Me.GroupBox21.Controls.Add(Me.txtPSPackVout)
        Me.GroupBox21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox21.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox21.Location = New System.Drawing.Point(3, 2)
        Me.GroupBox21.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox21.Name = "GroupBox21"
        Me.GroupBox21.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox21.Size = New System.Drawing.Size(141, 63)
        Me.GroupBox21.TabIndex = 0
        Me.GroupBox21.TabStop = False
        Me.GroupBox21.Text = "Output Volts"
        '
        'txtPSPackVout
        '
        Me.txtPSPackVout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPSPackVout.Location = New System.Drawing.Point(27, 25)
        Me.txtPSPackVout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPSPackVout.Name = "txtPSPackVout"
        Me.txtPSPackVout.ReadOnly = True
        Me.txtPSPackVout.Size = New System.Drawing.Size(87, 29)
        Me.txtPSPackVout.TabIndex = 0
        Me.txtPSPackVout.Text = "88.888"
        Me.txtPSPackVout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtPSPackIout)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(150, 2)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(141, 63)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Output Amps"
        '
        'txtPSPackIout
        '
        Me.txtPSPackIout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPSPackIout.Location = New System.Drawing.Point(27, 25)
        Me.txtPSPackIout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPSPackIout.Name = "txtPSPackIout"
        Me.txtPSPackIout.ReadOnly = True
        Me.txtPSPackIout.Size = New System.Drawing.Size(87, 29)
        Me.txtPSPackIout.TabIndex = 0
        Me.txtPSPackIout.Text = "88.888"
        Me.txtPSPackIout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TableLayoutPanel14
        '
        Me.TableLayoutPanel14.ColumnCount = 3
        Me.TableLayoutPanel10.SetColumnSpan(Me.TableLayoutPanel14, 2)
        Me.TableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.33784!))
        Me.TableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.40541!))
        Me.TableLayoutPanel14.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.98455!))
        Me.TableLayoutPanel14.Controls.Add(Me.Label8, 2, 3)
        Me.TableLayoutPanel14.Controls.Add(Me.udPSPackOCP, 1, 3)
        Me.TableLayoutPanel14.Controls.Add(Me.udPSPackIlimit, 1, 1)
        Me.TableLayoutPanel14.Controls.Add(Me.udPSPackVLimit, 1, 0)
        Me.TableLayoutPanel14.Controls.Add(Me.Label17, 0, 0)
        Me.TableLayoutPanel14.Controls.Add(Me.Label24, 2, 0)
        Me.TableLayoutPanel14.Controls.Add(Me.udPSPackOVP, 1, 2)
        Me.TableLayoutPanel14.Controls.Add(Me.Label23, 2, 1)
        Me.TableLayoutPanel14.Controls.Add(Me.Label18, 0, 1)
        Me.TableLayoutPanel14.Controls.Add(Me.btnPSPackEnabled, 0, 4)
        Me.TableLayoutPanel14.Controls.Add(Me.Label19, 0, 2)
        Me.TableLayoutPanel14.Controls.Add(Me.Label20, 0, 3)
        Me.TableLayoutPanel14.Controls.Add(Me.Label22, 2, 2)
        Me.TableLayoutPanel14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel14.Location = New System.Drawing.Point(3, 70)
        Me.TableLayoutPanel14.Name = "TableLayoutPanel14"
        Me.TableLayoutPanel14.RowCount = 5
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.30103!))
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.93409!))
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.39301!))
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.47516!))
        Me.TableLayoutPanel14.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29.8967!))
        Me.TableLayoutPanel14.Size = New System.Drawing.Size(288, 176)
        Me.TableLayoutPanel14.TabIndex = 1
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(235, 96)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 18)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Amps"
        '
        'udPSPackOCP
        '
        Me.udPSPackOCP.DecimalPlaces = 3
        Me.udPSPackOCP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSPackOCP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSPackOCP.Location = New System.Drawing.Point(148, 91)
        Me.udPSPackOCP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSPackOCP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSPackOCP.Name = "udPSPackOCP"
        Me.udPSPackOCP.Size = New System.Drawing.Size(81, 29)
        Me.udPSPackOCP.TabIndex = 2
        Me.udPSPackOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udPSPackIlimit
        '
        Me.udPSPackIlimit.DecimalPlaces = 3
        Me.udPSPackIlimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSPackIlimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSPackIlimit.Location = New System.Drawing.Point(148, 30)
        Me.udPSPackIlimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSPackIlimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSPackIlimit.Name = "udPSPackIlimit"
        Me.udPSPackIlimit.Size = New System.Drawing.Size(81, 29)
        Me.udPSPackIlimit.TabIndex = 2
        Me.udPSPackIlimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udPSPackVLimit
        '
        Me.udPSPackVLimit.DecimalPlaces = 3
        Me.udPSPackVLimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSPackVLimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSPackVLimit.Location = New System.Drawing.Point(148, 2)
        Me.udPSPackVLimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSPackVLimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSPackVLimit.Name = "udPSPackVLimit"
        Me.udPSPackVLimit.Size = New System.Drawing.Size(81, 29)
        Me.udPSPackVLimit.TabIndex = 1
        Me.udPSPackVLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label17
        '
        Me.Label17.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(51, 5)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(91, 18)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Voltage Limit"
        '
        'Label24
        '
        Me.Label24.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(235, 5)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(40, 18)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "Volts"
        '
        'udPSPackOVP
        '
        Me.udPSPackOVP.DecimalPlaces = 3
        Me.udPSPackOVP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSPackOVP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSPackOVP.Location = New System.Drawing.Point(148, 61)
        Me.udPSPackOVP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSPackOVP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSPackOVP.Name = "udPSPackOVP"
        Me.udPSPackOVP.Size = New System.Drawing.Size(81, 29)
        Me.udPSPackOVP.TabIndex = 2
        Me.udPSPackOVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label23
        '
        Me.Label23.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(235, 34)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(44, 18)
        Me.Label23.TabIndex = 3
        Me.Label23.Text = "Amps"
        '
        'Label18
        '
        Me.Label18.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(53, 34)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(89, 18)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Current Limit"
        '
        'btnPSPackEnabled
        '
        Me.TableLayoutPanel14.SetColumnSpan(Me.btnPSPackEnabled, 3)
        Me.btnPSPackEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnPSPackEnabled.Location = New System.Drawing.Point(20, 129)
        Me.btnPSPackEnabled.Margin = New System.Windows.Forms.Padding(20, 8, 20, 8)
        Me.btnPSPackEnabled.Name = "btnPSPackEnabled"
        Me.btnPSPackEnabled.Size = New System.Drawing.Size(248, 39)
        Me.btnPSPackEnabled.TabIndex = 1
        Me.btnPSPackEnabled.Tag = "A"
        Me.btnPSPackEnabled.Text = "Button2"
        Me.btnPSPackEnabled.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(33, 65)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(109, 18)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "OverVolt Protect"
        '
        'Label20
        '
        Me.Label20.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(13, 96)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(129, 18)
        Me.Label20.TabIndex = 4
        Me.Label20.Text = "OverCurrent Protect"
        '
        'Label22
        '
        Me.Label22.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(235, 65)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(40, 18)
        Me.Label22.TabIndex = 3
        Me.Label22.Text = "Volts"
        '
        'gbxPowerSupplyAux
        '
        Me.gbxPowerSupplyAux.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gbxPowerSupplyAux.Controls.Add(Me.TableLayoutPanel20)
        Me.gbxPowerSupplyAux.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxPowerSupplyAux.Location = New System.Drawing.Point(632, 9)
        Me.gbxPowerSupplyAux.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.gbxPowerSupplyAux.Name = "gbxPowerSupplyAux"
        Me.gbxPowerSupplyAux.Padding = New System.Windows.Forms.Padding(7)
        Me.gbxPowerSupplyAux.Size = New System.Drawing.Size(308, 285)
        Me.gbxPowerSupplyAux.TabIndex = 7
        Me.gbxPowerSupplyAux.TabStop = False
        Me.gbxPowerSupplyAux.Text = "Aux Power Supply"
        '
        'TableLayoutPanel20
        '
        Me.TableLayoutPanel20.ColumnCount = 2
        Me.TableLayoutPanel20.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel20.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel20.Controls.Add(Me.GroupBox13, 0, 0)
        Me.TableLayoutPanel20.Controls.Add(Me.GroupBox14, 1, 0)
        Me.TableLayoutPanel20.Controls.Add(Me.TableLayoutPanel21, 0, 1)
        Me.TableLayoutPanel20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel20.Location = New System.Drawing.Point(7, 29)
        Me.TableLayoutPanel20.Name = "TableLayoutPanel20"
        Me.TableLayoutPanel20.RowCount = 2
        Me.TableLayoutPanel20.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.90763!))
        Me.TableLayoutPanel20.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.09237!))
        Me.TableLayoutPanel20.Size = New System.Drawing.Size(294, 249)
        Me.TableLayoutPanel20.TabIndex = 0
        '
        'GroupBox13
        '
        Me.GroupBox13.Controls.Add(Me.txtPsAuxVout)
        Me.GroupBox13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox13.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.Location = New System.Drawing.Point(3, 2)
        Me.GroupBox13.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox13.Size = New System.Drawing.Size(141, 63)
        Me.GroupBox13.TabIndex = 0
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Output Volts"
        '
        'txtPsAuxVout
        '
        Me.txtPsAuxVout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPsAuxVout.Location = New System.Drawing.Point(27, 25)
        Me.txtPsAuxVout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPsAuxVout.Name = "txtPsAuxVout"
        Me.txtPsAuxVout.ReadOnly = True
        Me.txtPsAuxVout.Size = New System.Drawing.Size(87, 29)
        Me.txtPsAuxVout.TabIndex = 0
        Me.txtPsAuxVout.Text = "88.888"
        Me.txtPsAuxVout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.txtPsAuxIout)
        Me.GroupBox14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox14.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.Location = New System.Drawing.Point(150, 2)
        Me.GroupBox14.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox14.Size = New System.Drawing.Size(141, 63)
        Me.GroupBox14.TabIndex = 0
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Output Amps"
        '
        'txtPsAuxIout
        '
        Me.txtPsAuxIout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPsAuxIout.Location = New System.Drawing.Point(27, 25)
        Me.txtPsAuxIout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPsAuxIout.Name = "txtPsAuxIout"
        Me.txtPsAuxIout.ReadOnly = True
        Me.txtPsAuxIout.Size = New System.Drawing.Size(87, 29)
        Me.txtPsAuxIout.TabIndex = 0
        Me.txtPsAuxIout.Text = "88.888"
        Me.txtPsAuxIout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TableLayoutPanel21
        '
        Me.TableLayoutPanel21.ColumnCount = 3
        Me.TableLayoutPanel20.SetColumnSpan(Me.TableLayoutPanel21, 2)
        Me.TableLayoutPanel21.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.33784!))
        Me.TableLayoutPanel21.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30.40541!))
        Me.TableLayoutPanel21.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.98455!))
        Me.TableLayoutPanel21.Controls.Add(Me.Label21, 2, 3)
        Me.TableLayoutPanel21.Controls.Add(Me.udPSAuxOCP, 1, 3)
        Me.TableLayoutPanel21.Controls.Add(Me.udPSAuxIlimit, 1, 1)
        Me.TableLayoutPanel21.Controls.Add(Me.udPSAuxVLimit, 1, 0)
        Me.TableLayoutPanel21.Controls.Add(Me.Label33, 0, 0)
        Me.TableLayoutPanel21.Controls.Add(Me.Label34, 2, 0)
        Me.TableLayoutPanel21.Controls.Add(Me.udPSAuxOVP, 1, 2)
        Me.TableLayoutPanel21.Controls.Add(Me.Label35, 2, 1)
        Me.TableLayoutPanel21.Controls.Add(Me.Label36, 0, 1)
        Me.TableLayoutPanel21.Controls.Add(Me.btnPsAuxEnabled, 0, 4)
        Me.TableLayoutPanel21.Controls.Add(Me.Label37, 0, 2)
        Me.TableLayoutPanel21.Controls.Add(Me.Label38, 0, 3)
        Me.TableLayoutPanel21.Controls.Add(Me.Label39, 2, 2)
        Me.TableLayoutPanel21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel21.Location = New System.Drawing.Point(3, 70)
        Me.TableLayoutPanel21.Name = "TableLayoutPanel21"
        Me.TableLayoutPanel21.RowCount = 5
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.30103!))
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.93409!))
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.39301!))
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.47516!))
        Me.TableLayoutPanel21.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 29.8967!))
        Me.TableLayoutPanel21.Size = New System.Drawing.Size(288, 176)
        Me.TableLayoutPanel21.TabIndex = 1
        '
        'Label21
        '
        Me.Label21.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(235, 96)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(44, 18)
        Me.Label21.TabIndex = 5
        Me.Label21.Text = "Amps"
        '
        'udPSAuxOCP
        '
        Me.udPSAuxOCP.DecimalPlaces = 3
        Me.udPSAuxOCP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSAuxOCP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSAuxOCP.Location = New System.Drawing.Point(148, 91)
        Me.udPSAuxOCP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSAuxOCP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSAuxOCP.Name = "udPSAuxOCP"
        Me.udPSAuxOCP.Size = New System.Drawing.Size(81, 29)
        Me.udPSAuxOCP.TabIndex = 2
        Me.udPSAuxOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udPSAuxIlimit
        '
        Me.udPSAuxIlimit.DecimalPlaces = 3
        Me.udPSAuxIlimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSAuxIlimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSAuxIlimit.Location = New System.Drawing.Point(148, 30)
        Me.udPSAuxIlimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSAuxIlimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSAuxIlimit.Name = "udPSAuxIlimit"
        Me.udPSAuxIlimit.Size = New System.Drawing.Size(81, 29)
        Me.udPSAuxIlimit.TabIndex = 2
        Me.udPSAuxIlimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udPSAuxVLimit
        '
        Me.udPSAuxVLimit.DecimalPlaces = 3
        Me.udPSAuxVLimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSAuxVLimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSAuxVLimit.Location = New System.Drawing.Point(148, 2)
        Me.udPSAuxVLimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSAuxVLimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSAuxVLimit.Name = "udPSAuxVLimit"
        Me.udPSAuxVLimit.Size = New System.Drawing.Size(81, 29)
        Me.udPSAuxVLimit.TabIndex = 1
        Me.udPSAuxVLimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label33
        '
        Me.Label33.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.Location = New System.Drawing.Point(51, 5)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(91, 18)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "Voltage Limit"
        '
        'Label34
        '
        Me.Label34.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.Location = New System.Drawing.Point(235, 5)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(40, 18)
        Me.Label34.TabIndex = 3
        Me.Label34.Text = "Volts"
        '
        'udPSAuxOVP
        '
        Me.udPSAuxOVP.DecimalPlaces = 3
        Me.udPSAuxOVP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSAuxOVP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSAuxOVP.Location = New System.Drawing.Point(148, 61)
        Me.udPSAuxOVP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSAuxOVP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSAuxOVP.Name = "udPSAuxOVP"
        Me.udPSAuxOVP.Size = New System.Drawing.Size(81, 29)
        Me.udPSAuxOVP.TabIndex = 2
        Me.udPSAuxOVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label35
        '
        Me.Label35.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.Location = New System.Drawing.Point(235, 34)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(44, 18)
        Me.Label35.TabIndex = 3
        Me.Label35.Text = "Amps"
        '
        'Label36
        '
        Me.Label36.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.Location = New System.Drawing.Point(53, 34)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(89, 18)
        Me.Label36.TabIndex = 4
        Me.Label36.Text = "Current Limit"
        '
        'btnPsAuxEnabled
        '
        Me.TableLayoutPanel21.SetColumnSpan(Me.btnPsAuxEnabled, 3)
        Me.btnPsAuxEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnPsAuxEnabled.Location = New System.Drawing.Point(20, 129)
        Me.btnPsAuxEnabled.Margin = New System.Windows.Forms.Padding(20, 8, 20, 8)
        Me.btnPsAuxEnabled.Name = "btnPsAuxEnabled"
        Me.btnPsAuxEnabled.Size = New System.Drawing.Size(248, 39)
        Me.btnPsAuxEnabled.TabIndex = 1
        Me.btnPsAuxEnabled.Tag = "A"
        Me.btnPsAuxEnabled.Text = "Button2"
        Me.btnPsAuxEnabled.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.Location = New System.Drawing.Point(33, 65)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(109, 18)
        Me.Label37.TabIndex = 4
        Me.Label37.Text = "OverVolt Protect"
        '
        'Label38
        '
        Me.Label38.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.Location = New System.Drawing.Point(13, 96)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(129, 18)
        Me.Label38.TabIndex = 4
        Me.Label38.Text = "OverCurrent Protect"
        '
        'Label39
        '
        Me.Label39.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.Location = New System.Drawing.Point(235, 65)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(40, 18)
        Me.Label39.TabIndex = 3
        Me.Label39.Text = "Volts"
        '
        'gbxPowerSupplyCell
        '
        Me.gbxPowerSupplyCell.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.gbxPowerSupplyCell.Controls.Add(Me.TableLayoutPanel3)
        Me.gbxPowerSupplyCell.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxPowerSupplyCell.Location = New System.Drawing.Point(3, 9)
        Me.gbxPowerSupplyCell.Name = "gbxPowerSupplyCell"
        Me.gbxPowerSupplyCell.Size = New System.Drawing.Size(308, 285)
        Me.gbxPowerSupplyCell.TabIndex = 6
        Me.gbxPowerSupplyCell.TabStop = False
        Me.gbxPowerSupplyCell.Text = "Cell Power Supply"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.TableLayoutPanel9, 0, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.GroupBox2, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.GroupBox3, 1, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 25)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 2
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.35426!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.64574!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(302, 257)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.ColumnCount = 3
        Me.TableLayoutPanel3.SetColumnSpan(Me.TableLayoutPanel9, 2)
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.67105!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.25!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.91892!))
        Me.TableLayoutPanel9.Controls.Add(Me.udPSCellOCP, 1, 3)
        Me.TableLayoutPanel9.Controls.Add(Me.udPSCellILimit, 1, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.Label25, 0, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.udPSCellVlimit, 1, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Label26, 2, 0)
        Me.TableLayoutPanel9.Controls.Add(Me.Label27, 2, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.Label28, 0, 1)
        Me.TableLayoutPanel9.Controls.Add(Me.Label29, 0, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.btnPSCellEnabled, 0, 4)
        Me.TableLayoutPanel9.Controls.Add(Me.Label30, 0, 3)
        Me.TableLayoutPanel9.Controls.Add(Me.Label31, 2, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.udPSCellOVP, 1, 2)
        Me.TableLayoutPanel9.Controls.Add(Me.Label32, 2, 3)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(3, 73)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 5
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.57458!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.23204!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.67956!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 18.78453!))
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.38674!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(296, 181)
        Me.TableLayoutPanel9.TabIndex = 2
        '
        'udPSCellOCP
        '
        Me.udPSCellOCP.DecimalPlaces = 3
        Me.udPSCellOCP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSCellOCP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSCellOCP.Location = New System.Drawing.Point(150, 94)
        Me.udPSCellOCP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSCellOCP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSCellOCP.Name = "udPSCellOCP"
        Me.udPSCellOCP.Size = New System.Drawing.Size(86, 29)
        Me.udPSCellOCP.TabIndex = 2
        Me.udPSCellOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'udPSCellILimit
        '
        Me.udPSCellILimit.DecimalPlaces = 3
        Me.udPSCellILimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSCellILimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSCellILimit.Location = New System.Drawing.Point(150, 31)
        Me.udPSCellILimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSCellILimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSCellILimit.Name = "udPSCellILimit"
        Me.udPSCellILimit.Size = New System.Drawing.Size(86, 29)
        Me.udPSCellILimit.TabIndex = 2
        Me.udPSCellILimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(53, 5)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(91, 18)
        Me.Label25.TabIndex = 3
        Me.Label25.Text = "Voltage Limit"
        '
        'udPSCellVlimit
        '
        Me.udPSCellVlimit.DecimalPlaces = 3
        Me.udPSCellVlimit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSCellVlimit.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSCellVlimit.Location = New System.Drawing.Point(150, 2)
        Me.udPSCellVlimit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSCellVlimit.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSCellVlimit.Name = "udPSCellVlimit"
        Me.udPSCellVlimit.Size = New System.Drawing.Size(86, 29)
        Me.udPSCellVlimit.TabIndex = 1
        Me.udPSCellVlimit.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label26
        '
        Me.Label26.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(242, 5)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(40, 18)
        Me.Label26.TabIndex = 3
        Me.Label26.Text = "Volts"
        '
        'Label27
        '
        Me.Label27.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(242, 36)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(44, 18)
        Me.Label27.TabIndex = 3
        Me.Label27.Text = "Amps"
        '
        'Label28
        '
        Me.Label28.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.Location = New System.Drawing.Point(55, 36)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(89, 18)
        Me.Label28.TabIndex = 4
        Me.Label28.Text = "Current Limit"
        '
        'Label29
        '
        Me.Label29.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.Location = New System.Drawing.Point(35, 67)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(109, 18)
        Me.Label29.TabIndex = 4
        Me.Label29.Text = "OverVolt Protect"
        '
        'btnPSCellEnabled
        '
        Me.TableLayoutPanel9.SetColumnSpan(Me.btnPSCellEnabled, 3)
        Me.btnPSCellEnabled.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnPSCellEnabled.Location = New System.Drawing.Point(20, 133)
        Me.btnPSCellEnabled.Margin = New System.Windows.Forms.Padding(20, 8, 20, 8)
        Me.btnPSCellEnabled.Name = "btnPSCellEnabled"
        Me.btnPSCellEnabled.Size = New System.Drawing.Size(256, 40)
        Me.btnPSCellEnabled.TabIndex = 1
        Me.btnPSCellEnabled.Tag = "A"
        Me.btnPSCellEnabled.Text = "Button2"
        Me.btnPSCellEnabled.UseVisualStyleBackColor = True
        '
        'Label30
        '
        Me.Label30.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.Location = New System.Drawing.Point(15, 99)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(129, 18)
        Me.Label30.TabIndex = 4
        Me.Label30.Text = "OverCurrent Protect"
        '
        'Label31
        '
        Me.Label31.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.Location = New System.Drawing.Point(242, 67)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(40, 18)
        Me.Label31.TabIndex = 3
        Me.Label31.Text = "Volts"
        '
        'udPSCellOVP
        '
        Me.udPSCellOVP.DecimalPlaces = 3
        Me.udPSCellOVP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.udPSCellOVP.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.udPSCellOVP.Location = New System.Drawing.Point(150, 63)
        Me.udPSCellOVP.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.udPSCellOVP.Maximum = New Decimal(New Integer() {66, 0, 0, 0})
        Me.udPSCellOVP.Name = "udPSCellOVP"
        Me.udPSCellOVP.Size = New System.Drawing.Size(86, 29)
        Me.udPSCellOVP.TabIndex = 2
        Me.udPSCellOVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label32
        '
        Me.Label32.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(242, 99)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(44, 18)
        Me.Label32.TabIndex = 3
        Me.Label32.Text = "Amps"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtPSCellVout)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(3, 2)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(145, 66)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Output Volts"
        '
        'txtPSCellVout
        '
        Me.txtPSCellVout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPSCellVout.Location = New System.Drawing.Point(27, 25)
        Me.txtPSCellVout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPSCellVout.Name = "txtPSCellVout"
        Me.txtPSCellVout.ReadOnly = True
        Me.txtPSCellVout.Size = New System.Drawing.Size(91, 29)
        Me.txtPSCellVout.TabIndex = 0
        Me.txtPSCellVout.Text = "88.888"
        Me.txtPSCellVout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtPSCellIout)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox3.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(154, 2)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(27, 3, 27, 2)
        Me.GroupBox3.Size = New System.Drawing.Size(145, 66)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Output Amps"
        '
        'txtPSCellIout
        '
        Me.txtPSCellIout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtPSCellIout.Location = New System.Drawing.Point(27, 25)
        Me.txtPSCellIout.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPSCellIout.Name = "txtPSCellIout"
        Me.txtPSCellIout.ReadOnly = True
        Me.txtPSCellIout.Size = New System.Drawing.Size(91, 29)
        Me.txtPSCellIout.TabIndex = 0
        Me.txtPSCellIout.Text = "88.888"
        Me.txtPSCellIout.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.TableLayoutPanel4)
        Me.GroupBox7.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.Location = New System.Drawing.Point(631, 609)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(308, 299)
        Me.GroupBox7.TabIndex = 10
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Data Acquition Switching"
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.dgvDaq200a, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.dgvDaq200b, 1, 1)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 25)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 2
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 4.797048!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 95.20295!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(302, 271)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'dgvDaq200a
        '
        Me.dgvDaq200a.AllowUserToAddRows = False
        Me.dgvDaq200a.AllowUserToDeleteRows = False
        Me.dgvDaq200a.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaq200a.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewCheckBoxColumn1})
        Me.dgvDaq200a.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaq200a.Location = New System.Drawing.Point(3, 16)
        Me.dgvDaq200a.Name = "dgvDaq200a"
        Me.dgvDaq200a.ReadOnly = True
        Me.dgvDaq200a.RowHeadersVisible = False
        Me.dgvDaq200a.RowHeadersWidth = 12
        Me.dgvDaq200a.Size = New System.Drawing.Size(145, 252)
        Me.dgvDaq200a.TabIndex = 3
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewTextBoxColumn1.DefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridViewTextBoxColumn1.HeaderText = "Channel"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.DataGridViewTextBoxColumn1.Width = 83
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewCheckBoxColumn1.HeaderText = "State"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        Me.DataGridViewCheckBoxColumn1.ReadOnly = True
        Me.DataGridViewCheckBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewCheckBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'dgvDaq200b
        '
        Me.dgvDaq200b.AllowUserToAddRows = False
        Me.dgvDaq200b.AllowUserToDeleteRows = False
        Me.dgvDaq200b.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDaq200b.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewComboBoxColumn1, Me.State})
        Me.dgvDaq200b.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvDaq200b.Location = New System.Drawing.Point(154, 16)
        Me.dgvDaq200b.Name = "dgvDaq200b"
        Me.dgvDaq200b.ReadOnly = True
        Me.dgvDaq200b.RowHeadersVisible = False
        Me.dgvDaq200b.RowHeadersWidth = 12
        Me.dgvDaq200b.Size = New System.Drawing.Size(145, 252)
        Me.dgvDaq200b.TabIndex = 1
        '
        'DataGridViewComboBoxColumn1
        '
        Me.DataGridViewComboBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DataGridViewComboBoxColumn1.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridViewComboBoxColumn1.HeaderText = "Channel"
        Me.DataGridViewComboBoxColumn1.Name = "DataGridViewComboBoxColumn1"
        Me.DataGridViewComboBoxColumn1.ReadOnly = True
        Me.DataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic
        Me.DataGridViewComboBoxColumn1.Width = 83
        '
        'State
        '
        Me.State.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.State.HeaderText = "State"
        Me.State.Name = "State"
        Me.State.ReadOnly = True
        Me.State.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.State.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'GroupBox12
        '
        Me.TableLayoutPanelEquipmentControl.SetColumnSpan(Me.GroupBox12, 2)
        Me.GroupBox12.Controls.Add(Me.tlpRelayIndi)
        Me.GroupBox12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox12.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.Location = New System.Drawing.Point(3, 608)
        Me.GroupBox12.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox12.Size = New System.Drawing.Size(622, 301)
        Me.GroupBox12.TabIndex = 11
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "Relay Control"
        '
        'tlpRelayIndi
        '
        Me.tlpRelayIndi.ColumnCount = 8
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit18, 2, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit17, 1, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit16, 0, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit8, 0, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit7, 7, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit9, 1, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit4, 4, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit10, 2, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit6, 6, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit11, 3, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit19, 3, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit14, 6, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit12, 4, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit20, 4, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit13, 5, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit21, 5, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit5, 5, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit2, 2, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit22, 6, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit1, 1, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit23, 7, 2)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit15, 7, 1)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit3, 3, 0)
        Me.tlpRelayIndi.Controls.Add(Me.btnRelayBit0, 0, 0)
        Me.tlpRelayIndi.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpRelayIndi.Location = New System.Drawing.Point(3, 24)
        Me.tlpRelayIndi.Name = "tlpRelayIndi"
        Me.tlpRelayIndi.RowCount = 3
        Me.tlpRelayIndi.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpRelayIndi.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpRelayIndi.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpRelayIndi.Size = New System.Drawing.Size(616, 275)
        Me.tlpRelayIndi.TabIndex = 1
        '
        'btnRelayBit18
        '
        Me.btnRelayBit18.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit18.Location = New System.Drawing.Point(158, 186)
        Me.btnRelayBit18.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit18.Name = "btnRelayBit18"
        Me.btnRelayBit18.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit18.TabIndex = 4
        Me.btnRelayBit18.Text = "PS Select"
        Me.btnRelayBit18.UseVisualStyleBackColor = True
        '
        'btnRelayBit17
        '
        Me.btnRelayBit17.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit17.Location = New System.Drawing.Point(81, 186)
        Me.btnRelayBit17.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit17.Name = "btnRelayBit17"
        Me.btnRelayBit17.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit17.TabIndex = 3
        Me.btnRelayBit17.Text = "Eload Select"
        Me.btnRelayBit17.UseVisualStyleBackColor = True
        '
        'btnRelayBit16
        '
        Me.btnRelayBit16.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit16.Location = New System.Drawing.Point(4, 186)
        Me.btnRelayBit16.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit16.Name = "btnRelayBit16"
        Me.btnRelayBit16.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit16.TabIndex = 7
        Me.btnRelayBit16.Text = "Low Shunt Enable"
        Me.btnRelayBit16.UseVisualStyleBackColor = True
        '
        'btnRelayBit8
        '
        Me.btnRelayBit8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit8.Location = New System.Drawing.Point(4, 95)
        Me.btnRelayBit8.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit8.Name = "btnRelayBit8"
        Me.btnRelayBit8.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit8.TabIndex = 7
        Me.btnRelayBit8.Text = "Bal En 0"
        Me.btnRelayBit8.UseVisualStyleBackColor = True
        '
        'btnRelayBit7
        '
        Me.btnRelayBit7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit7.Location = New System.Drawing.Point(543, 4)
        Me.btnRelayBit7.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit7.Name = "btnRelayBit7"
        Me.btnRelayBit7.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit7.TabIndex = 4
        Me.btnRelayBit7.Text = "A8"
        Me.btnRelayBit7.UseVisualStyleBackColor = True
        '
        'btnRelayBit9
        '
        Me.btnRelayBit9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit9.Location = New System.Drawing.Point(81, 95)
        Me.btnRelayBit9.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit9.Name = "btnRelayBit9"
        Me.btnRelayBit9.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit9.TabIndex = 3
        Me.btnRelayBit9.Text = "Bal En 1"
        Me.btnRelayBit9.UseVisualStyleBackColor = True
        '
        'btnRelayBit4
        '
        Me.btnRelayBit4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit4.Location = New System.Drawing.Point(312, 4)
        Me.btnRelayBit4.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit4.Name = "btnRelayBit4"
        Me.btnRelayBit4.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit4.TabIndex = 7
        Me.btnRelayBit4.Text = "A5"
        Me.btnRelayBit4.UseVisualStyleBackColor = True
        '
        'btnRelayBit10
        '
        Me.btnRelayBit10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit10.Location = New System.Drawing.Point(158, 95)
        Me.btnRelayBit10.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit10.Name = "btnRelayBit10"
        Me.btnRelayBit10.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit10.TabIndex = 4
        Me.btnRelayBit10.Text = "Bal En 2"
        Me.btnRelayBit10.UseVisualStyleBackColor = True
        '
        'btnRelayBit6
        '
        Me.btnRelayBit6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit6.Location = New System.Drawing.Point(466, 4)
        Me.btnRelayBit6.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit6.Name = "btnRelayBit6"
        Me.btnRelayBit6.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit6.TabIndex = 5
        Me.btnRelayBit6.Text = "A7"
        Me.btnRelayBit6.UseVisualStyleBackColor = True
        '
        'btnRelayBit11
        '
        Me.btnRelayBit11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit11.Location = New System.Drawing.Point(235, 95)
        Me.btnRelayBit11.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit11.Name = "btnRelayBit11"
        Me.btnRelayBit11.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit11.TabIndex = 5
        Me.btnRelayBit11.Text = "Bal En 3"
        Me.btnRelayBit11.UseVisualStyleBackColor = True
        '
        'btnRelayBit19
        '
        Me.btnRelayBit19.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit19.Location = New System.Drawing.Point(235, 186)
        Me.btnRelayBit19.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit19.Name = "btnRelayBit19"
        Me.btnRelayBit19.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit19.TabIndex = 1
        Me.btnRelayBit19.Text = "12V Enable"
        Me.btnRelayBit19.UseVisualStyleBackColor = True
        '
        'btnRelayBit14
        '
        Me.btnRelayBit14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit14.Location = New System.Drawing.Point(466, 95)
        Me.btnRelayBit14.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit14.Name = "btnRelayBit14"
        Me.btnRelayBit14.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit14.TabIndex = 1
        Me.btnRelayBit14.Text = "D14"
        Me.btnRelayBit14.UseVisualStyleBackColor = True
        '
        'btnRelayBit12
        '
        Me.btnRelayBit12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit12.Location = New System.Drawing.Point(312, 95)
        Me.btnRelayBit12.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit12.Name = "btnRelayBit12"
        Me.btnRelayBit12.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit12.TabIndex = 2
        Me.btnRelayBit12.Text = "B5"
        Me.btnRelayBit12.UseVisualStyleBackColor = True
        '
        'btnRelayBit20
        '
        Me.btnRelayBit20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit20.Location = New System.Drawing.Point(312, 186)
        Me.btnRelayBit20.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit20.Name = "btnRelayBit20"
        Me.btnRelayBit20.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit20.TabIndex = 5
        Me.btnRelayBit20.Text = "Spare 1"
        Me.btnRelayBit20.UseVisualStyleBackColor = True
        '
        'btnRelayBit13
        '
        Me.btnRelayBit13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit13.Location = New System.Drawing.Point(389, 95)
        Me.btnRelayBit13.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit13.Name = "btnRelayBit13"
        Me.btnRelayBit13.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit13.TabIndex = 6
        Me.btnRelayBit13.Text = "B6"
        Me.btnRelayBit13.UseVisualStyleBackColor = True
        '
        'btnRelayBit21
        '
        Me.btnRelayBit21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit21.Location = New System.Drawing.Point(389, 186)
        Me.btnRelayBit21.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit21.Name = "btnRelayBit21"
        Me.btnRelayBit21.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit21.TabIndex = 2
        Me.btnRelayBit21.Text = "Spare 2"
        Me.btnRelayBit21.UseVisualStyleBackColor = True
        '
        'btnRelayBit5
        '
        Me.btnRelayBit5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit5.Location = New System.Drawing.Point(389, 4)
        Me.btnRelayBit5.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit5.Name = "btnRelayBit5"
        Me.btnRelayBit5.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit5.TabIndex = 6
        Me.btnRelayBit5.Text = "A6"
        Me.btnRelayBit5.UseVisualStyleBackColor = True
        '
        'btnRelayBit2
        '
        Me.btnRelayBit2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit2.Location = New System.Drawing.Point(158, 4)
        Me.btnRelayBit2.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit2.Name = "btnRelayBit2"
        Me.btnRelayBit2.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit2.TabIndex = 3
        Me.btnRelayBit2.Text = "Cell Count 2"
        Me.btnRelayBit2.UseVisualStyleBackColor = True
        '
        'btnRelayBit22
        '
        Me.btnRelayBit22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit22.Location = New System.Drawing.Point(466, 186)
        Me.btnRelayBit22.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit22.Name = "btnRelayBit22"
        Me.btnRelayBit22.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit22.TabIndex = 6
        Me.btnRelayBit22.Text = "Spare 3"
        Me.btnRelayBit22.UseVisualStyleBackColor = True
        '
        'btnRelayBit1
        '
        Me.btnRelayBit1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit1.Location = New System.Drawing.Point(81, 4)
        Me.btnRelayBit1.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit1.Name = "btnRelayBit1"
        Me.btnRelayBit1.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit1.TabIndex = 1
        Me.btnRelayBit1.Text = "Cell Count 1"
        Me.btnRelayBit1.UseVisualStyleBackColor = True
        '
        'btnRelayBit23
        '
        Me.btnRelayBit23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit23.Location = New System.Drawing.Point(543, 186)
        Me.btnRelayBit23.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit23.Name = "btnRelayBit23"
        Me.btnRelayBit23.Size = New System.Drawing.Size(69, 85)
        Me.btnRelayBit23.TabIndex = 0
        Me.btnRelayBit23.Text = "Spare 4"
        Me.btnRelayBit23.UseVisualStyleBackColor = True
        '
        'btnRelayBit15
        '
        Me.btnRelayBit15.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit15.Location = New System.Drawing.Point(543, 95)
        Me.btnRelayBit15.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit15.Name = "btnRelayBit15"
        Me.btnRelayBit15.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit15.TabIndex = 0
        Me.btnRelayBit15.Text = "B8"
        Me.btnRelayBit15.UseVisualStyleBackColor = True
        '
        'btnRelayBit3
        '
        Me.btnRelayBit3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit3.Location = New System.Drawing.Point(235, 4)
        Me.btnRelayBit3.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit3.Name = "btnRelayBit3"
        Me.btnRelayBit3.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit3.TabIndex = 2
        Me.btnRelayBit3.Text = "Cell Count 3"
        Me.btnRelayBit3.UseVisualStyleBackColor = True
        '
        'btnRelayBit0
        '
        Me.btnRelayBit0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRelayBit0.Location = New System.Drawing.Point(4, 4)
        Me.btnRelayBit0.Margin = New System.Windows.Forms.Padding(4)
        Me.btnRelayBit0.Name = "btnRelayBit0"
        Me.btnRelayBit0.Size = New System.Drawing.Size(69, 83)
        Me.btnRelayBit0.TabIndex = 0
        Me.btnRelayBit0.Text = "Cell Count 0"
        Me.btnRelayBit0.UseVisualStyleBackColor = True
        '
        'tpgMeter
        '
        Me.tpgMeter.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpgMeter.Controls.Add(Me.GroupBox15)
        Me.tpgMeter.Location = New System.Drawing.Point(4, 40)
        Me.tpgMeter.Margin = New System.Windows.Forms.Padding(4)
        Me.tpgMeter.Name = "tpgMeter"
        Me.tpgMeter.Padding = New System.Windows.Forms.Padding(4)
        Me.tpgMeter.Size = New System.Drawing.Size(952, 919)
        Me.tpgMeter.TabIndex = 1
        Me.tpgMeter.Tag = "DAQ"
        Me.tpgMeter.Text = "Metering"
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.tlpDaqMonitor)
        Me.GroupBox15.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox15.Location = New System.Drawing.Point(29, 25)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(885, 758)
        Me.GroupBox15.TabIndex = 7
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "Data Acquition"
        '
        'tlpDaqMonitor
        '
        Me.tlpDaqMonitor.ColumnCount = 3
        Me.tlpDaqMonitor.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpDaqMonitor.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpDaqMonitor.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.tlpDaqMonitor.Controls.Add(Me.btnSendDaqConfig, 0, 0)
        Me.tlpDaqMonitor.Controls.Add(Me.btnResetDAQ, 2, 0)
        Me.tlpDaqMonitor.Controls.Add(Me.btnScanDaq, 1, 0)
        Me.tlpDaqMonitor.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpDaqMonitor.Location = New System.Drawing.Point(3, 25)
        Me.tlpDaqMonitor.Name = "tlpDaqMonitor"
        Me.tlpDaqMonitor.RowCount = 2
        Me.tlpDaqMonitor.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.2807!))
        Me.tlpDaqMonitor.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.7193!))
        Me.tlpDaqMonitor.Size = New System.Drawing.Size(879, 730)
        Me.tlpDaqMonitor.TabIndex = 0
        '
        'btnScanDaq
        '
        Me.btnScanDaq.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnScanDaq.Location = New System.Drawing.Point(338, 25)
        Me.btnScanDaq.Name = "btnScanDaq"
        Me.btnScanDaq.Size = New System.Drawing.Size(202, 39)
        Me.btnScanDaq.TabIndex = 3
        Me.btnScanDaq.Text = "Scan DAQ"
        Me.btnScanDaq.UseVisualStyleBackColor = True
        '
        'tpgDataComm
        '
        Me.tpgDataComm.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.tpgDataComm.Controls.Add(Me.SplitContainer3)
        Me.tpgDataComm.Location = New System.Drawing.Point(4, 36)
        Me.tpgDataComm.Margin = New System.Windows.Forms.Padding(4)
        Me.tpgDataComm.Name = "tpgDataComm"
        Me.tpgDataComm.Padding = New System.Windows.Forms.Padding(4)
        Me.tpgDataComm.Size = New System.Drawing.Size(952, 923)
        Me.tpgDataComm.TabIndex = 3
        Me.tpgDataComm.Text = "Data Comm"
        '
        'SplitContainer3
        '
        Me.SplitContainer3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer3.Location = New System.Drawing.Point(4, 4)
        Me.SplitContainer3.Name = "SplitContainer3"
        '
        'SplitContainer3.Panel1
        '
        Me.SplitContainer3.Panel1.Controls.Add(Me.dgvUtility)
        '
        'SplitContainer3.Panel2
        '
        Me.SplitContainer3.Panel2.Controls.Add(Me.btnBreak)
        Me.SplitContainer3.Panel2.Controls.Add(Me.Button27)
        Me.SplitContainer3.Panel2.Controls.Add(Me.btnDisplayI2CCommands)
        Me.SplitContainer3.Size = New System.Drawing.Size(944, 915)
        Me.SplitContainer3.SplitterDistance = 685
        Me.SplitContainer3.TabIndex = 1
        '
        'dgvUtility
        '
        Me.dgvUtility.AllowUserToAddRows = False
        Me.dgvUtility.AllowUserToDeleteRows = False
        Me.dgvUtility.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvUtility.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgvUtility.Location = New System.Drawing.Point(0, 0)
        Me.dgvUtility.Name = "dgvUtility"
        Me.dgvUtility.ReadOnly = True
        Me.dgvUtility.Size = New System.Drawing.Size(685, 915)
        Me.dgvUtility.TabIndex = 1
        '
        'btnBreak
        '
        Me.btnBreak.Location = New System.Drawing.Point(45, 189)
        Me.btnBreak.Name = "btnBreak"
        Me.btnBreak.Size = New System.Drawing.Size(115, 69)
        Me.btnBreak.TabIndex = 0
        Me.btnBreak.Text = "Step into App"
        Me.btnBreak.UseVisualStyleBackColor = True
        '
        'Button27
        '
        Me.Button27.Enabled = False
        Me.Button27.Location = New System.Drawing.Point(45, 103)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(115, 69)
        Me.Button27.TabIndex = 0
        Me.Button27.Text = "Display SMB Commands"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'btnDisplayI2CCommands
        '
        Me.btnDisplayI2CCommands.Location = New System.Drawing.Point(45, 18)
        Me.btnDisplayI2CCommands.Name = "btnDisplayI2CCommands"
        Me.btnDisplayI2CCommands.Size = New System.Drawing.Size(115, 69)
        Me.btnDisplayI2CCommands.TabIndex = 0
        Me.btnDisplayI2CCommands.Text = "Display I2C Commands"
        Me.btnDisplayI2CCommands.UseVisualStyleBackColor = True
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 65)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.txtMessaqeLog)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.TableLayoutPanel7)
        Me.SplitContainer2.Size = New System.Drawing.Size(494, 883)
        Me.SplitContainer2.SplitterDistance = 459
        Me.SplitContainer2.TabIndex = 5
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60.47746!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 39.52254!))
        Me.TableLayoutPanel7.Controls.Add(Me.GroupBox11, 1, 1)
        Me.TableLayoutPanel7.Controls.Add(Me.gbxStartIndicators, 0, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.GroupBox10, 0, 1)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowCount = 4
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.38095!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.38095!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(494, 420)
        Me.TableLayoutPanel7.TabIndex = 2
        '
        'GroupBox11
        '
        Me.GroupBox11.Controls.Add(Me.TableLayoutPanel8)
        Me.GroupBox11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox11.Location = New System.Drawing.Point(301, 108)
        Me.GroupBox11.Name = "GroupBox11"
        Me.TableLayoutPanel7.SetRowSpan(Me.GroupBox11, 3)
        Me.GroupBox11.Size = New System.Drawing.Size(190, 309)
        Me.GroupBox11.TabIndex = 1
        Me.GroupBox11.TabStop = False
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 2
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel8.Controls.Add(Me.txtTotal, 1, 0)
        Me.TableLayoutPanel8.Controls.Add(Me.txtPass, 1, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.txtFail, 1, 2)
        Me.TableLayoutPanel8.Controls.Add(Me.Label2, 0, 0)
        Me.TableLayoutPanel8.Controls.Add(Me.Label3, 0, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.Label4, 0, 2)
        Me.TableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(3, 21)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 3
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(184, 285)
        Me.TableLayoutPanel8.TabIndex = 2
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtTotal.ForeColor = System.Drawing.Color.Blue
        Me.txtTotal.Location = New System.Drawing.Point(95, 35)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(62, 25)
        Me.txtTotal.TabIndex = 1
        Me.txtTotal.Text = "]"
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPass
        '
        Me.txtPass.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtPass.ForeColor = System.Drawing.Color.DarkGreen
        Me.txtPass.Location = New System.Drawing.Point(95, 130)
        Me.txtPass.Name = "txtPass"
        Me.txtPass.ReadOnly = True
        Me.txtPass.Size = New System.Drawing.Size(62, 25)
        Me.txtPass.TabIndex = 1
        Me.txtPass.Text = "]"
        Me.txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtFail
        '
        Me.txtFail.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtFail.ForeColor = System.Drawing.Color.DarkRed
        Me.txtFail.Location = New System.Drawing.Point(95, 225)
        Me.txtFail.Name = "txtFail"
        Me.txtFail.ReadOnly = True
        Me.txtFail.Size = New System.Drawing.Size(62, 25)
        Me.txtFail.TabIndex = 1
        Me.txtFail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Blue
        Me.Label2.Location = New System.Drawing.Point(53, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 17)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Total"
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label3.Location = New System.Drawing.Point(55, 134)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Pass"
        '
        'Label4
        '
        Me.Label4.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.DarkRed
        Me.Label4.Location = New System.Drawing.Point(62, 229)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(27, 17)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Fail"
        '
        'gbxStartIndicators
        '
        Me.TableLayoutPanel7.SetColumnSpan(Me.gbxStartIndicators, 2)
        Me.gbxStartIndicators.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxStartIndicators.Font = New System.Drawing.Font("Georgia", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbxStartIndicators.Location = New System.Drawing.Point(3, 3)
        Me.gbxStartIndicators.Name = "gbxStartIndicators"
        Me.gbxStartIndicators.Size = New System.Drawing.Size(488, 99)
        Me.gbxStartIndicators.TabIndex = 2
        Me.gbxStartIndicators.TabStop = False
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.btnTestStuff)
        Me.GroupBox10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox10.Location = New System.Drawing.Point(3, 108)
        Me.GroupBox10.Name = "GroupBox10"
        Me.TableLayoutPanel7.SetRowSpan(Me.GroupBox10, 3)
        Me.GroupBox10.Size = New System.Drawing.Size(292, 309)
        Me.GroupBox10.TabIndex = 3
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "EVENT Table"
        '
        'btnTestStuff
        '
        Me.btnTestStuff.Location = New System.Drawing.Point(76, 108)
        Me.btnTestStuff.Name = "btnTestStuff"
        Me.btnTestStuff.Size = New System.Drawing.Size(130, 88)
        Me.btnTestStuff.TabIndex = 0
        Me.btnTestStuff.Text = "Test Stuff"
        Me.btnTestStuff.UseVisualStyleBackColor = True
        '
        'tmrScanInstruments
        '
        Me.tmrScanInstruments.Interval = 2000
        '
        'DaqControlDataSet
        '
        Me.DaqControlDataSet.DataSetName = "DaqControlDataSet"
        Me.DaqControlDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'frmTestSetControl
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1474, 987)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmTestSetControl"
        Me.Text = "frmTestSetControl"
        Me.ctxMonitor.ResumeLayout(False)
        Me.ctzMeterGrid.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tpgEnvironment.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.dgvEnvPallet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tpgMonitor.ResumeLayout(False)
        Me.TableLayoutPanelEquipmentControl.ResumeLayout(False)
        Me.gbxELoadPack.ResumeLayout(False)
        Me.TableLayoutPanel16.ResumeLayout(False)
        Me.GroupBox30.ResumeLayout(False)
        Me.TableLayoutPanel17.ResumeLayout(False)
        Me.TableLayoutPanel17.PerformLayout()
        CType(Me.udELPackCRohms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELPackCCamps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELPackCVvolts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELPackCPwatts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel18.ResumeLayout(False)
        Me.TableLayoutPanel18.PerformLayout()
        Me.TableLayoutPanel19.ResumeLayout(False)
        Me.GroupBox31.ResumeLayout(False)
        Me.GroupBox31.PerformLayout()
        Me.GroupBox32.ResumeLayout(False)
        Me.GroupBox32.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.gbxELoadCell.ResumeLayout(False)
        Me.TableLayoutPanel11.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.TableLayoutPanel12.ResumeLayout(False)
        Me.TableLayoutPanel12.PerformLayout()
        CType(Me.udELCellCRohms, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELCellCCamps, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELCellCVvolts, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udELCellCPwatts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel13.ResumeLayout(False)
        Me.TableLayoutPanel13.PerformLayout()
        Me.TableLayoutPanel15.ResumeLayout(False)
        Me.GroupBox25.ResumeLayout(False)
        Me.GroupBox25.PerformLayout()
        Me.GroupBox24.ResumeLayout(False)
        Me.GroupBox24.PerformLayout()
        Me.GroupBox23.ResumeLayout(False)
        Me.GroupBox23.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.gbxPowerSupplyPack.ResumeLayout(False)
        Me.TableLayoutPanel10.ResumeLayout(False)
        Me.GroupBox21.ResumeLayout(False)
        Me.GroupBox21.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TableLayoutPanel14.ResumeLayout(False)
        Me.TableLayoutPanel14.PerformLayout()
        CType(Me.udPSPackOCP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSPackIlimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSPackVLimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSPackOVP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxPowerSupplyAux.ResumeLayout(False)
        Me.TableLayoutPanel20.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.TableLayoutPanel21.ResumeLayout(False)
        Me.TableLayoutPanel21.PerformLayout()
        CType(Me.udPSAuxOCP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSAuxIlimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSAuxVLimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSAuxOVP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxPowerSupplyCell.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.TableLayoutPanel9.PerformLayout()
        CType(Me.udPSCellOCP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSCellILimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSCellVlimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.udPSCellOVP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        CType(Me.dgvDaq200a, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvDaq200b, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox12.ResumeLayout(False)
        Me.tlpRelayIndi.ResumeLayout(False)
        Me.tpgMeter.ResumeLayout(False)
        Me.GroupBox15.ResumeLayout(False)
        Me.tlpDaqMonitor.ResumeLayout(False)
        Me.tpgDataComm.ResumeLayout(False)
        Me.SplitContainer3.Panel1.ResumeLayout(False)
        Me.SplitContainer3.Panel2.ResumeLayout(False)
        Me.SplitContainer3.ResumeLayout(False)
        CType(Me.dgvUtility, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        Me.SplitContainer2.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.TableLayoutPanel8.PerformLayout()
        Me.GroupBox10.ResumeLayout(False)
        CType(Me.DaqControlDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dlgBqEVSW As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SendI2CUnsealCodesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents LocateBqEVSWExecutableFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents I2COperationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SmbShutdownToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendSMBUnsealToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FuelGaugeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenBqEVSWToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SMBusOperationsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CommunicationTraceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EV2300CommToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DAQCommToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PowerSupply1ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PowerSupply2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ElectronicLoadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents I2C5VControlToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VEnableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VDisableToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenConfigDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveCSVFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents SaveXMLFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ctxMonitor As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuSetRefreshIntervalTop As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ctzMeterGrid As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents mnuResetDaqGrid As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SelectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UnselectAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveUncheckedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteSelectedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopyToClipboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtMessaqeLog As System.Windows.Forms.RichTextBox
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenConfigurationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents TableLayoutPanel7 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents TableLayoutPanel8 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtPass As System.Windows.Forms.TextBox
    Friend WithEvents txtFail As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents tmrScanInstruments As System.Windows.Forms.Timer
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents mnuScanAllItems As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents gbxStartIndicators As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents mnuScanAllItemsContext As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents txtRefreshInterval As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents btnTestStuff As Button
    Friend WithEvents ShowBq76940ControlScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TestingToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents tpgTesting As TabPage
    Friend WithEvents tpgEnvironment As TabPage
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents dgvEnvPallet1 As DataGridView
    Friend WithEvents tpgMonitor As TabPage
    Friend WithEvents TableLayoutPanelEquipmentControl As TableLayoutPanel
    Friend WithEvents gbxELoadPack As GroupBox
    Friend WithEvents TableLayoutPanel16 As TableLayoutPanel
    Friend WithEvents GroupBox30 As GroupBox
    Friend WithEvents TableLayoutPanel17 As TableLayoutPanel
    Friend WithEvents radELPackModeCC As RadioButton
    Friend WithEvents radELPackModeCV As RadioButton
    Friend WithEvents Label13 As Label
    Friend WithEvents radELPackModeCP As RadioButton
    Friend WithEvents Label14 As Label
    Friend WithEvents radELPackModeCR As RadioButton
    Friend WithEvents Label15 As Label
    Friend WithEvents udELPackCRohms As NumericUpDown
    Friend WithEvents Label16 As Label
    Friend WithEvents udELPackCCamps As NumericUpDown
    Friend WithEvents udELPackCVvolts As NumericUpDown
    Friend WithEvents udELPackCPwatts As NumericUpDown
    Friend WithEvents TableLayoutPanel18 As TableLayoutPanel
    Friend WithEvents chkELPackShort As CheckBox
    Friend WithEvents btnELPackEnabled As Button
    Friend WithEvents TableLayoutPanel19 As TableLayoutPanel
    Friend WithEvents GroupBox31 As GroupBox
    Friend WithEvents txtELPackRin As TextBox
    Friend WithEvents GroupBox32 As GroupBox
    Friend WithEvents txtELPackPin As TextBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents txtELPackVin As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents txtELPackIin As TextBox
    Friend WithEvents gbxELoadCell As GroupBox
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents radELCellModeCC As RadioButton
    Friend WithEvents radELCellModeCV As RadioButton
    Friend WithEvents Label9 As Label
    Friend WithEvents radELCellModeCP As RadioButton
    Friend WithEvents Label10 As Label
    Friend WithEvents radELCellModeCR As RadioButton
    Friend WithEvents Label11 As Label
    Friend WithEvents udELCellCRohms As NumericUpDown
    Friend WithEvents Label12 As Label
    Friend WithEvents udELCellCCamps As NumericUpDown
    Friend WithEvents udELCellCVvolts As NumericUpDown
    Friend WithEvents udELCellCPwatts As NumericUpDown
    Friend WithEvents TableLayoutPanel13 As TableLayoutPanel
    Friend WithEvents chkELCellShort As CheckBox
    Friend WithEvents btnELCellEnabled As Button
    Friend WithEvents TableLayoutPanel15 As TableLayoutPanel
    Friend WithEvents GroupBox25 As GroupBox
    Friend WithEvents txtELCellRin As TextBox
    Friend WithEvents GroupBox24 As GroupBox
    Friend WithEvents txtELCellPin As TextBox
    Friend WithEvents GroupBox23 As GroupBox
    Friend WithEvents txtELCellVin As TextBox
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents txtELCellIin As TextBox
    Friend WithEvents gbxPowerSupplyPack As GroupBox
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents GroupBox21 As GroupBox
    Friend WithEvents txtPSPackVout As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtPSPackIout As TextBox
    Friend WithEvents TableLayoutPanel14 As TableLayoutPanel
    Friend WithEvents Label8 As Label
    Friend WithEvents udPSPackOCP As NumericUpDown
    Friend WithEvents udPSPackIlimit As NumericUpDown
    Friend WithEvents udPSPackVLimit As NumericUpDown
    Friend WithEvents Label17 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents udPSPackOVP As NumericUpDown
    Friend WithEvents Label23 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents btnPSPackEnabled As Button
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents gbxPowerSupplyAux As GroupBox
    Friend WithEvents TableLayoutPanel20 As TableLayoutPanel
    Friend WithEvents GroupBox13 As GroupBox
    Friend WithEvents txtPsAuxVout As TextBox
    Friend WithEvents GroupBox14 As GroupBox
    Friend WithEvents txtPsAuxIout As TextBox
    Friend WithEvents TableLayoutPanel21 As TableLayoutPanel
    Friend WithEvents Label21 As Label
    Friend WithEvents udPSAuxOCP As NumericUpDown
    Friend WithEvents udPSAuxIlimit As NumericUpDown
    Friend WithEvents udPSAuxVLimit As NumericUpDown
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents udPSAuxOVP As NumericUpDown
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents btnPsAuxEnabled As Button
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents gbxPowerSupplyCell As GroupBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents udPSCellOCP As NumericUpDown
    Friend WithEvents udPSCellILimit As NumericUpDown
    Friend WithEvents Label25 As Label
    Friend WithEvents udPSCellVlimit As NumericUpDown
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Label29 As Label
    Friend WithEvents btnPSCellEnabled As Button
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents udPSCellOVP As NumericUpDown
    Friend WithEvents Label32 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents txtPSCellVout As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtPSCellIout As TextBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents dgvDaq200a As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Friend WithEvents dgvDaq200b As DataGridView
    Friend WithEvents DataGridViewComboBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents State As DataGridViewCheckBoxColumn
    Friend WithEvents GroupBox12 As GroupBox
    Friend WithEvents tlpRelayIndi As TableLayoutPanel
    Friend WithEvents btnRelayBit18 As Button
    Friend WithEvents btnRelayBit17 As Button
    Friend WithEvents btnRelayBit16 As Button
    Friend WithEvents btnRelayBit8 As Button
    Friend WithEvents btnRelayBit7 As Button
    Friend WithEvents btnRelayBit9 As Button
    Friend WithEvents btnRelayBit4 As Button
    Friend WithEvents btnRelayBit10 As Button
    Friend WithEvents btnRelayBit6 As Button
    Friend WithEvents btnRelayBit11 As Button
    Friend WithEvents btnRelayBit19 As Button
    Friend WithEvents btnRelayBit14 As Button
    Friend WithEvents btnRelayBit12 As Button
    Friend WithEvents btnRelayBit20 As Button
    Friend WithEvents btnRelayBit13 As Button
    Friend WithEvents btnRelayBit21 As Button
    Friend WithEvents btnRelayBit5 As Button
    Friend WithEvents btnRelayBit2 As Button
    Friend WithEvents btnRelayBit22 As Button
    Friend WithEvents btnRelayBit1 As Button
    Friend WithEvents btnRelayBit23 As Button
    Friend WithEvents btnRelayBit15 As Button
    Friend WithEvents btnRelayBit3 As Button
    Friend WithEvents btnRelayBit0 As Button
    Friend WithEvents tpgMeter As TabPage
    Friend WithEvents tpgDataComm As TabPage
    Friend WithEvents SplitContainer3 As SplitContainer
    Friend WithEvents dgvUtility As DataGridView
    Friend WithEvents btnBreak As Button
    Friend WithEvents Button27 As Button
    Friend WithEvents btnDisplayI2CCommands As Button
    Friend WithEvents GroupBox15 As GroupBox
    Friend WithEvents tlpDaqMonitor As TableLayoutPanel
    Friend WithEvents btnSendDaqConfig As Button
    Friend WithEvents btnResetDAQ As Button
    Friend WithEvents DaqControlDataSet As DaqControlDataSet
    Friend WithEvents btnScanDaq As Button
End Class
