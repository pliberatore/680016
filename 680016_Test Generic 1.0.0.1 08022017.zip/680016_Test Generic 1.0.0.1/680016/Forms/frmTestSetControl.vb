﻿Public Class frmTestSetControl


    Private ReadInProgress As Boolean ' Indicates a full PS read is happening. Used for updown.Change events

    Private ELoadCellModeIndicators As New Collection
    Private ELoadPackModeIndicators As New Collection
    Private RelayButtonIndicators As New Collection

    Private Sub frmTestSetControl_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
       With TestSetControl
            If .PsCell IsNot Nothing Then .PsCell.IsEnabled = False
            If .PsPack IsNot Nothing Then .PsPack.IsEnabled = False
            If .PSAux IsNot Nothing Then .PSAux.IsEnabled = False
            If .ELoadCell IsNot Nothing Then .ELoadCell.InputEnabledState = False
            If .EloadPack IsNot Nothing Then .EloadPack.InputEnabledState = False
        End With
    End Sub
    Private WithEvents btnSetupErrorIndicator As Button
    Private Sub frmTestSetControl_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        ' Basic housekeepping setup
        With ELoadCellModeIndicators
            .Add(Me.radELCellModeCC)
            .Add(Me.radELCellModeCP)
            .Add(Me.radELCellModeCR)
            .Add(Me.radELCellModeCV)
        End With
        With ELoadPackModeIndicators
            .Add(Me.radELPackModeCC)
            .Add(Me.radELPackModeCP)
            .Add(Me.radELPackModeCR)
            .Add(Me.radELPackModeCV)
        End With
        'Set each relay button caption with its function
        btnRelayBit0.Text = clsRelayDriver.enBitFunctions.Cell_A.ToString.Replace("_", " ")
        btnRelayBit1.Text = clsRelayDriver.enBitFunctions.Cell_B.ToString.Replace("_", " ")
        btnRelayBit2.Text = clsRelayDriver.enBitFunctions.Cell_C.ToString.Replace("_", " ")
        btnRelayBit3.Text = clsRelayDriver.enBitFunctions.Cell_D.ToString.Replace("_", " ")
        btnRelayBit4.Text = clsRelayDriver.enBitFunctions.Cell_E.ToString.Replace("_", " ")
        btnRelayBit5.Text = clsRelayDriver.enBitFunctions.Cell_F.ToString.Replace("_", " ")
        btnRelayBit6.Text = clsRelayDriver.enBitFunctions.Cell_G.ToString.Replace("_", " ")
        btnRelayBit7.Text = clsRelayDriver.enBitFunctions.Cell_H.ToString.Replace("_", " ")

        btnRelayBit8.Text = clsRelayDriver.enBitFunctions.Pack_A.ToString.Replace("_", " ")
        btnRelayBit9.Text = clsRelayDriver.enBitFunctions.Pack_B.ToString.Replace("_", " ")
        btnRelayBit10.Text = clsRelayDriver.enBitFunctions.Pack_C.ToString.Replace("_", " ")
        btnRelayBit11.Text = clsRelayDriver.enBitFunctions.Pack_D.ToString.Replace("_", " ")
        btnRelayBit12.Text = clsRelayDriver.enBitFunctions.Pack_E.ToString.Replace("_", " ")
        btnRelayBit13.Text = clsRelayDriver.enBitFunctions.Pack_F.ToString.Replace("_", " ")
        btnRelayBit14.Text = clsRelayDriver.enBitFunctions.Pack_G.ToString.Replace("_", " ")
        btnRelayBit15.Text = clsRelayDriver.enBitFunctions.Pack_H.ToString.Replace("_", " ")

        btnRelayBit16.Text = clsRelayDriver.enBitFunctions.Cell_PS.ToString.Replace("_", " ")
        btnRelayBit17.Text = clsRelayDriver.enBitFunctions.Cell_EL.ToString.Replace("_", " ")
        btnRelayBit18.Text = clsRelayDriver.enBitFunctions.Pack_PS.ToString.Replace("_", " ")
        btnRelayBit19.Text = clsRelayDriver.enBitFunctions.Pack_EL.ToString.Replace("_", " ")
        btnRelayBit20.Text = clsRelayDriver.enBitFunctions.Aux_PS.ToString.Replace("_", " ")
        btnRelayBit21.Text = clsRelayDriver.enBitFunctions.Relay_21.ToString.Replace("_", " ")
        btnRelayBit22.Text = clsRelayDriver.enBitFunctions.Relay_22.ToString.Replace("_", " ")
        btnRelayBit23.Text = clsRelayDriver.enBitFunctions.Relay_23.ToString.Replace("_", " ")

        ' Order the Relay Indicator buttons
        ' The bit number each is assocated with is defined by its index number of the collection
        RelayButtonIndicators.Add(Me.btnRelayBit0)  ' Index=0 in the collection, so this indicator corresponds with Relay Driver Bit 0
        RelayButtonIndicators.Add(Me.btnRelayBit1)  ' Index=1 in the collection, so this indicator corresponds with Relay Driver Bit 1
        RelayButtonIndicators.Add(Me.btnRelayBit2)  ' Index=2 in the collection, so this indicator corresponds with Relay Driver Bit 2
        RelayButtonIndicators.Add(Me.btnRelayBit3)  ' Index=3 in the collection, so this indicator corresponds with Relay Driver Bit 3
        RelayButtonIndicators.Add(Me.btnRelayBit4)  ' Index=4 in the collection, so this indicator corresponds with Relay Driver Bit 4
        RelayButtonIndicators.Add(Me.btnRelayBit5)  ' Index=5 in the collection, so this indicator corresponds with Relay Driver Bit 5
        RelayButtonIndicators.Add(Me.btnRelayBit6)  ' Index=6 in the collection, so this indicator corresponds with Relay Driver Bit 6
        RelayButtonIndicators.Add(Me.btnRelayBit7)  ' Index=7 in the collection, so this indicator corresponds with Relay Driver Bit 7
        RelayButtonIndicators.Add(Me.btnRelayBit8)  ' Index=8 in the collection, so this indicator corresponds with Relay Driver Bit 8
        RelayButtonIndicators.Add(Me.btnRelayBit9)  ' Index=9 in the collection, so this indicator corresponds with Relay Driver Bit 9
        RelayButtonIndicators.Add(Me.btnRelayBit10)  ' Index=10 in the collection, so this indicator corresponds with Relay Driver Bit 10
        RelayButtonIndicators.Add(Me.btnRelayBit11)  ' Index=11 in the collection, so this indicator corresponds with Relay Driver Bit 11
        RelayButtonIndicators.Add(Me.btnRelayBit12)  ' Index=12 in the collection, so this indicator corresponds with Relay Driver Bit 12
        RelayButtonIndicators.Add(Me.btnRelayBit13)  ' Index=13 in the collection, so this indicator corresponds with Relay Driver Bit 13
        RelayButtonIndicators.Add(Me.btnRelayBit14)  ' Index=14 in the collection, so this indicator corresponds with Relay Driver Bit 14
        RelayButtonIndicators.Add(Me.btnRelayBit15)  ' Index=15 in the collection, so this indicator corresponds with Relay Driver Bit 15
        RelayButtonIndicators.Add(Me.btnRelayBit16)  ' Index=16 in the collection, so this indicator corresponds with Relay Driver Bit 16
        RelayButtonIndicators.Add(Me.btnRelayBit17)  ' Index=17 in the collection, so this indicator corresponds with Relay Driver Bit 17
        RelayButtonIndicators.Add(Me.btnRelayBit18)  ' Index=18 in the collection, so this indicator corresponds with Relay Driver Bit 18
        RelayButtonIndicators.Add(Me.btnRelayBit19)  ' Index=19 in the collection, so this indicator corresponds with Relay Driver Bit 19
        RelayButtonIndicators.Add(Me.btnRelayBit20)  ' Index=20 in the collection, so this indicator corresponds with Relay Driver Bit 20
        RelayButtonIndicators.Add(Me.btnRelayBit21)  ' Index=21 in the collection, so this indicator corresponds with Relay Driver Bit 21
        RelayButtonIndicators.Add(Me.btnRelayBit22)  ' Index=22 in the collection, so this indicator corresponds with Relay Driver Bit 22
        RelayButtonIndicators.Add(Me.btnRelayBit23)  ' Index=23 in the collection, so this indicator corresponds with Relay Driver Bit 23
        ' Now set the Tag properties of each button.
        Dim RelayFont As Font = New Font(btnRelayBit0.Font.FontFamily, btnRelayBit0.Font.Size - 2)
        For i As Integer = 1 To RelayButtonIndicators.Count
            Dim btn As Button = RelayButtonIndicators(i)
            ' Text is the index number, 0-23. (Should this be 1-24?)
            ' Tag is the bit number, used to the btnRElayBit_CLICK event
            ' btn.Text = i.ToString
            btn.Tag = i - 1
            '    btn.Font = RelayFont
        Next
        Try
            Utility.glo.InitializeDefaults()
        Catch ex As Exception

        End Try


        Utility.AddStatusMessageIndicator(Me.txtMessaqeLog)
        Me.Text = glo.Title

        ' Add event handlers for objects on this form
        If Not TestSetControl.Initialize() Then
            ' Some device was not properly initialized.
            ' Don't do anything about it, yet.
            ' The error will be reported later in IOQ check.
        End If

        Me.btnPSCellEnabled.Tag = enPowerSupplyChannelID.ONE
        Me.btnPSPackEnabled.Tag = enPowerSupplyChannelID.TWO

        ' Add event handlers to display equipment settings
        If TestSetControl.PsCell IsNot Nothing Then
            AddHandler TestSetControl.PsCell.CurrentOutputMeasurement, AddressOf Me.EventHandler_PSIout
            AddHandler TestSetControl.PsCell.CurrentSetpoint, AddressOf Me.EventHandler_PSISet
            AddHandler TestSetControl.PsCell.Enabled, AddressOf Me.EventHandler_PSEnable
            AddHandler TestSetControl.PsCell.OverCurrentProtectValue, AddressOf Me.EventHandler_PSOCP
            AddHandler TestSetControl.PsCell.OverVoltageProtectValue, AddressOf Me.EventHandler_PSOVP
            AddHandler TestSetControl.PsCell.VoltageOutputMeasurement, AddressOf Me.EventHandler_PSVout
            AddHandler TestSetControl.PsCell.VoltageSetpoint, AddressOf Me.EventHandler_PSVSet
        End If
        If TestSetControl.PsPack IsNot Nothing Then
            AddHandler TestSetControl.PsPack.CurrentOutputMeasurement, AddressOf Me.EventHandler_PSIout
            AddHandler TestSetControl.PsPack.CurrentSetpoint, AddressOf Me.EventHandler_PSISet
            AddHandler TestSetControl.PsPack.Enabled, AddressOf Me.EventHandler_PSEnable
            AddHandler TestSetControl.PsPack.OverCurrentProtectValue, AddressOf Me.EventHandler_PSOCP
            AddHandler TestSetControl.PsPack.OverVoltageProtectValue, AddressOf Me.EventHandler_PSOVP
            AddHandler TestSetControl.PsPack.VoltageOutputMeasurement, AddressOf Me.EventHandler_PSVout
            AddHandler TestSetControl.PsPack.VoltageSetpoint, AddressOf Me.EventHandler_PSVSet
        End If
        If TestSetControl.PSAux IsNot Nothing Then
            AddHandler TestSetControl.PSAux.CurrentOutputMeasurement, AddressOf Me.EventHandler_PSIout
            AddHandler TestSetControl.PSAux.CurrentSetpoint, AddressOf Me.EventHandler_PSISet
            AddHandler TestSetControl.PSAux.Enabled, AddressOf Me.EventHandler_PSEnable
            AddHandler TestSetControl.PSAux.OverCurrentProtectValue, AddressOf Me.EventHandler_PSOCP
            AddHandler TestSetControl.PSAux.OverVoltageProtectValue, AddressOf Me.EventHandler_PSOVP
            AddHandler TestSetControl.PSAux.VoltageOutputMeasurement, AddressOf Me.EventHandler_PSVout
            AddHandler TestSetControl.PSAux.VoltageSetpoint, AddressOf Me.EventHandler_PSVSet
        End If

        '' Event handlers for Cell Eload - Instrument Metering functions 
        If TestSetControl.ELoadCell IsNot Nothing Then
            AddHandler TestSetControl.ELoadCell.InputVoltage, AddressOf Me.EventHandler_ELCVin
            AddHandler TestSetControl.ELoadCell.InputCurrent, AddressOf Me.EventHandler_ELCIin
            AddHandler TestSetControl.ELoadCell.InputPower, AddressOf Me.EventHandler_ELCPin
            AddHandler TestSetControl.ELoadCell.InputResistance, AddressOf Me.EventHandler_ELCRin
            AddHandler TestSetControl.ELoadCell.InputEnabled, AddressOf Me.EventHandler_ELCEnabble
            '' Event handlers for Cell ELoad - Instrument settings
            AddHandler TestSetControl.ELoadCell.ConstantCurrentLimit, AddressOf Me.EventHandler_ELCCCset
            AddHandler TestSetControl.ELoadCell.ConstantVoltageLimit, AddressOf Me.EventHandler_ELCCVset
            AddHandler TestSetControl.ELoadCell.ConstantPowerLimit, AddressOf Me.EventHandler_ELCCPset
            AddHandler TestSetControl.ELoadCell.ConstantResistanceLimit, AddressOf Me.EventHandler_ELCCRset
            AddHandler TestSetControl.ELoadCell.TheOperatingMode, AddressOf Me.EventHandler_ELCellMode
        End If

        If TestSetControl.EloadPack IsNot Nothing Then
            '' Event handlers for Pack Eload - Instrument Metering functions 
            AddHandler TestSetControl.EloadPack.InputVoltage, AddressOf Me.EventHandler_ELPVin
            AddHandler TestSetControl.EloadPack.InputCurrent, AddressOf Me.EventHandler_ELPIin
            AddHandler TestSetControl.EloadPack.InputPower, AddressOf Me.EventHandler_ELPPin
            AddHandler TestSetControl.EloadPack.InputResistance, AddressOf Me.EventHandler_ELPRin
            AddHandler TestSetControl.EloadPack.InputEnabled, AddressOf Me.EventHandler_ELPEnabble

            '' Event handlers for Pack ELoad - Instrument settings
            AddHandler TestSetControl.EloadPack.ConstantCurrentLimit, AddressOf Me.EventHandler_ELPCCset
            AddHandler TestSetControl.EloadPack.ConstantVoltageLimit, AddressOf Me.EventHandler_ELPCVset
            AddHandler TestSetControl.EloadPack.ConstantPowerLimit, AddressOf Me.EventHandler_ELPCPset
            AddHandler TestSetControl.EloadPack.ConstantResistanceLimit, AddressOf Me.EventHandler_ELPCRset
            AddHandler TestSetControl.EloadPack.TheOperatingMode, AddressOf Me.EventHandler_ELPackMode
        End If

        '' Event handlers for VISA functions - The same handler for all VISA operations
        AddHandler TestSetControl.PsCell.VisaOperation, AddressOf Me.EventHandler_VISAOp '' Same handler for all VISA ops
        AddHandler TestSetControl.ELoadCell.VisaOperation, AddressOf Me.EventHandler_VISAOp
        AddHandler TestSetControl.EloadPack.VisaOperation, AddressOf Me.EventHandler_VISAOp
        AddHandler TestSetControl.PSAux.VisaOperation, AddressOf Me.EventHandler_VISAOp


        ' Event handlers for Relay Driver
        AddHandler TestSetControl.RelayDriver.BitStatus, AddressOf Me.EventHandler_RelayBitState
        TestSetControl.RelayDriver.ClearAllBits() ' Initialize the indicators

        '' Configure dgvDaqScan
        'Dim EN As HP34970A_VISA.enumMeasurementConfiguration = HP34970A_VISA.enumMeasurementConfiguration.Ohms
        'Dim EnumNames() As String = [Enum].GetNames(EN.GetType)
        'Dim FunctCol As DataGridViewComboBoxColumn = dgvDaqScan.Columns("Funct")
        'For Each EnName As String In EnumNames
        '    FunctCol.Items.Add(EnName)
        'Next

        'Initialize dgvDAQ200a and B. These indicate the DAQ switch states
        dgvDaq200a.Rows.Add(10)
        dgvDaq200b.Rows.Add(10)
        Dim j As Integer = 200
        For Each Row As DataGridViewRow In dgvDaq200a.Rows
            j += 1
            Row.SetValues(j, False)
        Next
        j = 210
        For Each Row As DataGridViewRow In dgvDaq200b.Rows
            j += 1
            Row.SetValues(j, False)
        Next

        ' DAQ Event Handlers
        'AddHandler TestSetControl.DAQ.SingleMeasurement, AddressOf Me.EventHandler_DaqSingleMeasurement
        AddHandler TestSetControl.DAQ.SwitchState, AddressOf Me.EventHandler_DaqSwitchState

        ' Sync form indicators with equipment
        Me.ScanTheInstruments(tmrScanInstruments, New System.EventArgs)

        ' Initialize Test Report functions

        ' Here down configures the test groups
        ' Don't do this if there was an error configuring equipment
        Dim IOQResult As Boolean = TestSetControl.IOQReport.DoIOQTest
        'IOQResult = True
        If Not IOQResult Then
            Me.BackColor = glo.Colors.ErrorColor
            '  Me.tpgTesting.Controls.Clear() ' Clear out the tab page
            Me.tpgTesting.BackColor = glo.Colors.ErrorColor
            btnSetupErrorIndicator = New Button
            btnSetupErrorIndicator.Text = "Set Up Error" & NL &
                                            "Some Equipment Was Not Properly Intialized!"
            gbxStartIndicators.Controls.Add(btnSetupErrorIndicator)
            btnSetupErrorIndicator.Dock = DockStyle.Fill
        End If

        'gbxStartIndicators.Controls.Add(Sequencer.btnRunAllTestsButton)
        'Sequencer.btnRunAllTestsButton.Dock = DockStyle.Fill
        'Sequencer.btnRunAllTestsButton.Visible = True
        'Sequencer.btnRunAllTestsButton.Font = Sequencer.btnRunAllTestsButton.Parent.Font.Clone

        ' Add handler to keep the Bq76940ControlScreenToolStripMenuItem checked state in sync with the form visibility property
        AddHandler TestSetControl.bq76940.FormVisibleChanged, AddressOf Me.SetBq76940ControlScreenToolStripMenuItem_Click

        'Me.TestingToolStripMenuItem.DropDownItems.Add(Sequencer.mnuRunAllTestsMenuItem)

        ' Initialize sequencer
        Sequencer = New TestSequencer
        Sequencer.InitializeSequencer() ' Creates test groups, buttons and menu indicators. Initializes data collection
        Me.MenuStrip1.Items.Insert(1, Sequencer.TestingMenuItem)
        'Me.tlpStatusIndicators.Controls.Add(Sequencer.AllTestingData.MyStatusDisplay, 0, 0)
        'Me.tlpStatusIndicators.SetRowSpan(Sequencer.AllTestingData.MyStatusDisplay, 2)
        'Me.tlpStatusIndicators.SetColumnSpan(Sequencer.AllTestingData.MyStatusDisplay, 2)
        Sequencer.AllTestingData.MyStatusDisplay.Dock = DockStyle.Fill

        TestSetControl.DAQ.ConfigurationDataGridView.Dock = DockStyle.Fill
        Me.tlpDaqMonitor.Controls.Add(TestSetControl.DAQ.ConfigurationDataGridView)
        tlpDaqMonitor.SetCellPosition(TestSetControl.DAQ.ConfigurationDataGridView, New TableLayoutPanelCellPosition(0, 1))
        tlpDaqMonitor.SetColumnSpan(TestSetControl.DAQ.ConfigurationDataGridView, tlpDaqMonitor.ColumnCount)

    End Sub
    Private Sub InitializeCommonValues(ByRef TheTest As ITestFunction)
        '' All these value are the same for every pallet

        TheTest.AddKeyValue("PsCell_ISetNominal", 3.5)  'Amps
        TheTest.AddKeyValue("ElCell_ISet", 3)    'Amps
        TheTest.AddKeyValue("PsCell_VsetNominal", 3.5) 'V
        TheTest.AddKeyValue("ElPack_IsetNom", 0.5) 'amp

        ' Cell Overvoltage Testing
        ' Ramp up PsCell until Ipack", 0, as measured by PsPack
        TheTest.AddKeyValue("PsPack_Vset", 4.5) 'Volts
        TheTest.AddKeyValue("PsPack_Iset", 0.5) 'Amps

        TheTest.AddKeyValue("PsCell_COV_Max", 4.3)   ' Volts. Max voltage to step up to
        TheTest.AddKeyValue("PsCell_COV_Step", 0.1)    ' Volts. Step in this increment
        TheTest.AddKeyValue("PsCell_COV_Dwell", 100)   'msec between steps
        TheTest.AddKeyValue("Pack_Current_COV", 0.1) 'Amp. Max allowable pack current during COV
        TheTest.AddKeyValue("CellVoltage_COV_Min", 4.1)   ' Volts
        TheTest.AddKeyValue("CellVoltage_COV_Max", 4.2)  ' Volts

        'Cell Undervoltage
        ' Ramp down PsCell until Ipack", 0, as measured by ElPack
        TheTest.AddKeyValue("PsCell_CUV_Min", 2.0) 'V
        TheTest.AddKeyValue("PsCell_CUV_Step", 0.1)  'V
        TheTest.AddKeyValue("PSCell_CUV_Dwell", 100) 'msec
        TheTest.AddKeyValue("Pack_Current_CUV", 0.1) 'Amp. Max allowable pack current during CUV
        TheTest.AddKeyValue("CellVoltage_CUV_Min", 4.1)  ' Volts
        TheTest.AddKeyValue("CellVoltage_CUV_Max", 4.2) ' Volts

        'OverCurrent-Discharge
        ' Ramp up Ipack until Ipack=0
        ' Cell at nominal settings
        TheTest.AddKeyValue("ElPack_OCD_Step", 0.1) 'A
        TheTest.AddKeyValue("ElPack_OCD_Dwell", 100) 'msec
        TheTest.AddKeyValue("ElPack_OCD_Max", 2) '   Amp. Max discharge current before calling it a fail
        TheTest.AddKeyValue("Pack_Current_OCD_min", 1.8) 'A. The pack current that caused OCD fault
        TheTest.AddKeyValue("Pack_Current_OCD_max", 1.8) 'A. The pack current that caused OCD fault

        'OverCurrent-Charge
        ' Ramp up Ipack until Ipack=0
        ' Cell at nominal settings
        TheTest.AddKeyValue("ElPack_OCC_Step", 0.1)  'A
        TheTest.AddKeyValue("ElPack_OCC_Dwell", 100)  'msec
        TheTest.AddKeyValue("ElPack_OCC_Max", 2) '   Amp. Max discharge current before calling it a fail
        TheTest.AddKeyValue("Pack_Current_OCC_min", 1.8) 'A. The pack current that caused OCD fault
        TheTest.AddKeyValue("Pack_Current_OCC_max", 1.8) 'A. The pack current that caused OCD fault
    End Sub
    Private Sub EventHandler_PSVout(Vout As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As TextBox
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.txtPSCellVout
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.txtPSPackVout
            Case enPowerSupplyChannelID.None
                txtBox = Me.txtPsAuxVout
            Case Else
                txtBox = New TextBox ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Text = Format(Vout, "0.000")
        Else
            txtBox.Text = "Error"
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub
    Private Sub EventHandler_PSIout(Iout As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As TextBox
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.txtPSCellIout
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.txtPSPackIout
            Case enPowerSupplyChannelID.None
                txtBox = Me.txtPsAuxIout
            Case Else
                txtBox = New TextBox ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Text = Format(Iout, "0.000")
            txtBox.BackColor = glo.Colors.DefaultControlBackcolor
        Else
            txtBox.Text = "Error"
            txtBox.BackColor = glo.Colors.ErrorColor
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub
    Private Sub EventHandler_PSVSet(Vset As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As NumericUpDown
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.udPSCellVlimit
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.udPSPackVLimit
            Case enPowerSupplyChannelID.None
                txtBox = Me.udPSAuxVLimit
            Case Else
                txtBox = New NumericUpDown ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Value = Format(Vset, "0.000")
            txtBox.BackColor = glo.Colors.DefaultControlBackcolor
        Else
            txtBox.Value = 0
            txtBox.BackColor = glo.Colors.ErrorColor
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub
    Private Sub EventHandler_PSISet(Iset As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As NumericUpDown
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.udPSCellILimit
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.udPSPackIlimit
            Case enPowerSupplyChannelID.None
                txtBox = Me.udPSAuxIlimit
            Case Else
                txtBox = New NumericUpDown ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Text = Format(Iset, "0.00")
            txtBox.BackColor = glo.Colors.DefaultControlBackcolor
        Else
            'txtBox.Text = "Error"
            txtBox.BackColor = glo.Colors.ErrorColor
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub

    Private Sub EventHandler_PSOVP(OVP As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As NumericUpDown
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.udPSCellOVP
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.udPSPackOVP
            Case enPowerSupplyChannelID.None
                txtBox = Me.udPSAuxOVP
            Case Else
                txtBox = New NumericUpDown ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Value = Format(OVP, "0.00")
            txtBox.BackColor = glo.Colors.DefaultControlBackcolor
        Else
            txtBox.Value = 0
            txtBox.BackColor = glo.Colors.ErrorColor
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub
    Private Sub EventHandler_PSOCP(OCP As Double, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim txtBox As NumericUpDown
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                txtBox = Me.udPSCellOCP
            Case enPowerSupplyChannelID.TWO
                txtBox = Me.udPSPackOCP
            Case enPowerSupplyChannelID.None
                txtBox = Me.udPSAuxOCP
            Case Else
                txtBox = New NumericUpDown ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            txtBox.Value = Format(OCP, "0.00")
            txtBox.BackColor = glo.Colors.DefaultControlBackcolor
        Else
            txtBox.Value = 0
            txtBox.BackColor = glo.Colors.ErrorColor
        End If
        txtBox.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub
    Private Sub EventHandler_PSEnable(Enabled As Boolean, Channel As enPowerSupplyChannelID, ErrorThrown As Boolean)
        Dim btn As Button
        Select Case Channel
            Case enPowerSupplyChannelID.ONE
                btn = Me.btnPSCellEnabled
            Case enPowerSupplyChannelID.TWO
                btn = Me.btnPSPackEnabled
            Case enPowerSupplyChannelID.None
                btn = btnPsAuxEnabled
            Case Else
                btn = New Button ' Really "nothing", but does not raise an error
        End Select
        If Not ErrorThrown Then
            btn.Text = IIf(Enabled, "Enabled", "Not Enabled")
            btn.BackColor = IIf(Enabled, glo.Colors.OnColor, glo.Colors.OffColor)
        Else
            btn.Text = "Error"
            btn.BackColor = glo.Colors.ErrorColor
        End If
        btn.Tag = Channel  ' This will be needed if the operator manually changes a value
    End Sub

    '' Eload Event Handlers
    'Public Event InputEnabled(InputStatus As Boolean)
    'Public Event ConstantCurrentLimit(CCLevel As Double)
    'Public Event ConstantVoltageLimit(CVLevel As Double)
    'Public Event ConstantPowerLimit(CPLevel As Double)
    'Public Event ConstantResistanceLimit(CRLevel As Double)

    'Public Event OperatingMode(TheMode As String)

    'Public Event InputVoltage(Volts As Double)
    'Public Event InputCurrent(Amps As Double)
    'Public Event InputResistance(Ohms As Double)
    'Public Event InputPower(Watts As Double)

    'Public Event Reset()
    Private Sub EventHandler_ELCVin(Vin As Double)
        Me.txtELCellVin.Text = Format(Vin, "0.000")
    End Sub
    Private Sub EventHandler_ELPVin(Vin As Double)
        Me.txtELPackVin.Text = Format(Vin, "0.000")
    End Sub
    Private Sub EventHandler_ELCIin(Iin As Double)
        Me.txtELCellIin.Text = Format(Iin, "0.000")
    End Sub
    Private Sub EventHandler_ELPIin(Iin As Double)
        Me.txtELPackIin.Text = Format(Iin, "0.000")
    End Sub
    Private Sub EventHandler_ELCPin(Pin As Double)
        Me.txtELCellPin.Text = Format(Pin, "0.000")
    End Sub
    Private Sub EventHandler_ELPPin(Pin As Double)
        Me.txtELPackPin.Text = Format(Pin, "0.000")
    End Sub
    Private Sub EventHandler_ELCRin(Rin As Double)
        Me.txtELCellRin.Text = Format(Rin, "0")
    End Sub
    Private Sub EventHandler_ELPRin(Rin As Double)
        Me.txtELPackRin.Text = Format(Rin, "0")
    End Sub

    Private Sub EventHandler_ELCCCset(CCSet As Double)
        Me.udELCellCCamps.Value = Format(CCSet, "0.000")
    End Sub
    Private Sub EventHandler_ELCCVset(CVSet As Double)
        Me.udELCellCVvolts.Value = Format(CVSet, "0.000")
    End Sub
    Private Sub EventHandler_ELCCPset(CPSet As Double)
        Me.udELCellCPwatts.Value = Format(CPSet, "0.000")
    End Sub
    Private Sub EventHandler_ELCCRset(CRSet As Double)
        Me.udELCellCRohms.Value = Format(CRSet, "0.000")
    End Sub
    Private Sub EventHandler_ELCellMode(Mode As String)
        ' Select the Radio button with the "mode" value in its tag property
        ' Values are CCH, CCL, CPV, CPC, CV, CRH, CRM, CRL
        If Mode Is Nothing Then Exit Sub ' Some error happened, probably the E-Load objects didn't load
        If Mode.StartsWith("CC") Then Me.radELCellModeCC.Checked = True 'Default to CCHigh mode
        If Mode.StartsWith("CP") Then Me.radELCellModeCP.Checked = True 'Default to CPCurrent mode
        If Mode.StartsWith("CV") Then Me.radELCellModeCV.Checked = True 'Only one CV mode
        If Mode.StartsWith("CR") Then Me.radELCellModeCR.Checked = True 'Default to CRHigh mode

        ' Set the backcolor of the appropriate ud indicator
        udELCellCCamps.BackColor = IIf(Mode.StartsWith("CC"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELCellCPwatts.BackColor = IIf(Mode.StartsWith("CP"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELCellCRohms.BackColor = IIf(Mode.StartsWith("CR"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELCellCVvolts.BackColor = IIf(Mode.StartsWith("CV"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
    End Sub
    Private Sub EventHandler_ELPCCset(CCSet As Double)
        Me.udELPackCCamps.Value = Format(CCSet, "0.000")
    End Sub
    Private Sub EventHandler_ELPCVset(CVSet As Double)
        Me.udELPackCVvolts.Value = Format(CVSet, "0.000")
    End Sub
    Private Sub EventHandler_ELPCPset(CPSet As Double)
        Me.udELPackCPwatts.Value = Format(CPSet, "0.000")
    End Sub
    Private Sub EventHandler_ELPCRset(CRSet As Double)
        Me.udELPackCRohms.Value = Format(CRSet, "0.000")
    End Sub
    Private Sub EventHandler_ELPackMode(Mode As String)
        ' Select the Radio button with the "mode" value in its tag property
        ' Values are CCH, CCL, CPV, CPC, CV, CRH, CRM, CRL
        If Mode Is Nothing Then Exit Sub ' Some error happened, probably the E-Load objects didn't load
        If Mode.StartsWith("CC") Then Me.radELPackModeCC.Checked = True 'Default to CCHigh mode
        If Mode.StartsWith("CP") Then Me.radELPackModeCP.Checked = True 'Default to CPCurrent mode
        If Mode.StartsWith("CV") Then Me.radELPackModeCV.Checked = True 'Only one CV mode
        If Mode.StartsWith("CR") Then Me.radELPackModeCR.Checked = True 'Default to CRHigh mode

        ' Set the backcolor of the appropriate ud indicator
        udELPackCCamps.BackColor = IIf(Mode.StartsWith("CC"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELPackCPwatts.BackColor = IIf(Mode.StartsWith("CP"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELPackCRohms.BackColor = IIf(Mode.StartsWith("CR"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
        udELPackCVvolts.BackColor = IIf(Mode.StartsWith("CV"), glo.Colors.InProgressColor, System.Drawing.SystemColors.Window)
    End Sub
    Private Sub EventHandler_ELCEnabble(Enabled As Boolean)
        Dim Btn As Button = Me.btnELCellEnabled
        Btn.Text = IIf(Enabled, "Enabled", "Not Enabled")
        Btn.BackColor = IIf(Enabled, glo.Colors.OnColor, glo.Colors.OffColor)
    End Sub
    Private Sub EventHandler_ELPEnabble(Enabled As Boolean)
        Dim Btn As Button = Me.btnELPackEnabled
        Btn.Text = IIf(Enabled, "Enabled", "Not Enabled")
        Btn.BackColor = IIf(Enabled, glo.Colors.OnColor, glo.Colors.OffColor)
    End Sub
    Private Sub EventHandler_RelayBitState(Bit0_23 As Integer, State As Boolean)
        ' Bit0_23 corresponds to the index number in the collection
        Dim Btn As Button = RelayButtonIndicators(Bit0_23 + 1)
        Btn.BackColor = IIf(State, glo.Colors.OnColor, glo.Colors.OffColor)
    End Sub

    Private Sub EventHandler_VISAOp(Message As String, M32 As String, IsError As Boolean)

    End Sub

    ' Click event handlers. Changes values of the power supply
    Private Sub btnAuxEnabled(sender As System.Object, e As System.EventArgs) Handles btnPsAuxEnabled.Click
        If ReadInProgress Then Exit Sub
        Dim StateNow As Boolean = TestSetControl.PSAux.IsEnabled
        TestSetControl.PSAux.IsEnabled = Not StateNow
    End Sub
    Private Sub btnEnabled_Click(sender As System.Object, e As System.EventArgs) Handles btnPSCellEnabled.Click, btnPSPackEnabled.Click
        If ReadInProgress Then Exit Sub
        Dim Chan As enPowerSupplyChannelID = sender.tag
        Dim PS As IPowerSupply
        Select Case Chan
            Case enPowerSupplyChannelID.ONE
                PS = TestSetControl.PsCell
            Case enPowerSupplyChannelID.TWO
                PS = TestSetControl.PsPack
            Case enPowerSupplyChannelID.None
                PS = TestSetControl.PSAux
            Case Else
                Exit Sub
        End Select
        PS.IsEnabled = Not PS.IsEnabled
    End Sub

    Private Sub udVlimit_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udPSCellVlimit.ValueChanged, udPSPackVLimit.ValueChanged, udPSAuxVLimit.ValueChanged
        If ReadInProgress Then Exit Sub
        Dim Chan As enPowerSupplyChannelID = sender.tag
        Dim NewVal As Double = Val(sender.value)

        Dim PS As IPowerSupply
        Select Case Chan
            Case enPowerSupplyChannelID.ONE
                PS = TestSetControl.PsCell
            Case enPowerSupplyChannelID.TWO
                PS = TestSetControl.PsPack
            Case enPowerSupplyChannelID.None
                PS = TestSetControl.PSAux
            Case Else
                Exit Sub
        End Select
        PS.VoltageSet = NewVal
    End Sub
    Private Sub udIlimitB_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udPSCellILimit.ValueChanged, udPSPackIlimit.ValueChanged, udPSAuxIlimit.ValueChanged
        If ReadInProgress Then Exit Sub
        Dim Chan As enPowerSupplyChannelID = sender.tag
        Dim NewVal As Double = Val(sender.value)

        Dim PS As IPowerSupply
        Select Case Chan
            Case enPowerSupplyChannelID.ONE
                PS = TestSetControl.PsCell
            Case enPowerSupplyChannelID.TWO
                PS = TestSetControl.PsPack
            Case enPowerSupplyChannelID.None
                PS = TestSetControl.PSAux
            Case Else
                Exit Sub
        End Select
        PS.CurrentSet = NewVal
    End Sub
    Private Sub udOVPA_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udPSCellOVP.ValueChanged, udPSPackOVP.ValueChanged, udPSAuxOVP.ValueChanged
        If ReadInProgress Then Exit Sub
        Dim Chan As enPowerSupplyChannelID = sender.tag
        Dim NewVal As Double = Val(sender.value)

        Dim PS As IPowerSupply
        Select Case Chan
            Case enPowerSupplyChannelID.ONE
                PS = TestSetControl.PsCell
            Case enPowerSupplyChannelID.TWO
                PS = TestSetControl.PsPack
            Case enPowerSupplyChannelID.None
                PS = TestSetControl.PSAux
            Case Else
                Exit Sub
        End Select
        PS.OverVoltageProtect = NewVal
    End Sub
    Private Sub udOCPA_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udPSCellOCP.ValueChanged, udPSPackOCP.ValueChanged, udPSAuxOCP.ValueChanged
        If ReadInProgress Then Exit Sub
        Dim Chan As enPowerSupplyChannelID = sender.tag
        Dim NewVal As Double = Val(sender.value)

        Dim PS As IPowerSupply
        Select Case Chan
            Case enPowerSupplyChannelID.ONE
                PS = TestSetControl.PsCell
            Case enPowerSupplyChannelID.TWO
                PS = TestSetControl.PsPack
            Case enPowerSupplyChannelID.None
                PS = TestSetControl.PSAux
            Case Else
                Exit Sub
        End Select
        PS.OverCurrentProtect = NewVal
    End Sub

    Private Sub ScanTheInstruments(sender As System.Object, e As System.EventArgs) Handles tmrScanInstruments.Tick
        ReadInProgress = True
        Me.gbxPowerSupplyCell.Visible = TestSetControl.PsCell IsNot Nothing
        Me.gbxPowerSupplyPack.Visible = TestSetControl.PsPack IsNot Nothing
        Me.gbxPowerSupplyAux.Visible = TestSetControl.PSAux IsNot Nothing
        Me.gbxELoadCell.Visible = TestSetControl.ELoadCell IsNot Nothing
        Me.gbxELoadPack.Visible = TestSetControl.EloadPack IsNot Nothing

        If TestSetControl.PsCell IsNot Nothing Then TestSetControl.PsCell.ReadAllParameters()
        If TestSetControl.PsPack IsNot Nothing Then TestSetControl.PsPack.ReadAllParameters()
        If TestSetControl.PSAux IsNot Nothing Then TestSetControl.PSAux.ReadAllParameters()
        If TestSetControl.ELoadCell IsNot Nothing Then TestSetControl.ELoadCell.ReadAllParameters()
        If TestSetControl.EloadPack IsNot Nothing Then TestSetControl.EloadPack.ReadAllParameters()

        ReadInProgress = False
    End Sub


    Private Sub btnELCellEnabled_Click(sender As System.Object, e As System.EventArgs) Handles btnELCellEnabled.Click
        If ReadInProgress Then Exit Sub
        Dim IsNowOn = TestSetControl.ELoadCell.InputEnabledState
        TestSetControl.ELoadCell.InputEnabledState = Not IsNowOn
    End Sub
    Private Sub btnELPackEnabled_Click(sender As System.Object, e As System.EventArgs) Handles btnELPackEnabled.Click
        If ReadInProgress Then Exit Sub
        Dim IsNowOn = TestSetControl.EloadPack.InputEnabledState
        TestSetControl.EloadPack.InputEnabledState = Not IsNowOn
    End Sub

    Private Sub udELCellCCamps_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELCellCCamps.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.ELoadCell.ConstantCurrentSetting = sender.value
    End Sub
    Private Sub udELCellCCVolts_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELCellCVvolts.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.ELoadCell.ConstantVoltageSetting = sender.value
    End Sub
    Private Sub udELCellCPwatts_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELCellCPwatts.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.ELoadCell.ConstantPowerSetting = sender.value
    End Sub
    Private Sub udELCellCRohms_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELCellCRohms.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.ELoadCell.ConstantResistanceSetting = sender.value
    End Sub

    Private Sub udELPackCCamps_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELPackCCamps.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.EloadPack.ConstantCurrentSetting = sender.value
    End Sub
    Private Sub udELPackCCVolts_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELPackCVvolts.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.EloadPack.ConstantVoltageSetting = sender.value
    End Sub
    Private Sub udELPackCPwatts_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELPackCPwatts.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.EloadPack.ConstantPowerSetting = sender.value
    End Sub
    Private Sub udELPackCRohms_ValueChanged(sender As System.Object, e As System.EventArgs) Handles udELPackCRohms.ValueChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.EloadPack.ConstantResistanceSetting = sender.value
    End Sub

    Private Sub radELCellModeCC_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radELCellModeCC.CheckedChanged,
                                                                                radELCellModeCV.CheckedChanged, radELCellModeCP.CheckedChanged, radELCellModeCR.CheckedChanged

        If ReadInProgress Then Exit Sub
        Dim Sndr As RadioButton = sender
        If Not Sndr.Checked Then Exit Sub ' Not checked, so nothing to do

        Dim NewMode As String = sender.tag.ToString.Trim.ToUpper
        TestSetControl.ELoadCell.OperatingMode = NewMode
    End Sub
    Private Sub radELpackModeCC_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles radELPackModeCC.CheckedChanged,
                                                                                radELPackModeCV.CheckedChanged, radELPackModeCP.CheckedChanged, radELPackModeCR.CheckedChanged
        If ReadInProgress Then Exit Sub
        Dim Sndr As RadioButton = sender
        If Not Sndr.Checked Then Exit Sub 'Not checked, so nothing to send to device

        Dim NewMode As String = sender.tag.ToString.Trim.ToUpper
        TestSetControl.EloadPack.OperatingMode = NewMode
    End Sub

    Private Sub chkELCellShort_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkELCellShort.CheckedChanged, chkELPackShort.CheckedChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.ELoadCell.ShortIsEnabled = sender.checked
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkELPackShort.CheckedChanged
        If ReadInProgress Then Exit Sub
        TestSetControl.EloadPack.ShortIsEnabled = sender.checked
    End Sub

    Private Sub btnRelayBit_Click(sender As System.Object, e As System.EventArgs) Handles btnRelayBit0.Click, btnRelayBit1.Click, btnRelayBit2.Click, btnRelayBit3.Click,
                                                                                        btnRelayBit4.Click, btnRelayBit5.Click, btnRelayBit6.Click, btnRelayBit7.Click,
                                                                                        btnRelayBit8.Click, btnRelayBit9.Click, btnRelayBit10.Click, btnRelayBit11.Click,
                                                                                        btnRelayBit12.Click, btnRelayBit13.Click, btnRelayBit14.Click, btnRelayBit15.Click,
                                                                                        btnRelayBit16.Click, btnRelayBit17.Click, btnRelayBit18.Click, btnRelayBit19.Click,
                                                                                        btnRelayBit20.Click, btnRelayBit21.Click, btnRelayBit22.Click, btnRelayBit23.Click
        Dim Sndr As Button = sender
        TestSetControl.RelayDriver.ToggleBit(Sndr.Tag)
    End Sub
    Private Sub EventHandler_DaqSwitchState(Channel As Integer, IsClosed As Boolean)
        Dim dgv As DataGridView
        Select Case Channel
            Case 201 To 210
                dgv = Me.dgvDaq200a
            Case 211 To 220
                dgv = Me.dgvDaq200b
            Case Else
                ' Handle error somewhere else
        End Select
        For Each row As DataGridViewRow In dgv.Rows
            If Not row.Cells(0).Value Is Nothing Then
                If row.Cells(0).Value = Channel Then
                    row.Cells(1).Value = IsClosed
                End If
            End If
        Next
    End Sub
    Private Sub dgvDaq200a_CellClick(sender As Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDaq200a.CellClick, dgvDaq200b.CellClick
        If e.ColumnIndex <> 1 Then Exit Sub
        If TestSetControl.DAQ Is Nothing Then Exit Sub
        Dim dgv As DataGridView = sender
        Dim Chan = dgv.Rows(e.RowIndex).Cells(0).Value
        TestSetControl.DAQ.ToggleSwitch(Chan)
    End Sub

    Private Sub btnUsbioAllOn_Click(sender As System.Object, e As System.EventArgs)
        Dim Stk As Boolean = sender.enabled
        For i As Integer = 0 To 23
            TestSetControl.RelayDriver.SetBit(i)
        Next
        sender.enabled = Stk
    End Sub

    Private Sub btnUsbIoAllOff_Click(sender As System.Object, e As System.EventArgs)
        Dim Stk As Boolean = sender.enabled
        For i As Integer = 0 To 23
            TestSetControl.RelayDriver.ClearBit(i)
        Next
        sender.enabled = Stk
    End Sub

    Private Sub txtRefreshInternal_TextChanged(sender As Object, e As System.EventArgs) Handles txtRefreshInterval.TextChanged
        txtRefreshInterval.Text = CInt(Val(txtRefreshInterval.Text))
        If Val(txtRefreshInterval.Text) < 100 Then txtRefreshInterval.Text = "100"
        Me.tmrScanInstruments.Interval = Val(txtRefreshInterval.Text)
    End Sub

    Private Sub mnuScanAllItemsContext_Click(sender As System.Object, e As System.EventArgs) Handles mnuScanAllItemsContext.Click
        Me.mnuScanAllItems.Checked = Not Me.mnuScanAllItems.Checked
    End Sub
    Private Sub mnuScanAllItems_Click(sender As System.Object, e As System.EventArgs) Handles mnuScanAllItems.CheckedChanged
        mnuScanAllItemsContext.Checked = mnuScanAllItems.Checked
        Me.tmrScanInstruments.Enabled = Me.mnuScanAllItems.Checked
    End Sub
    Private bqComm As New clsEv2300Comm

    Private Sub btnTestStuff_Click(sender As Object, e As EventArgs) Handles btnTestStuff.Click
        Dim Res As clsEv2300Comm.EV2300_ErrorCode
        Dim SW As New Stopwatch
        SW.Start()

        Dim TheName = Nothing
        Dim nLen As Short

        Dim nData As Short = Short.MaxValue
        ' Run through all the bq769X0 registers
        ' See how fast this can be done
        Dim strout As New System.Text.StringBuilder("")
        Dim ThisData As Short
        Dim V As Object
        Dim NumBytes As Integer
        Dim BlkNum As Integer
        For BlkNum = 0 To 2

            'Res = TestSetControl.EV2300.Bq80xRW1.I2CReadWrite(BQ80XRWLib.I2COperation.vb_I2C_EE_RD_BYTE, &H17S, addr, ThisData)
            'TestSetControl.EV2300.CloseDevice()
            'TestSetControl.EV2300.OpenFirstFreeDevice
            'Res = TestSetControl.EV2300.I2CReadWrite(BQ80XRWLib.I2COperation.vb_I2C_EE_RD_BYTE, &H8, addr, ThisData)
            V = Nothing
            Dim Addr As Short = BlkNum * 32
            Res = TestSetControl.EV2300.Bq80xRW1.I2CReadBlock(Addr, V, 32, &H11)

            NumBytes += V.length
            For i = 0 To 31
                strout.Append(Hex(V(i)).PadLeft(2, "0"))
                strout.Append(" ")
            Next
        Next
        MsgBox(strout.ToString, MsgBoxStyle.OkOnly, Res.ToString & "   " & SW.ElapsedMilliseconds & "msec  " & NumBytes & " bytes")

    End Sub
    Private Sub SetBq76940ControlScreenToolStripMenuItem_Click(NowVisible As Boolean)
        ShowBq76940ControlScreenToolStripMenuItem.Checked = NowVisible
    End Sub
    Private Sub ShowBq76940ControlScreenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowBq76940ControlScreenToolStripMenuItem.Click
        Dim sndr As ToolStripMenuItem = sender
        TestSetControl.bq76940.CommunicationFormVisible = sndr.Checked
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub btnResetDAQ_Click(sender As Object, e As EventArgs) Handles btnResetDAQ.Click
        If Not TestSetControl.DAQ Is Nothing Then
            TestSetControl.DAQ.ResetDAQ()
        End If
    End Sub

    Private Sub btnSendDaqConfig_Click(sender As Object, e As EventArgs) Handles btnSendDaqConfig.Click
        ' Sample configuration stuff
        Dim VoltsList() As Integer = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110}
        Dim ScaleList() As Integer = {101, 102, 103, 104, 105}
        TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, VoltsList, "Auto")
        TestSetControl.DAQ.ConfigureScaling(ScaleList, 100, 0, "A")

        TestSetControl.DAQ.SetScanList(VoltsList)


    End Sub

    Private Sub btnScanDaq_Click(sender As Object, e As EventArgs) Handles btnScanDaq.Click
        Dim VoltsList() As Integer = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110}

        TestSetControl.DAQ.ScanChannels(1, 10000)
        Utility.ClearStatusMessage()

        Dim TheMeas As Double, TheUnits As String
        For Each Chan In VoltsList
            TestSetControl.DAQ.GetMeasurementsFromLastScan(Chan, TheMeas, TheUnits)
            Utility.AddStatusMessage("Channel " & Chan.ToString & "  " & TheMeas.ToString & " " & TheUnits)
        Next

    End Sub

End Class
