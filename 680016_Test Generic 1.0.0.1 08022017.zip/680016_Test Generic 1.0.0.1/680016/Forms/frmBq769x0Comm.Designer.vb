﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBq769x0Comm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmBq769x0Comm))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EV2400AdapterDataSheetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Bq769x00DataSheetToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.tlpByte0 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte00 = New System.Windows.Forms.Label()
        Me.Byte01 = New System.Windows.Forms.Label()
        Me.Byte02 = New System.Windows.Forms.Label()
        Me.Byte03 = New System.Windows.Forms.Label()
        Me.Byte04 = New System.Windows.Forms.Label()
        Me.Byte05 = New System.Windows.Forms.Label()
        Me.Byte07 = New System.Windows.Forms.Label()
        Me.Byte06 = New System.Windows.Forms.Label()
        Me.tlpByte2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte20 = New System.Windows.Forms.Label()
        Me.Byte21 = New System.Windows.Forms.Label()
        Me.Byte22 = New System.Windows.Forms.Label()
        Me.Byte23 = New System.Windows.Forms.Label()
        Me.Byte24 = New System.Windows.Forms.Label()
        Me.tlpByte3 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte30 = New System.Windows.Forms.Label()
        Me.Byte31 = New System.Windows.Forms.Label()
        Me.Byte32 = New System.Windows.Forms.Label()
        Me.Byte33 = New System.Windows.Forms.Label()
        Me.Byte34 = New System.Windows.Forms.Label()
        Me.tlpByte1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte10 = New System.Windows.Forms.Label()
        Me.Byte11 = New System.Windows.Forms.Label()
        Me.Byte12 = New System.Windows.Forms.Label()
        Me.Byte13 = New System.Windows.Forms.Label()
        Me.Byte14 = New System.Windows.Forms.Label()
        Me.tlpByte5x = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte50 = New System.Windows.Forms.Label()
        Me.Byte51 = New System.Windows.Forms.Label()
        Me.Byte52 = New System.Windows.Forms.Label()
        Me.Byte53 = New System.Windows.Forms.Label()
        Me.Byte54 = New System.Windows.Forms.Label()
        Me.Byte55 = New System.Windows.Forms.Label()
        Me.Byte57 = New System.Windows.Forms.Label()
        Me.Byte56 = New System.Windows.Forms.Label()
        Me.tlpByte4 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte40 = New System.Windows.Forms.Label()
        Me.Byte41 = New System.Windows.Forms.Label()
        Me.Byte42 = New System.Windows.Forms.Label()
        Me.Byte43 = New System.Windows.Forms.Label()
        Me.Byte44 = New System.Windows.Forms.Label()
        Me.Byte45 = New System.Windows.Forms.Label()
        Me.Byte47 = New System.Windows.Forms.Label()
        Me.Byte46 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt0x0 = New System.Windows.Forms.TextBox()
        Me.tlpByte7 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte70 = New System.Windows.Forms.Label()
        Me.Byte71 = New System.Windows.Forms.Label()
        Me.Byte72 = New System.Windows.Forms.Label()
        Me.Byte73 = New System.Windows.Forms.Label()
        Me.Byte74 = New System.Windows.Forms.Label()
        Me.Byte75 = New System.Windows.Forms.Label()
        Me.Byte77 = New System.Windows.Forms.Label()
        Me.Byte76 = New System.Windows.Forms.Label()
        Me.tlpByte6 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte60 = New System.Windows.Forms.Label()
        Me.Byte61 = New System.Windows.Forms.Label()
        Me.Byte62 = New System.Windows.Forms.Label()
        Me.Byte63 = New System.Windows.Forms.Label()
        Me.Byte64 = New System.Windows.Forms.Label()
        Me.Byte65 = New System.Windows.Forms.Label()
        Me.Byte67 = New System.Windows.Forms.Label()
        Me.Byte66 = New System.Windows.Forms.Label()
        Me.tlpByte8 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte80 = New System.Windows.Forms.Label()
        Me.Byte81 = New System.Windows.Forms.Label()
        Me.Byte82 = New System.Windows.Forms.Label()
        Me.Byte83 = New System.Windows.Forms.Label()
        Me.Byte84 = New System.Windows.Forms.Label()
        Me.Byte85 = New System.Windows.Forms.Label()
        Me.Byte87 = New System.Windows.Forms.Label()
        Me.Byte86 = New System.Windows.Forms.Label()
        Me.tlpByte9 = New System.Windows.Forms.TableLayoutPanel()
        Me.Byte90 = New System.Windows.Forms.Label()
        Me.Byte91 = New System.Windows.Forms.Label()
        Me.Byte92 = New System.Windows.Forms.Label()
        Me.Byte93 = New System.Windows.Forms.Label()
        Me.Byte94 = New System.Windows.Forms.Label()
        Me.Byte95 = New System.Windows.Forms.Label()
        Me.Byte97 = New System.Windows.Forms.Label()
        Me.Byte96 = New System.Windows.Forms.Label()
        Me.tlpByteA = New System.Windows.Forms.TableLayoutPanel()
        Me.ByteA0 = New System.Windows.Forms.Label()
        Me.ByteA1 = New System.Windows.Forms.Label()
        Me.ByteA2 = New System.Windows.Forms.Label()
        Me.ByteA3 = New System.Windows.Forms.Label()
        Me.ByteA4 = New System.Windows.Forms.Label()
        Me.ByteA5 = New System.Windows.Forms.Label()
        Me.ByteA7 = New System.Windows.Forms.Label()
        Me.ByteA6 = New System.Windows.Forms.Label()
        Me.tlpByteB = New System.Windows.Forms.TableLayoutPanel()
        Me.ByteB0 = New System.Windows.Forms.Label()
        Me.ByteB1 = New System.Windows.Forms.Label()
        Me.ByteB2 = New System.Windows.Forms.Label()
        Me.ByteB3 = New System.Windows.Forms.Label()
        Me.ByteB4 = New System.Windows.Forms.Label()
        Me.ByteB5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txt0x4 = New System.Windows.Forms.TextBox()
        Me.txt0x5 = New System.Windows.Forms.TextBox()
        Me.txt0x1 = New System.Windows.Forms.TextBox()
        Me.txt0x2 = New System.Windows.Forms.TextBox()
        Me.txt0x3 = New System.Windows.Forms.TextBox()
        Me.txt0x6 = New System.Windows.Forms.TextBox()
        Me.txt0x7 = New System.Windows.Forms.TextBox()
        Me.txt0x8 = New System.Windows.Forms.TextBox()
        Me.txt0x9 = New System.Windows.Forms.TextBox()
        Me.txt0xA = New System.Windows.Forms.TextBox()
        Me.txt0xB = New System.Windows.Forms.TextBox()
        Me.btnReleaseEV2400 = New System.Windows.Forms.Button()
        Me.btnScanData = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.dgvParamRegisters = New System.Windows.Forms.DataGridView()
        Me.Units = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Value = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Hex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Parameter = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.txtADCGain = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtADCOffset = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.txtResponse = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtWriteVal = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtRegister = New System.Windows.Forms.TextBox()
        Me.btnWriteByte = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.tlpByte0.SuspendLayout()
        Me.tlpByte2.SuspendLayout()
        Me.tlpByte3.SuspendLayout()
        Me.tlpByte1.SuspendLayout()
        Me.tlpByte5x.SuspendLayout()
        Me.tlpByte4.SuspendLayout()
        Me.tlpByte7.SuspendLayout()
        Me.tlpByte6.SuspendLayout()
        Me.tlpByte8.SuspendLayout()
        Me.tlpByte9.SuspendLayout()
        Me.tlpByteA.SuspendLayout()
        Me.tlpByteB.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgvParamRegisters, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(1449, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(92, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EV2400AdapterDataSheetToolStripMenuItem, Me.Bq769x00DataSheetToolStripMenuItem, Me.ToolStripSeparator1, Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'EV2400AdapterDataSheetToolStripMenuItem
        '
        Me.EV2400AdapterDataSheetToolStripMenuItem.Name = "EV2400AdapterDataSheetToolStripMenuItem"
        Me.EV2400AdapterDataSheetToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.EV2400AdapterDataSheetToolStripMenuItem.Text = "EV2400 Adapter Data Sheet"
        '
        'Bq769x00DataSheetToolStripMenuItem
        '
        Me.Bq769x00DataSheetToolStripMenuItem.Name = "Bq769x00DataSheetToolStripMenuItem"
        Me.Bq769x00DataSheetToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.Bq769x00DataSheetToolStripMenuItem.Text = "bq769x00 Data Sheet"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(212, 6)
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(215, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.29054!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.70946!))
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox3, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox2, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.GroupBox1, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel4, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 24)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.676307!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 91.32369!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1449, 899)
        Me.TableLayoutPanel1.TabIndex = 4
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.TableLayoutPanel2)
        Me.GroupBox3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox3.Location = New System.Drawing.Point(1035, 80)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(411, 816)
        Me.GroupBox3.TabIndex = 5
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Stack V/T/I"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TableLayoutPanel3)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Location = New System.Drawing.Point(3, 80)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1026, 816)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "All Read/Write Registers   Green bits low. Red bits high"
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 4
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 50.0!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.01487!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.98513!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 52.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte0, 1, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte2, 1, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte3, 1, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte1, 1, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte5x, 1, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte4, 1, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label1, 2, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x0, 3, 1)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte7, 1, 8)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte6, 1, 7)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte8, 1, 9)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByte9, 1, 10)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByteA, 1, 11)
        Me.TableLayoutPanel3.Controls.Add(Me.tlpByteB, 1, 12)
        Me.TableLayoutPanel3.Controls.Add(Me.Label2, 2, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.Label3, 2, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.Label4, 2, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.Label5, 2, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.Label6, 2, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.Label7, 2, 7)
        Me.TableLayoutPanel3.Controls.Add(Me.Label8, 2, 8)
        Me.TableLayoutPanel3.Controls.Add(Me.Label9, 2, 9)
        Me.TableLayoutPanel3.Controls.Add(Me.Label10, 2, 10)
        Me.TableLayoutPanel3.Controls.Add(Me.Label11, 2, 11)
        Me.TableLayoutPanel3.Controls.Add(Me.Label12, 2, 12)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x4, 3, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x5, 3, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x1, 3, 4)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x2, 3, 5)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x3, 3, 6)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x6, 3, 7)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x7, 3, 8)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x8, 3, 9)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0x9, 3, 10)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0xA, 3, 11)
        Me.TableLayoutPanel3.Controls.Add(Me.txt0xB, 3, 12)
        Me.TableLayoutPanel3.Controls.Add(Me.GroupBox4, 1, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 16)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 13
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle())
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333334!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(1020, 797)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'tlpByte0
        '
        Me.tlpByte0.ColumnCount = 8
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte0.Controls.Add(Me.Byte00, 7, 0)
        Me.tlpByte0.Controls.Add(Me.Byte01, 6, 0)
        Me.tlpByte0.Controls.Add(Me.Byte02, 5, 0)
        Me.tlpByte0.Controls.Add(Me.Byte03, 4, 0)
        Me.tlpByte0.Controls.Add(Me.Byte04, 3, 0)
        Me.tlpByte0.Controls.Add(Me.Byte05, 2, 0)
        Me.tlpByte0.Controls.Add(Me.Byte07, 0, 0)
        Me.tlpByte0.Controls.Add(Me.Byte06, 1, 0)
        Me.tlpByte0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte0.Location = New System.Drawing.Point(53, 112)
        Me.tlpByte0.Name = "tlpByte0"
        Me.tlpByte0.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte0.RowCount = 1
        Me.tlpByte0.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte0.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte0.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte0.TabIndex = 13
        '
        'Byte00
        '
        Me.Byte00.AutoSize = True
        Me.Byte00.BackColor = System.Drawing.Color.Bisque
        Me.Byte00.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte00.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte00.Location = New System.Drawing.Point(669, 10)
        Me.Byte00.Name = "Byte00"
        Me.Byte00.Size = New System.Drawing.Size(92, 31)
        Me.Byte00.TabIndex = 8
        Me.Byte00.Text = "OCD"
        Me.Byte00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte01
        '
        Me.Byte01.AutoSize = True
        Me.Byte01.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte01.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte01.Location = New System.Drawing.Point(574, 10)
        Me.Byte01.Name = "Byte01"
        Me.Byte01.Size = New System.Drawing.Size(89, 31)
        Me.Byte01.TabIndex = 7
        Me.Byte01.Text = "SCD"
        Me.Byte01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte02
        '
        Me.Byte02.AutoSize = True
        Me.Byte02.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte02.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte02.Location = New System.Drawing.Point(479, 10)
        Me.Byte02.Name = "Byte02"
        Me.Byte02.Size = New System.Drawing.Size(89, 31)
        Me.Byte02.TabIndex = 6
        Me.Byte02.Text = "OV"
        Me.Byte02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte03
        '
        Me.Byte03.AutoSize = True
        Me.Byte03.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte03.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte03.Location = New System.Drawing.Point(384, 10)
        Me.Byte03.Name = "Byte03"
        Me.Byte03.Size = New System.Drawing.Size(89, 31)
        Me.Byte03.TabIndex = 5
        Me.Byte03.Text = "UV"
        Me.Byte03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte04
        '
        Me.Byte04.AutoSize = True
        Me.Byte04.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte04.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte04.Location = New System.Drawing.Point(289, 10)
        Me.Byte04.Name = "Byte04"
        Me.Byte04.Size = New System.Drawing.Size(89, 31)
        Me.Byte04.TabIndex = 4
        Me.Byte04.Text = "OVRDAL"
        Me.Byte04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte05
        '
        Me.Byte05.AutoSize = True
        Me.Byte05.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte05.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte05.Location = New System.Drawing.Point(194, 10)
        Me.Byte05.Name = "Byte05"
        Me.Byte05.Size = New System.Drawing.Size(89, 31)
        Me.Byte05.TabIndex = 3
        Me.Byte05.Text = "DEV_XD"
        Me.Byte05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte07
        '
        Me.Byte07.AutoSize = True
        Me.Byte07.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte07.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte07.Location = New System.Drawing.Point(4, 10)
        Me.Byte07.Name = "Byte07"
        Me.Byte07.Size = New System.Drawing.Size(89, 31)
        Me.Byte07.TabIndex = 2
        Me.Byte07.Text = "CCRDY"
        Me.Byte07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte06
        '
        Me.Byte06.AutoSize = True
        Me.Byte06.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte06.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte06.Location = New System.Drawing.Point(99, 10)
        Me.Byte06.Name = "Byte06"
        Me.Byte06.Size = New System.Drawing.Size(89, 31)
        Me.Byte06.TabIndex = 1
        Me.Byte06.Text = "RSVD"
        Me.Byte06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte2
        '
        Me.tlpByte2.ColumnCount = 8
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte2.Controls.Add(Me.Byte20, 7, 0)
        Me.tlpByte2.Controls.Add(Me.Byte21, 6, 0)
        Me.tlpByte2.Controls.Add(Me.Byte22, 5, 0)
        Me.tlpByte2.Controls.Add(Me.Byte23, 4, 0)
        Me.tlpByte2.Controls.Add(Me.Byte24, 3, 0)
        Me.tlpByte2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte2.Location = New System.Drawing.Point(53, 340)
        Me.tlpByte2.Name = "tlpByte2"
        Me.tlpByte2.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte2.RowCount = 1
        Me.tlpByte2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte2.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte2.TabIndex = 12
        '
        'Byte20
        '
        Me.Byte20.AutoSize = True
        Me.Byte20.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte20.Location = New System.Drawing.Point(669, 10)
        Me.Byte20.Name = "Byte20"
        Me.Byte20.Size = New System.Drawing.Size(92, 31)
        Me.Byte20.TabIndex = 8
        Me.Byte20.Text = "CB6"
        Me.Byte20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte21
        '
        Me.Byte21.AutoSize = True
        Me.Byte21.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte21.Location = New System.Drawing.Point(574, 10)
        Me.Byte21.Name = "Byte21"
        Me.Byte21.Size = New System.Drawing.Size(89, 31)
        Me.Byte21.TabIndex = 7
        Me.Byte21.Text = "CB7"
        Me.Byte21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte22
        '
        Me.Byte22.AutoSize = True
        Me.Byte22.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte22.Location = New System.Drawing.Point(479, 10)
        Me.Byte22.Name = "Byte22"
        Me.Byte22.Size = New System.Drawing.Size(89, 31)
        Me.Byte22.TabIndex = 6
        Me.Byte22.Text = "CB8"
        Me.Byte22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte23
        '
        Me.Byte23.AutoSize = True
        Me.Byte23.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte23.Location = New System.Drawing.Point(384, 10)
        Me.Byte23.Name = "Byte23"
        Me.Byte23.Size = New System.Drawing.Size(89, 31)
        Me.Byte23.TabIndex = 5
        Me.Byte23.Text = "CB9"
        Me.Byte23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte24
        '
        Me.Byte24.AutoSize = True
        Me.Byte24.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte24.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte24.Location = New System.Drawing.Point(289, 10)
        Me.Byte24.Name = "Byte24"
        Me.Byte24.Size = New System.Drawing.Size(89, 31)
        Me.Byte24.TabIndex = 4
        Me.Byte24.Text = "CB10"
        Me.Byte24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte3
        '
        Me.tlpByte3.ColumnCount = 8
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte3.Controls.Add(Me.Byte30, 7, 0)
        Me.tlpByte3.Controls.Add(Me.Byte31, 6, 0)
        Me.tlpByte3.Controls.Add(Me.Byte32, 5, 0)
        Me.tlpByte3.Controls.Add(Me.Byte33, 4, 0)
        Me.tlpByte3.Controls.Add(Me.Byte34, 3, 0)
        Me.tlpByte3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte3.Location = New System.Drawing.Point(53, 397)
        Me.tlpByte3.Name = "tlpByte3"
        Me.tlpByte3.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte3.RowCount = 1
        Me.tlpByte3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte3.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte3.TabIndex = 11
        '
        'Byte30
        '
        Me.Byte30.AutoSize = True
        Me.Byte30.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte30.Location = New System.Drawing.Point(669, 10)
        Me.Byte30.Name = "Byte30"
        Me.Byte30.Size = New System.Drawing.Size(92, 31)
        Me.Byte30.TabIndex = 8
        Me.Byte30.Text = "CB11"
        Me.Byte30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte31
        '
        Me.Byte31.AutoSize = True
        Me.Byte31.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte31.Location = New System.Drawing.Point(574, 10)
        Me.Byte31.Name = "Byte31"
        Me.Byte31.Size = New System.Drawing.Size(89, 31)
        Me.Byte31.TabIndex = 7
        Me.Byte31.Text = "CB12"
        Me.Byte31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte32
        '
        Me.Byte32.AutoSize = True
        Me.Byte32.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte32.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte32.Location = New System.Drawing.Point(479, 10)
        Me.Byte32.Name = "Byte32"
        Me.Byte32.Size = New System.Drawing.Size(89, 31)
        Me.Byte32.TabIndex = 6
        Me.Byte32.Text = "CB13"
        Me.Byte32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte33
        '
        Me.Byte33.AutoSize = True
        Me.Byte33.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte33.Location = New System.Drawing.Point(384, 10)
        Me.Byte33.Name = "Byte33"
        Me.Byte33.Size = New System.Drawing.Size(89, 31)
        Me.Byte33.TabIndex = 5
        Me.Byte33.Text = "CB14"
        Me.Byte33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte34
        '
        Me.Byte34.AutoSize = True
        Me.Byte34.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte34.Location = New System.Drawing.Point(289, 10)
        Me.Byte34.Name = "Byte34"
        Me.Byte34.Size = New System.Drawing.Size(89, 31)
        Me.Byte34.TabIndex = 4
        Me.Byte34.Text = "CB15"
        Me.Byte34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte1
        '
        Me.tlpByte1.ColumnCount = 8
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte1.Controls.Add(Me.Byte10, 7, 0)
        Me.tlpByte1.Controls.Add(Me.Byte11, 6, 0)
        Me.tlpByte1.Controls.Add(Me.Byte12, 5, 0)
        Me.tlpByte1.Controls.Add(Me.Byte13, 4, 0)
        Me.tlpByte1.Controls.Add(Me.Byte14, 3, 0)
        Me.tlpByte1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte1.Location = New System.Drawing.Point(53, 283)
        Me.tlpByte1.Name = "tlpByte1"
        Me.tlpByte1.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte1.RowCount = 1
        Me.tlpByte1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte1.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte1.TabIndex = 8
        '
        'Byte10
        '
        Me.Byte10.AutoSize = True
        Me.Byte10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte10.Location = New System.Drawing.Point(669, 10)
        Me.Byte10.Name = "Byte10"
        Me.Byte10.Size = New System.Drawing.Size(92, 31)
        Me.Byte10.TabIndex = 8
        Me.Byte10.Text = "CB1"
        Me.Byte10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte11
        '
        Me.Byte11.AutoSize = True
        Me.Byte11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte11.Location = New System.Drawing.Point(574, 10)
        Me.Byte11.Name = "Byte11"
        Me.Byte11.Size = New System.Drawing.Size(89, 31)
        Me.Byte11.TabIndex = 7
        Me.Byte11.Text = "CB2"
        Me.Byte11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte12
        '
        Me.Byte12.AutoSize = True
        Me.Byte12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte12.Location = New System.Drawing.Point(479, 10)
        Me.Byte12.Name = "Byte12"
        Me.Byte12.Size = New System.Drawing.Size(89, 31)
        Me.Byte12.TabIndex = 6
        Me.Byte12.Text = "CB3"
        Me.Byte12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte13
        '
        Me.Byte13.AutoSize = True
        Me.Byte13.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte13.Location = New System.Drawing.Point(384, 10)
        Me.Byte13.Name = "Byte13"
        Me.Byte13.Size = New System.Drawing.Size(89, 31)
        Me.Byte13.TabIndex = 5
        Me.Byte13.Text = "CB4"
        Me.Byte13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte14
        '
        Me.Byte14.AutoSize = True
        Me.Byte14.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte14.Location = New System.Drawing.Point(289, 10)
        Me.Byte14.Name = "Byte14"
        Me.Byte14.Size = New System.Drawing.Size(89, 31)
        Me.Byte14.TabIndex = 4
        Me.Byte14.Text = "CB5"
        Me.Byte14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte5x
        '
        Me.tlpByte5x.ColumnCount = 8
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte5x.Controls.Add(Me.Byte50, 7, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte51, 6, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte52, 5, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte53, 4, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte54, 3, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte55, 2, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte57, 0, 0)
        Me.tlpByte5x.Controls.Add(Me.Byte56, 1, 0)
        Me.tlpByte5x.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte5x.Location = New System.Drawing.Point(53, 226)
        Me.tlpByte5x.Name = "tlpByte5x"
        Me.tlpByte5x.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte5x.RowCount = 1
        Me.tlpByte5x.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte5x.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte5x.TabIndex = 7
        '
        'Byte50
        '
        Me.Byte50.AutoSize = True
        Me.Byte50.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte50.Location = New System.Drawing.Point(669, 10)
        Me.Byte50.Name = "Byte50"
        Me.Byte50.Size = New System.Drawing.Size(92, 31)
        Me.Byte50.TabIndex = 8
        Me.Byte50.Text = "CHG_ON"
        Me.Byte50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte51
        '
        Me.Byte51.AutoSize = True
        Me.Byte51.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte51.Location = New System.Drawing.Point(574, 10)
        Me.Byte51.Name = "Byte51"
        Me.Byte51.Size = New System.Drawing.Size(89, 31)
        Me.Byte51.TabIndex = 7
        Me.Byte51.Text = "DSG_ON"
        Me.Byte51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte52
        '
        Me.Byte52.AutoSize = True
        Me.Byte52.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte52.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte52.Location = New System.Drawing.Point(479, 10)
        Me.Byte52.Name = "Byte52"
        Me.Byte52.Size = New System.Drawing.Size(89, 31)
        Me.Byte52.TabIndex = 6
        Me.Byte52.Text = "RSVD"
        Me.Byte52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte53
        '
        Me.Byte53.AutoSize = True
        Me.Byte53.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte53.Location = New System.Drawing.Point(384, 10)
        Me.Byte53.Name = "Byte53"
        Me.Byte53.Size = New System.Drawing.Size(89, 31)
        Me.Byte53.TabIndex = 5
        Me.Byte53.Text = "RSVD"
        Me.Byte53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte54
        '
        Me.Byte54.AutoSize = True
        Me.Byte54.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte54.Location = New System.Drawing.Point(289, 10)
        Me.Byte54.Name = "Byte54"
        Me.Byte54.Size = New System.Drawing.Size(89, 31)
        Me.Byte54.TabIndex = 4
        Me.Byte54.Text = "RSVD"
        Me.Byte54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte55
        '
        Me.Byte55.AutoSize = True
        Me.Byte55.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte55.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte55.Location = New System.Drawing.Point(194, 10)
        Me.Byte55.Name = "Byte55"
        Me.Byte55.Size = New System.Drawing.Size(89, 31)
        Me.Byte55.TabIndex = 3
        Me.Byte55.Text = "CC_ONE"
        Me.Byte55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte57
        '
        Me.Byte57.AutoSize = True
        Me.Byte57.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte57.Location = New System.Drawing.Point(4, 10)
        Me.Byte57.Name = "Byte57"
        Me.Byte57.Size = New System.Drawing.Size(89, 31)
        Me.Byte57.TabIndex = 2
        Me.Byte57.Text = "DLY_DIS"
        Me.Byte57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte56
        '
        Me.Byte56.AutoSize = True
        Me.Byte56.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte56.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte56.Location = New System.Drawing.Point(99, 10)
        Me.Byte56.Name = "Byte56"
        Me.Byte56.Size = New System.Drawing.Size(89, 31)
        Me.Byte56.TabIndex = 1
        Me.Byte56.Text = "CC_EN"
        Me.Byte56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte4
        '
        Me.tlpByte4.ColumnCount = 8
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte4.Controls.Add(Me.Byte40, 7, 0)
        Me.tlpByte4.Controls.Add(Me.Byte41, 6, 0)
        Me.tlpByte4.Controls.Add(Me.Byte42, 5, 0)
        Me.tlpByte4.Controls.Add(Me.Byte43, 4, 0)
        Me.tlpByte4.Controls.Add(Me.Byte44, 3, 0)
        Me.tlpByte4.Controls.Add(Me.Byte45, 2, 0)
        Me.tlpByte4.Controls.Add(Me.Byte47, 0, 0)
        Me.tlpByte4.Controls.Add(Me.Byte46, 1, 0)
        Me.tlpByte4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte4.Location = New System.Drawing.Point(53, 169)
        Me.tlpByte4.Name = "tlpByte4"
        Me.tlpByte4.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte4.RowCount = 1
        Me.tlpByte4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte4.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte4.TabIndex = 6
        '
        'Byte40
        '
        Me.Byte40.AutoSize = True
        Me.Byte40.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte40.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte40.Location = New System.Drawing.Point(669, 10)
        Me.Byte40.Name = "Byte40"
        Me.Byte40.Size = New System.Drawing.Size(92, 31)
        Me.Byte40.TabIndex = 8
        Me.Byte40.Text = "SHUT_B"
        Me.Byte40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte41
        '
        Me.Byte41.AutoSize = True
        Me.Byte41.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte41.Location = New System.Drawing.Point(574, 10)
        Me.Byte41.Name = "Byte41"
        Me.Byte41.Size = New System.Drawing.Size(89, 31)
        Me.Byte41.TabIndex = 7
        Me.Byte41.Text = "SHUT_A"
        Me.Byte41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte42
        '
        Me.Byte42.AutoSize = True
        Me.Byte42.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte42.Location = New System.Drawing.Point(479, 10)
        Me.Byte42.Name = "Byte42"
        Me.Byte42.Size = New System.Drawing.Size(89, 31)
        Me.Byte42.TabIndex = 6
        Me.Byte42.Text = "RSVD"
        Me.Byte42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte43
        '
        Me.Byte43.AutoSize = True
        Me.Byte43.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte43.Location = New System.Drawing.Point(384, 10)
        Me.Byte43.Name = "Byte43"
        Me.Byte43.Size = New System.Drawing.Size(89, 31)
        Me.Byte43.TabIndex = 5
        Me.Byte43.Text = "TEMP_S"
        Me.Byte43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte44
        '
        Me.Byte44.AutoSize = True
        Me.Byte44.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte44.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte44.Location = New System.Drawing.Point(289, 10)
        Me.Byte44.Name = "Byte44"
        Me.Byte44.Size = New System.Drawing.Size(89, 31)
        Me.Byte44.TabIndex = 4
        Me.Byte44.Text = "ADC_EN"
        Me.Byte44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte45
        '
        Me.Byte45.AutoSize = True
        Me.Byte45.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte45.Location = New System.Drawing.Point(194, 10)
        Me.Byte45.Name = "Byte45"
        Me.Byte45.Size = New System.Drawing.Size(89, 31)
        Me.Byte45.TabIndex = 3
        Me.Byte45.Text = "RSVD"
        Me.Byte45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte47
        '
        Me.Byte47.AutoSize = True
        Me.Byte47.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte47.Location = New System.Drawing.Point(4, 10)
        Me.Byte47.Name = "Byte47"
        Me.Byte47.Size = New System.Drawing.Size(89, 31)
        Me.Byte47.TabIndex = 2
        Me.Byte47.Text = "LOAD_P"
        Me.Byte47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte46
        '
        Me.Byte46.AutoSize = True
        Me.Byte46.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte46.Location = New System.Drawing.Point(99, 10)
        Me.Byte46.Name = "Byte46"
        Me.Byte46.Size = New System.Drawing.Size(89, 31)
        Me.Byte46.TabIndex = 1
        Me.Byte46.Text = "RSVD"
        Me.Byte46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(824, 109)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 57)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "System Status (0x0)"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt0x0
        '
        Me.txt0x0.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x0.Location = New System.Drawing.Point(970, 127)
        Me.txt0x0.Name = "txt0x0"
        Me.txt0x0.Size = New System.Drawing.Size(29, 20)
        Me.txt0x0.TabIndex = 5
        Me.txt0x0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'tlpByte7
        '
        Me.tlpByte7.ColumnCount = 8
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte7.Controls.Add(Me.Byte70, 7, 0)
        Me.tlpByte7.Controls.Add(Me.Byte71, 6, 0)
        Me.tlpByte7.Controls.Add(Me.Byte72, 5, 0)
        Me.tlpByte7.Controls.Add(Me.Byte73, 4, 0)
        Me.tlpByte7.Controls.Add(Me.Byte74, 3, 0)
        Me.tlpByte7.Controls.Add(Me.Byte75, 2, 0)
        Me.tlpByte7.Controls.Add(Me.Byte77, 0, 0)
        Me.tlpByte7.Controls.Add(Me.Byte76, 1, 0)
        Me.tlpByte7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte7.Location = New System.Drawing.Point(53, 511)
        Me.tlpByte7.Name = "tlpByte7"
        Me.tlpByte7.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte7.RowCount = 1
        Me.tlpByte7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte7.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte7.TabIndex = 10
        '
        'Byte70
        '
        Me.Byte70.AutoSize = True
        Me.Byte70.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte70.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte70.Location = New System.Drawing.Point(669, 10)
        Me.Byte70.Name = "Byte70"
        Me.Byte70.Size = New System.Drawing.Size(92, 31)
        Me.Byte70.TabIndex = 8
        Me.Byte70.Text = "OCD_T0"
        Me.Byte70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte71
        '
        Me.Byte71.AutoSize = True
        Me.Byte71.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte71.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte71.Location = New System.Drawing.Point(574, 10)
        Me.Byte71.Name = "Byte71"
        Me.Byte71.Size = New System.Drawing.Size(89, 31)
        Me.Byte71.TabIndex = 7
        Me.Byte71.Text = "OCD_T1"
        Me.Byte71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte72
        '
        Me.Byte72.AutoSize = True
        Me.Byte72.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte72.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte72.Location = New System.Drawing.Point(479, 10)
        Me.Byte72.Name = "Byte72"
        Me.Byte72.Size = New System.Drawing.Size(89, 31)
        Me.Byte72.TabIndex = 6
        Me.Byte72.Text = "OCD_T2"
        Me.Byte72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte73
        '
        Me.Byte73.AutoSize = True
        Me.Byte73.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte73.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte73.Location = New System.Drawing.Point(384, 10)
        Me.Byte73.Name = "Byte73"
        Me.Byte73.Size = New System.Drawing.Size(89, 31)
        Me.Byte73.TabIndex = 5
        Me.Byte73.Text = "OCD_T3"
        Me.Byte73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte74
        '
        Me.Byte74.AutoSize = True
        Me.Byte74.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte74.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte74.Location = New System.Drawing.Point(289, 10)
        Me.Byte74.Name = "Byte74"
        Me.Byte74.Size = New System.Drawing.Size(89, 31)
        Me.Byte74.TabIndex = 4
        Me.Byte74.Text = "OCD_D0"
        Me.Byte74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte75
        '
        Me.Byte75.AutoSize = True
        Me.Byte75.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte75.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte75.Location = New System.Drawing.Point(194, 10)
        Me.Byte75.Name = "Byte75"
        Me.Byte75.Size = New System.Drawing.Size(89, 31)
        Me.Byte75.TabIndex = 3
        Me.Byte75.Text = "OCD_D1"
        Me.Byte75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte77
        '
        Me.Byte77.AutoSize = True
        Me.Byte77.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte77.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte77.Location = New System.Drawing.Point(4, 10)
        Me.Byte77.Name = "Byte77"
        Me.Byte77.Size = New System.Drawing.Size(89, 31)
        Me.Byte77.TabIndex = 2
        Me.Byte77.Text = "UV_D1"
        Me.Byte77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte76
        '
        Me.Byte76.AutoSize = True
        Me.Byte76.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte76.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte76.Location = New System.Drawing.Point(99, 10)
        Me.Byte76.Name = "Byte76"
        Me.Byte76.Size = New System.Drawing.Size(89, 31)
        Me.Byte76.TabIndex = 1
        Me.Byte76.Text = "UV_D0"
        Me.Byte76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte6
        '
        Me.tlpByte6.ColumnCount = 8
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte6.Controls.Add(Me.Byte60, 7, 0)
        Me.tlpByte6.Controls.Add(Me.Byte61, 6, 0)
        Me.tlpByte6.Controls.Add(Me.Byte62, 5, 0)
        Me.tlpByte6.Controls.Add(Me.Byte63, 4, 0)
        Me.tlpByte6.Controls.Add(Me.Byte64, 3, 0)
        Me.tlpByte6.Controls.Add(Me.Byte65, 2, 0)
        Me.tlpByte6.Controls.Add(Me.Byte67, 0, 0)
        Me.tlpByte6.Controls.Add(Me.Byte66, 1, 0)
        Me.tlpByte6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte6.Location = New System.Drawing.Point(53, 454)
        Me.tlpByte6.Name = "tlpByte6"
        Me.tlpByte6.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte6.RowCount = 1
        Me.tlpByte6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte6.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte6.TabIndex = 10
        '
        'Byte60
        '
        Me.Byte60.AutoSize = True
        Me.Byte60.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte60.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte60.Location = New System.Drawing.Point(669, 10)
        Me.Byte60.Name = "Byte60"
        Me.Byte60.Size = New System.Drawing.Size(92, 31)
        Me.Byte60.TabIndex = 8
        Me.Byte60.Text = "SCD_T0"
        Me.Byte60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte61
        '
        Me.Byte61.AutoSize = True
        Me.Byte61.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte61.Location = New System.Drawing.Point(574, 10)
        Me.Byte61.Name = "Byte61"
        Me.Byte61.Size = New System.Drawing.Size(89, 31)
        Me.Byte61.TabIndex = 7
        Me.Byte61.Text = "SCD_T1"
        Me.Byte61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte62
        '
        Me.Byte62.AutoSize = True
        Me.Byte62.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte62.Location = New System.Drawing.Point(479, 10)
        Me.Byte62.Name = "Byte62"
        Me.Byte62.Size = New System.Drawing.Size(89, 31)
        Me.Byte62.TabIndex = 6
        Me.Byte62.Text = "SCD_T2"
        Me.Byte62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte63
        '
        Me.Byte63.AutoSize = True
        Me.Byte63.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte63.Location = New System.Drawing.Point(384, 10)
        Me.Byte63.Name = "Byte63"
        Me.Byte63.Size = New System.Drawing.Size(89, 31)
        Me.Byte63.TabIndex = 5
        Me.Byte63.Text = "SCD_D0"
        Me.Byte63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte64
        '
        Me.Byte64.AutoSize = True
        Me.Byte64.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte64.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte64.Location = New System.Drawing.Point(289, 10)
        Me.Byte64.Name = "Byte64"
        Me.Byte64.Size = New System.Drawing.Size(89, 31)
        Me.Byte64.TabIndex = 4
        Me.Byte64.Text = "SCD_D1"
        Me.Byte64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte65
        '
        Me.Byte65.AutoSize = True
        Me.Byte65.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte65.Location = New System.Drawing.Point(194, 10)
        Me.Byte65.Name = "Byte65"
        Me.Byte65.Size = New System.Drawing.Size(89, 31)
        Me.Byte65.TabIndex = 3
        Me.Byte65.Text = "RSVD"
        Me.Byte65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte67
        '
        Me.Byte67.AutoSize = True
        Me.Byte67.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte67.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte67.Location = New System.Drawing.Point(4, 10)
        Me.Byte67.Name = "Byte67"
        Me.Byte67.Size = New System.Drawing.Size(89, 31)
        Me.Byte67.TabIndex = 2
        Me.Byte67.Text = "RSNS"
        Me.Byte67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte66
        '
        Me.Byte66.AutoSize = True
        Me.Byte66.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte66.Location = New System.Drawing.Point(99, 10)
        Me.Byte66.Name = "Byte66"
        Me.Byte66.Size = New System.Drawing.Size(89, 31)
        Me.Byte66.TabIndex = 1
        Me.Byte66.Text = "RSVD"
        Me.Byte66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte8
        '
        Me.tlpByte8.ColumnCount = 8
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte8.Controls.Add(Me.Byte80, 7, 0)
        Me.tlpByte8.Controls.Add(Me.Byte81, 6, 0)
        Me.tlpByte8.Controls.Add(Me.Byte82, 5, 0)
        Me.tlpByte8.Controls.Add(Me.Byte83, 4, 0)
        Me.tlpByte8.Controls.Add(Me.Byte84, 3, 0)
        Me.tlpByte8.Controls.Add(Me.Byte85, 2, 0)
        Me.tlpByte8.Controls.Add(Me.Byte87, 0, 0)
        Me.tlpByte8.Controls.Add(Me.Byte86, 1, 0)
        Me.tlpByte8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte8.Location = New System.Drawing.Point(53, 568)
        Me.tlpByte8.Name = "tlpByte8"
        Me.tlpByte8.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte8.RowCount = 1
        Me.tlpByte8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte8.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte8.TabIndex = 10
        '
        'Byte80
        '
        Me.Byte80.AutoSize = True
        Me.Byte80.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte80.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte80.Location = New System.Drawing.Point(669, 10)
        Me.Byte80.Name = "Byte80"
        Me.Byte80.Size = New System.Drawing.Size(92, 31)
        Me.Byte80.TabIndex = 8
        Me.Byte80.Text = "RSVD"
        Me.Byte80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte81
        '
        Me.Byte81.AutoSize = True
        Me.Byte81.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte81.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte81.Location = New System.Drawing.Point(574, 10)
        Me.Byte81.Name = "Byte81"
        Me.Byte81.Size = New System.Drawing.Size(89, 31)
        Me.Byte81.TabIndex = 7
        Me.Byte81.Text = "RSVD"
        Me.Byte81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte82
        '
        Me.Byte82.AutoSize = True
        Me.Byte82.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte82.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte82.Location = New System.Drawing.Point(479, 10)
        Me.Byte82.Name = "Byte82"
        Me.Byte82.Size = New System.Drawing.Size(89, 31)
        Me.Byte82.TabIndex = 6
        Me.Byte82.Text = "RSVD"
        Me.Byte82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte83
        '
        Me.Byte83.AutoSize = True
        Me.Byte83.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte83.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte83.Location = New System.Drawing.Point(384, 10)
        Me.Byte83.Name = "Byte83"
        Me.Byte83.Size = New System.Drawing.Size(89, 31)
        Me.Byte83.TabIndex = 5
        Me.Byte83.Text = "RSVD"
        Me.Byte83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte84
        '
        Me.Byte84.AutoSize = True
        Me.Byte84.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte84.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte84.Location = New System.Drawing.Point(289, 10)
        Me.Byte84.Name = "Byte84"
        Me.Byte84.Size = New System.Drawing.Size(89, 31)
        Me.Byte84.TabIndex = 4
        Me.Byte84.Text = "OV_D0"
        Me.Byte84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte85
        '
        Me.Byte85.AutoSize = True
        Me.Byte85.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte85.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte85.Location = New System.Drawing.Point(194, 10)
        Me.Byte85.Name = "Byte85"
        Me.Byte85.Size = New System.Drawing.Size(89, 31)
        Me.Byte85.TabIndex = 3
        Me.Byte85.Text = "OV_D1"
        Me.Byte85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte87
        '
        Me.Byte87.AutoSize = True
        Me.Byte87.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte87.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte87.Location = New System.Drawing.Point(4, 10)
        Me.Byte87.Name = "Byte87"
        Me.Byte87.Size = New System.Drawing.Size(89, 31)
        Me.Byte87.TabIndex = 2
        Me.Byte87.Text = "UV_D1"
        Me.Byte87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte86
        '
        Me.Byte86.AutoSize = True
        Me.Byte86.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte86.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte86.Location = New System.Drawing.Point(99, 10)
        Me.Byte86.Name = "Byte86"
        Me.Byte86.Size = New System.Drawing.Size(89, 31)
        Me.Byte86.TabIndex = 1
        Me.Byte86.Text = "UV_D0"
        Me.Byte86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByte9
        '
        Me.tlpByte9.ColumnCount = 8
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByte9.Controls.Add(Me.Byte90, 7, 0)
        Me.tlpByte9.Controls.Add(Me.Byte91, 6, 0)
        Me.tlpByte9.Controls.Add(Me.Byte92, 5, 0)
        Me.tlpByte9.Controls.Add(Me.Byte93, 4, 0)
        Me.tlpByte9.Controls.Add(Me.Byte94, 3, 0)
        Me.tlpByte9.Controls.Add(Me.Byte95, 2, 0)
        Me.tlpByte9.Controls.Add(Me.Byte97, 0, 0)
        Me.tlpByte9.Controls.Add(Me.Byte96, 1, 0)
        Me.tlpByte9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByte9.Location = New System.Drawing.Point(53, 625)
        Me.tlpByte9.Name = "tlpByte9"
        Me.tlpByte9.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByte9.RowCount = 1
        Me.tlpByte9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByte9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByte9.Size = New System.Drawing.Size(765, 51)
        Me.tlpByte9.TabIndex = 10
        '
        'Byte90
        '
        Me.Byte90.AutoSize = True
        Me.Byte90.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte90.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte90.Location = New System.Drawing.Point(669, 10)
        Me.Byte90.Name = "Byte90"
        Me.Byte90.Size = New System.Drawing.Size(92, 31)
        Me.Byte90.TabIndex = 8
        Me.Byte90.Text = "OV_T0"
        Me.Byte90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte91
        '
        Me.Byte91.AutoSize = True
        Me.Byte91.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte91.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte91.Location = New System.Drawing.Point(574, 10)
        Me.Byte91.Name = "Byte91"
        Me.Byte91.Size = New System.Drawing.Size(89, 31)
        Me.Byte91.TabIndex = 7
        Me.Byte91.Text = "OV_T1"
        Me.Byte91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte92
        '
        Me.Byte92.AutoSize = True
        Me.Byte92.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte92.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte92.Location = New System.Drawing.Point(479, 10)
        Me.Byte92.Name = "Byte92"
        Me.Byte92.Size = New System.Drawing.Size(89, 31)
        Me.Byte92.TabIndex = 6
        Me.Byte92.Text = "OV_T2"
        Me.Byte92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte93
        '
        Me.Byte93.AutoSize = True
        Me.Byte93.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte93.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte93.Location = New System.Drawing.Point(384, 10)
        Me.Byte93.Name = "Byte93"
        Me.Byte93.Size = New System.Drawing.Size(89, 31)
        Me.Byte93.TabIndex = 5
        Me.Byte93.Text = "OV_T3"
        Me.Byte93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte94
        '
        Me.Byte94.AutoSize = True
        Me.Byte94.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte94.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte94.Location = New System.Drawing.Point(289, 10)
        Me.Byte94.Name = "Byte94"
        Me.Byte94.Size = New System.Drawing.Size(89, 31)
        Me.Byte94.TabIndex = 4
        Me.Byte94.Text = "OV_T4"
        Me.Byte94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte95
        '
        Me.Byte95.AutoSize = True
        Me.Byte95.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte95.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte95.Location = New System.Drawing.Point(194, 10)
        Me.Byte95.Name = "Byte95"
        Me.Byte95.Size = New System.Drawing.Size(89, 31)
        Me.Byte95.TabIndex = 3
        Me.Byte95.Text = "OV_T5"
        Me.Byte95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte97
        '
        Me.Byte97.AutoSize = True
        Me.Byte97.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte97.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte97.Location = New System.Drawing.Point(4, 10)
        Me.Byte97.Name = "Byte97"
        Me.Byte97.Size = New System.Drawing.Size(89, 31)
        Me.Byte97.TabIndex = 2
        Me.Byte97.Text = "OV_T7"
        Me.Byte97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Byte96
        '
        Me.Byte96.AutoSize = True
        Me.Byte96.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Byte96.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Byte96.Location = New System.Drawing.Point(99, 10)
        Me.Byte96.Name = "Byte96"
        Me.Byte96.Size = New System.Drawing.Size(89, 31)
        Me.Byte96.TabIndex = 1
        Me.Byte96.Text = "OV_T6"
        Me.Byte96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByteA
        '
        Me.tlpByteA.ColumnCount = 8
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteA.Controls.Add(Me.ByteA0, 7, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA1, 6, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA2, 5, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA3, 4, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA4, 3, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA5, 2, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA7, 0, 0)
        Me.tlpByteA.Controls.Add(Me.ByteA6, 1, 0)
        Me.tlpByteA.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByteA.Location = New System.Drawing.Point(53, 682)
        Me.tlpByteA.Name = "tlpByteA"
        Me.tlpByteA.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByteA.RowCount = 1
        Me.tlpByteA.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByteA.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByteA.Size = New System.Drawing.Size(765, 51)
        Me.tlpByteA.TabIndex = 10
        '
        'ByteA0
        '
        Me.ByteA0.AutoSize = True
        Me.ByteA0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA0.Location = New System.Drawing.Point(669, 10)
        Me.ByteA0.Name = "ByteA0"
        Me.ByteA0.Size = New System.Drawing.Size(92, 31)
        Me.ByteA0.TabIndex = 8
        Me.ByteA0.Text = "UV_T0"
        Me.ByteA0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA1
        '
        Me.ByteA1.AutoSize = True
        Me.ByteA1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA1.Location = New System.Drawing.Point(574, 10)
        Me.ByteA1.Name = "ByteA1"
        Me.ByteA1.Size = New System.Drawing.Size(89, 31)
        Me.ByteA1.TabIndex = 7
        Me.ByteA1.Text = "UV_T1"
        Me.ByteA1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA2
        '
        Me.ByteA2.AutoSize = True
        Me.ByteA2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA2.Location = New System.Drawing.Point(479, 10)
        Me.ByteA2.Name = "ByteA2"
        Me.ByteA2.Size = New System.Drawing.Size(89, 31)
        Me.ByteA2.TabIndex = 6
        Me.ByteA2.Text = "UV_T2"
        Me.ByteA2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA3
        '
        Me.ByteA3.AutoSize = True
        Me.ByteA3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA3.Location = New System.Drawing.Point(384, 10)
        Me.ByteA3.Name = "ByteA3"
        Me.ByteA3.Size = New System.Drawing.Size(89, 31)
        Me.ByteA3.TabIndex = 5
        Me.ByteA3.Text = "UV_T3"
        Me.ByteA3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA4
        '
        Me.ByteA4.AutoSize = True
        Me.ByteA4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA4.Location = New System.Drawing.Point(289, 10)
        Me.ByteA4.Name = "ByteA4"
        Me.ByteA4.Size = New System.Drawing.Size(89, 31)
        Me.ByteA4.TabIndex = 4
        Me.ByteA4.Text = "UV_T4"
        Me.ByteA4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA5
        '
        Me.ByteA5.AutoSize = True
        Me.ByteA5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA5.Location = New System.Drawing.Point(194, 10)
        Me.ByteA5.Name = "ByteA5"
        Me.ByteA5.Size = New System.Drawing.Size(89, 31)
        Me.ByteA5.TabIndex = 3
        Me.ByteA5.Text = "UV_T5"
        Me.ByteA5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA7
        '
        Me.ByteA7.AutoSize = True
        Me.ByteA7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA7.Location = New System.Drawing.Point(4, 10)
        Me.ByteA7.Name = "ByteA7"
        Me.ByteA7.Size = New System.Drawing.Size(89, 31)
        Me.ByteA7.TabIndex = 2
        Me.ByteA7.Text = "UV_T7"
        Me.ByteA7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteA6
        '
        Me.ByteA6.AutoSize = True
        Me.ByteA6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteA6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteA6.Location = New System.Drawing.Point(99, 10)
        Me.ByteA6.Name = "ByteA6"
        Me.ByteA6.Size = New System.Drawing.Size(89, 31)
        Me.ByteA6.TabIndex = 1
        Me.ByteA6.Text = "UV_T6"
        Me.ByteA6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'tlpByteB
        '
        Me.tlpByteB.ColumnCount = 8
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 12.5!))
        Me.tlpByteB.Controls.Add(Me.ByteB0, 7, 0)
        Me.tlpByteB.Controls.Add(Me.ByteB1, 6, 0)
        Me.tlpByteB.Controls.Add(Me.ByteB2, 5, 0)
        Me.tlpByteB.Controls.Add(Me.ByteB3, 4, 0)
        Me.tlpByteB.Controls.Add(Me.ByteB4, 3, 0)
        Me.tlpByteB.Controls.Add(Me.ByteB5, 2, 0)
        Me.tlpByteB.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpByteB.Location = New System.Drawing.Point(53, 739)
        Me.tlpByteB.Name = "tlpByteB"
        Me.tlpByteB.Padding = New System.Windows.Forms.Padding(1, 10, 1, 10)
        Me.tlpByteB.RowCount = 1
        Me.tlpByteB.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.tlpByteB.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.tlpByteB.Size = New System.Drawing.Size(765, 55)
        Me.tlpByteB.TabIndex = 10
        '
        'ByteB0
        '
        Me.ByteB0.AutoSize = True
        Me.ByteB0.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB0.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB0.Location = New System.Drawing.Point(669, 10)
        Me.ByteB0.Name = "ByteB0"
        Me.ByteB0.Size = New System.Drawing.Size(92, 35)
        Me.ByteB0.TabIndex = 8
        Me.ByteB0.Text = "CC_CFG0"
        Me.ByteB0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteB1
        '
        Me.ByteB1.AutoSize = True
        Me.ByteB1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB1.Location = New System.Drawing.Point(574, 10)
        Me.ByteB1.Name = "ByteB1"
        Me.ByteB1.Size = New System.Drawing.Size(89, 35)
        Me.ByteB1.TabIndex = 7
        Me.ByteB1.Text = "CC_CFG1"
        Me.ByteB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteB2
        '
        Me.ByteB2.AutoSize = True
        Me.ByteB2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB2.Location = New System.Drawing.Point(479, 10)
        Me.ByteB2.Name = "ByteB2"
        Me.ByteB2.Size = New System.Drawing.Size(89, 35)
        Me.ByteB2.TabIndex = 6
        Me.ByteB2.Text = "CC_CFG2"
        Me.ByteB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteB3
        '
        Me.ByteB3.AutoSize = True
        Me.ByteB3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB3.Location = New System.Drawing.Point(384, 10)
        Me.ByteB3.Name = "ByteB3"
        Me.ByteB3.Size = New System.Drawing.Size(89, 35)
        Me.ByteB3.TabIndex = 5
        Me.ByteB3.Text = "CC_CFG3"
        Me.ByteB3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteB4
        '
        Me.ByteB4.AutoSize = True
        Me.ByteB4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB4.Location = New System.Drawing.Point(289, 10)
        Me.ByteB4.Name = "ByteB4"
        Me.ByteB4.Size = New System.Drawing.Size(89, 35)
        Me.ByteB4.TabIndex = 4
        Me.ByteB4.Text = "CC_CFG4"
        Me.ByteB4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ByteB5
        '
        Me.ByteB5.AutoSize = True
        Me.ByteB5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ByteB5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ByteB5.Location = New System.Drawing.Point(194, 10)
        Me.ByteB5.Name = "ByteB5"
        Me.ByteB5.Size = New System.Drawing.Size(89, 35)
        Me.ByteB5.TabIndex = 3
        Me.ByteB5.Text = "CC_CFG5"
        Me.ByteB5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(824, 166)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(140, 57)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "System Control1 (0x4)"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(824, 223)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(140, 57)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "System Control2 (0x5)"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(824, 280)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(140, 57)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Cell Balance 1 (0x1)"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(824, 337)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(140, 57)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Cell Balance 2 (0x2)"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(824, 394)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(140, 57)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Cell Balance 3 (0x3)"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(824, 451)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(140, 57)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Protection 1 (0x6)"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(824, 508)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(140, 57)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Protection 2 (0x7)"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(824, 565)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(140, 57)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Protection 3 (0x8)"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(824, 622)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(140, 57)
        Me.Label10.TabIndex = 4
        Me.Label10.Text = "OV_TRIP (0x9)"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(824, 679)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(140, 57)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "UV_TRIP ()xA)"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(824, 736)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(140, 61)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "CC_CFG (0xB)"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt0x4
        '
        Me.txt0x4.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x4.Location = New System.Drawing.Point(970, 184)
        Me.txt0x4.Name = "txt0x4"
        Me.txt0x4.Size = New System.Drawing.Size(29, 20)
        Me.txt0x4.TabIndex = 5
        Me.txt0x4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x5
        '
        Me.txt0x5.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x5.Location = New System.Drawing.Point(970, 241)
        Me.txt0x5.Name = "txt0x5"
        Me.txt0x5.Size = New System.Drawing.Size(29, 20)
        Me.txt0x5.TabIndex = 5
        Me.txt0x5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x1
        '
        Me.txt0x1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x1.Location = New System.Drawing.Point(970, 298)
        Me.txt0x1.Name = "txt0x1"
        Me.txt0x1.Size = New System.Drawing.Size(29, 20)
        Me.txt0x1.TabIndex = 5
        Me.txt0x1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x2
        '
        Me.txt0x2.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x2.Location = New System.Drawing.Point(970, 355)
        Me.txt0x2.Name = "txt0x2"
        Me.txt0x2.Size = New System.Drawing.Size(29, 20)
        Me.txt0x2.TabIndex = 5
        Me.txt0x2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x3
        '
        Me.txt0x3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x3.Location = New System.Drawing.Point(970, 412)
        Me.txt0x3.Name = "txt0x3"
        Me.txt0x3.Size = New System.Drawing.Size(29, 20)
        Me.txt0x3.TabIndex = 5
        Me.txt0x3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x6
        '
        Me.txt0x6.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x6.Location = New System.Drawing.Point(970, 469)
        Me.txt0x6.Name = "txt0x6"
        Me.txt0x6.Size = New System.Drawing.Size(29, 20)
        Me.txt0x6.TabIndex = 5
        Me.txt0x6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x7
        '
        Me.txt0x7.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x7.Location = New System.Drawing.Point(970, 526)
        Me.txt0x7.Name = "txt0x7"
        Me.txt0x7.Size = New System.Drawing.Size(29, 20)
        Me.txt0x7.TabIndex = 5
        Me.txt0x7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x8
        '
        Me.txt0x8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x8.Location = New System.Drawing.Point(970, 583)
        Me.txt0x8.Name = "txt0x8"
        Me.txt0x8.Size = New System.Drawing.Size(29, 20)
        Me.txt0x8.TabIndex = 5
        Me.txt0x8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0x9
        '
        Me.txt0x9.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0x9.Location = New System.Drawing.Point(970, 640)
        Me.txt0x9.Name = "txt0x9"
        Me.txt0x9.Size = New System.Drawing.Size(29, 20)
        Me.txt0x9.TabIndex = 5
        Me.txt0x9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0xA
        '
        Me.txt0xA.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0xA.Location = New System.Drawing.Point(970, 697)
        Me.txt0xA.Name = "txt0xA"
        Me.txt0xA.Size = New System.Drawing.Size(29, 20)
        Me.txt0xA.TabIndex = 5
        Me.txt0xA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt0xB
        '
        Me.txt0xB.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txt0xB.Location = New System.Drawing.Point(970, 756)
        Me.txt0xB.Name = "txt0xB"
        Me.txt0xB.Size = New System.Drawing.Size(29, 20)
        Me.txt0xB.TabIndex = 5
        Me.txt0xB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnReleaseEV2400
        '
        Me.btnReleaseEV2400.Location = New System.Drawing.Point(213, 18)
        Me.btnReleaseEV2400.Name = "btnReleaseEV2400"
        Me.btnReleaseEV2400.Size = New System.Drawing.Size(113, 45)
        Me.btnReleaseEV2400.TabIndex = 6
        Me.btnReleaseEV2400.Text = "Release EV2400"
        Me.btnReleaseEV2400.UseVisualStyleBackColor = True
        '
        'btnScanData
        '
        Me.btnScanData.Location = New System.Drawing.Point(56, 18)
        Me.btnScanData.Name = "btnScanData"
        Me.btnScanData.Size = New System.Drawing.Size(119, 46)
        Me.btnScanData.TabIndex = 0
        Me.btnScanData.Text = "Scan Target"
        Me.btnScanData.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnScanData)
        Me.GroupBox2.Controls.Add(Me.btnReleaseEV2400)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(1035, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(411, 71)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Data Scanning"
        '
        'dgvParamRegisters
        '
        Me.dgvParamRegisters.AllowUserToAddRows = False
        Me.dgvParamRegisters.AllowUserToDeleteRows = False
        Me.dgvParamRegisters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvParamRegisters.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Parameter, Me.Hex, Me.Value, Me.Units})
        Me.dgvParamRegisters.Location = New System.Drawing.Point(3, 145)
        Me.dgvParamRegisters.Name = "dgvParamRegisters"
        Me.dgvParamRegisters.ReadOnly = True
        Me.dgvParamRegisters.RowHeadersVisible = False
        Me.dgvParamRegisters.Size = New System.Drawing.Size(399, 632)
        Me.dgvParamRegisters.TabIndex = 0
        '
        'Units
        '
        Me.Units.HeaderText = "Units"
        Me.Units.Name = "Units"
        Me.Units.ReadOnly = True
        '
        'Value
        '
        Me.Value.HeaderText = "Value"
        Me.Value.Name = "Value"
        Me.Value.ReadOnly = True
        '
        'Hex
        '
        Me.Hex.HeaderText = "Hex"
        Me.Hex.Name = "Hex"
        Me.Hex.ReadOnly = True
        '
        'Parameter
        '
        Me.Parameter.HeaderText = "Parameter"
        Me.Parameter.Name = "Parameter"
        Me.Parameter.ReadOnly = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.txtADCOffset)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.txtADCGain)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(399, 136)
        Me.Panel1.TabIndex = 1
        '
        'txtADCGain
        '
        Me.txtADCGain.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtADCGain.Location = New System.Drawing.Point(163, 51)
        Me.txtADCGain.Name = "txtADCGain"
        Me.txtADCGain.ReadOnly = True
        Me.txtADCGain.Size = New System.Drawing.Size(29, 20)
        Me.txtADCGain.TabIndex = 5
        Me.txtADCGain.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(90, 26)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(209, 13)
        Me.Label13.TabIndex = 0
        Me.Label13.Text = "ADC Correctoins read from registers"
        '
        'txtADCOffset
        '
        Me.txtADCOffset.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtADCOffset.Location = New System.Drawing.Point(163, 84)
        Me.txtADCOffset.Name = "txtADCOffset"
        Me.txtADCOffset.ReadOnly = True
        Me.txtADCOffset.Size = New System.Drawing.Size(29, 20)
        Me.txtADCOffset.TabIndex = 5
        Me.txtADCOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(100, 57)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(62, 13)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "ADC Gain"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(92, 90)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(70, 13)
        Me.Label16.TabIndex = 6
        Me.Label16.Text = "ADC Offset"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(198, 90)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(24, 13)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "mV"
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 1
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.dgvParamRegisters, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 16)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.88932!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.11068!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(405, 797)
        Me.TableLayoutPanel2.TabIndex = 1
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 3
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 16.95906!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 83.04094!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 181.0!))
        Me.TableLayoutPanel4.Controls.Add(Me.PictureBox1, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.txtResponse, 2, 0)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 1
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(1026, 71)
        Me.TableLayoutPanel4.TabIndex = 6
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(137, 65)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'txtResponse
        '
        Me.txtResponse.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.txtResponse.Location = New System.Drawing.Point(847, 25)
        Me.txtResponse.Name = "txtResponse"
        Me.txtResponse.ReadOnly = True
        Me.txtResponse.Size = New System.Drawing.Size(176, 20)
        Me.txtResponse.TabIndex = 5
        Me.txtResponse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(198, 57)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 13)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "uV/LSB"
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.GroupBox4.Controls.Add(Me.btnWriteByte)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.txtWriteVal)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.txtRegister)
        Me.GroupBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(219, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(432, 103)
        Me.GroupBox4.TabIndex = 15
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Write One Byte to a Register"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(168, 26)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(107, 13)
        Me.Label18.TabIndex = 6
        Me.Label18.Text = "Write To Register"
        '
        'txtWriteVal
        '
        Me.txtWriteVal.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtWriteVal.Location = New System.Drawing.Point(201, 51)
        Me.txtWriteVal.Name = "txtWriteVal"
        Me.txtWriteVal.Size = New System.Drawing.Size(40, 20)
        Me.txtWriteVal.TabIndex = 5
        Me.txtWriteVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(32, 26)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(86, 13)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "Address (Hex)"
        '
        'txtRegister
        '
        Me.txtRegister.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.txtRegister.Location = New System.Drawing.Point(55, 51)
        Me.txtRegister.Name = "txtRegister"
        Me.txtRegister.Size = New System.Drawing.Size(40, 20)
        Me.txtRegister.TabIndex = 5
        Me.txtRegister.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button1
        '
        Me.btnWriteByte.Location = New System.Drawing.Point(321, 28)
        Me.btnWriteByte.Name = "Button1"
        Me.btnWriteByte.Size = New System.Drawing.Size(67, 45)
        Me.btnWriteByte.TabIndex = 7
        Me.btnWriteByte.Text = "Write"
        Me.btnWriteByte.UseVisualStyleBackColor = True
        '
        'frmBq769x0Comm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1449, 923)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmBq769x0Comm"
        Me.Text = "frmBq769x0Comm"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.tlpByte0.ResumeLayout(False)
        Me.tlpByte0.PerformLayout()
        Me.tlpByte2.ResumeLayout(False)
        Me.tlpByte2.PerformLayout()
        Me.tlpByte3.ResumeLayout(False)
        Me.tlpByte3.PerformLayout()
        Me.tlpByte1.ResumeLayout(False)
        Me.tlpByte1.PerformLayout()
        Me.tlpByte5x.ResumeLayout(False)
        Me.tlpByte5x.PerformLayout()
        Me.tlpByte4.ResumeLayout(False)
        Me.tlpByte4.PerformLayout()
        Me.tlpByte7.ResumeLayout(False)
        Me.tlpByte7.PerformLayout()
        Me.tlpByte6.ResumeLayout(False)
        Me.tlpByte6.PerformLayout()
        Me.tlpByte8.ResumeLayout(False)
        Me.tlpByte8.PerformLayout()
        Me.tlpByte9.ResumeLayout(False)
        Me.tlpByte9.PerformLayout()
        Me.tlpByteA.ResumeLayout(False)
        Me.tlpByteA.PerformLayout()
        Me.tlpByteB.ResumeLayout(False)
        Me.tlpByteB.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.dgvParamRegisters, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EV2400AdapterDataSheetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Bq769x00DataSheetToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents tlpByte1 As TableLayoutPanel
    Friend WithEvents Byte10 As Label
    Friend WithEvents Byte11 As Label
    Friend WithEvents Byte12 As Label
    Friend WithEvents Byte13 As Label
    Friend WithEvents Byte14 As Label
    Friend WithEvents tlpByte5x As TableLayoutPanel
    Friend WithEvents Byte50 As Label
    Friend WithEvents Byte51 As Label
    Friend WithEvents Byte52 As Label
    Friend WithEvents Byte53 As Label
    Friend WithEvents Byte54 As Label
    Friend WithEvents Byte55 As Label
    Friend WithEvents Byte57 As Label
    Friend WithEvents Byte56 As Label
    Friend WithEvents tlpByte4 As TableLayoutPanel
    Friend WithEvents Byte40 As Label
    Friend WithEvents Byte41 As Label
    Friend WithEvents Byte42 As Label
    Friend WithEvents Byte43 As Label
    Friend WithEvents Byte44 As Label
    Friend WithEvents Byte45 As Label
    Friend WithEvents Byte47 As Label
    Friend WithEvents Byte46 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txt0x0 As TextBox
    Friend WithEvents tlpByte0 As TableLayoutPanel
    Friend WithEvents Byte00 As Label
    Friend WithEvents Byte01 As Label
    Friend WithEvents Byte02 As Label
    Friend WithEvents Byte03 As Label
    Friend WithEvents Byte04 As Label
    Friend WithEvents Byte05 As Label
    Friend WithEvents Byte07 As Label
    Friend WithEvents Byte06 As Label
    Friend WithEvents tlpByte2 As TableLayoutPanel
    Friend WithEvents Byte20 As Label
    Friend WithEvents Byte21 As Label
    Friend WithEvents Byte22 As Label
    Friend WithEvents Byte23 As Label
    Friend WithEvents Byte24 As Label
    Friend WithEvents tlpByte3 As TableLayoutPanel
    Friend WithEvents Byte30 As Label
    Friend WithEvents Byte31 As Label
    Friend WithEvents Byte32 As Label
    Friend WithEvents Byte33 As Label
    Friend WithEvents Byte34 As Label
    Friend WithEvents tlpByte6 As TableLayoutPanel
    Friend WithEvents Byte60 As Label
    Friend WithEvents Byte61 As Label
    Friend WithEvents Byte62 As Label
    Friend WithEvents Byte63 As Label
    Friend WithEvents Byte64 As Label
    Friend WithEvents Byte65 As Label
    Friend WithEvents Byte67 As Label
    Friend WithEvents Byte66 As Label
    Friend WithEvents tlpByte7 As TableLayoutPanel
    Friend WithEvents Byte70 As Label
    Friend WithEvents Byte71 As Label
    Friend WithEvents Byte72 As Label
    Friend WithEvents Byte73 As Label
    Friend WithEvents Byte74 As Label
    Friend WithEvents Byte75 As Label
    Friend WithEvents Byte77 As Label
    Friend WithEvents Byte76 As Label
    Friend WithEvents tlpByte8 As TableLayoutPanel
    Friend WithEvents Byte80 As Label
    Friend WithEvents Byte81 As Label
    Friend WithEvents Byte82 As Label
    Friend WithEvents Byte83 As Label
    Friend WithEvents Byte84 As Label
    Friend WithEvents Byte85 As Label
    Friend WithEvents Byte87 As Label
    Friend WithEvents Byte86 As Label
    Friend WithEvents tlpByte9 As TableLayoutPanel
    Friend WithEvents Byte90 As Label
    Friend WithEvents Byte91 As Label
    Friend WithEvents Byte92 As Label
    Friend WithEvents Byte93 As Label
    Friend WithEvents Byte94 As Label
    Friend WithEvents Byte95 As Label
    Friend WithEvents Byte97 As Label
    Friend WithEvents Byte96 As Label
    Friend WithEvents tlpByteA As TableLayoutPanel
    Friend WithEvents ByteA0 As Label
    Friend WithEvents ByteA1 As Label
    Friend WithEvents ByteA2 As Label
    Friend WithEvents ByteA3 As Label
    Friend WithEvents ByteA4 As Label
    Friend WithEvents ByteA5 As Label
    Friend WithEvents ByteA7 As Label
    Friend WithEvents ByteA6 As Label
    Friend WithEvents tlpByteB As TableLayoutPanel
    Friend WithEvents ByteB0 As Label
    Friend WithEvents ByteB1 As Label
    Friend WithEvents ByteB2 As Label
    Friend WithEvents ByteB3 As Label
    Friend WithEvents ByteB4 As Label
    Friend WithEvents ByteB5 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents txt0x4 As TextBox
    Friend WithEvents txt0x5 As TextBox
    Friend WithEvents txt0x1 As TextBox
    Friend WithEvents txt0x2 As TextBox
    Friend WithEvents txt0x3 As TextBox
    Friend WithEvents txt0x6 As TextBox
    Friend WithEvents txt0x7 As TextBox
    Friend WithEvents txt0x8 As TextBox
    Friend WithEvents txt0x9 As TextBox
    Friend WithEvents txt0xA As TextBox
    Friend WithEvents txt0xB As TextBox
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents dgvParamRegisters As DataGridView
    Friend WithEvents Parameter As DataGridViewTextBoxColumn
    Friend WithEvents Hex As DataGridViewTextBoxColumn
    Friend WithEvents Value As DataGridViewTextBoxColumn
    Friend WithEvents Units As DataGridViewTextBoxColumn
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label17 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents txtADCOffset As TextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtADCGain As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnScanData As Button
    Friend WithEvents btnReleaseEV2400 As Button
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents txtResponse As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents btnWriteByte As Button
    Friend WithEvents Label18 As Label
    Friend WithEvents txtWriteVal As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtRegister As TextBox
End Class
