﻿Public Class frmBq769x0Comm

    Private Sub EV2400AdapterDataSheetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EV2400AdapterDataSheetToolStripMenuItem.Click
        Dim Proc As New Process
        Process.Start("http://www.ti.com/tool/ev2400")
    End Sub

    Private Sub Bq769x00DataSheetToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Bq769x00DataSheetToolStripMenuItem.Click
        Dim Proc As New Process
        Process.Start("http://www.ti.com/product/bq76940")
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub
    Private HiColor As Color = Color.LightGreen
    Private LoColor As Color = Color.Pink
    Private RsvdColor As Color = Color.PaleGoldenrod

    Private Sub Label1_Click(sender As Object, e As EventArgs)
        Dim LBL As Label = sender
        LBL.BackColor = IIf(LBL.BackColor = HiColor, LoColor, HiColor)
    End Sub
    Public Sub ByteWasWritten(Register As Short, RegValue As Short, Response As clsEv2300Comm.EV2300_ErrorCode)
        txtResponse.Text = Response & " - " & Response.ToString
        txtRegister.Text = Conversion.Hex(Register).PadLeft(2, "0")
        txtWriteVal.Text = Conversion.Hex(RegValue).PadLeft(2, "0")
    End Sub
    Public Sub IncomingData(NewData As bq769x0_Comm.strDeviceData, Response As clsEv2300Comm.EV2300_ErrorCode)
        ' Display the new data on the grid
        txtResponse.Text = Response & " - " & Response.ToString

        If NewData.DataArr Is Nothing Then ReDim NewData.DataArr(95)    ' Head off a lot of errors
        If UBound(NewData.DataArr) < 95 Then ReDim Preserve NewData.DataArr(95)

        Me.txt0x0.Text = Conversion.Hex(NewData.SYS_STAT_0x00).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x1.Text = Conversion.Hex(NewData.CELLBAL1_0x01).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x2.Text = Conversion.Hex(NewData.CELLBAL2_0x02).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x3.Text = Conversion.Hex(NewData.CELLBAL3_0x03).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x4.Text = Conversion.Hex(NewData.SYS_CTRL1_0x04).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x5.Text = Conversion.Hex(NewData.SYS_CTRL2_0x05).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x6.Text = Conversion.Hex(NewData.PROTECT1_0x06).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x7.Text = Conversion.Hex(NewData.PROTECT2_0x07).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x8.Text = Conversion.Hex(NewData.PROTECT3_0x08).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0x9.Text = Conversion.Hex(NewData.OV_TRIP_0x09).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0xA.Text = Conversion.Hex(NewData.UV_TRIP_0x0A).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event
        Me.txt0xB.Text = Conversion.Hex(NewData.CC_CFG_0x0B).PadLeft(2, "0") ' Flags are parse out in the CHANGE textbox event

        Me.txtADCGain.Text = NewData.ADCGainuV.ToString
        Me.txtADCOffset.Text = NewData.ADCOffsetmV.ToString

        ' display the parameter registers (cell voltages, current, etc.)
        dgvParamRegisters.Rows.Clear()
        'My.Application.DoEvents()
        Dim ValsToAdd(3) As String
        For i As Integer = 1 To 15
            ValsToAdd(0) = "Voltage Cell " & i.ToString
            ValsToAdd(1) = "0x" & Conversion.Hex(NewData.VCell_Raw(i)).PadLeft(4, "0")
            ValsToAdd(2) = NewData.Vcell_Volts(i).ToString
            ValsToAdd(3) = "Volts"
            dgvParamRegisters.Rows.Add(ValsToAdd)
        Next
        ValsToAdd(0) = "Battery Voltage"
        ValsToAdd(1) = "0x" & Conversion.Hex(NewData.BatteryVoltage_Raw).PadLeft(4, "0")
        ValsToAdd(2) = NewData.BatteryVoltage_Volts.ToString
        ValsToAdd(3) = "Volts"
        dgvParamRegisters.Rows.Add(ValsToAdd)

        ' Now do the temperature sensors
        For i As Integer = 1 To 3
            Dim TsOhms As Double
            Dim TsVolts As Double
            ValsToAdd(0) = "Temp Sensor " & i.ToString
            ValsToAdd(1) = "0x" & Conversion.Hex(NewData.Temperature_Raw(i)).PadLeft(4, "0")
            NewData.Temperature(i, TsVolts, TsOhms)
            ValsToAdd(2) = TsVolts.ToString
            ValsToAdd(3) = "Vtsx"
            dgvParamRegisters.Rows.Add(ValsToAdd)
        Next

        ValsToAdd(0) = "Coulomb Counter"
        ValsToAdd(1) = "0x" & Conversion.Hex(NewData.CoulCounter_Raw).PadLeft(4, "0")
        ValsToAdd(2) = (NewData.CoulCounter_uV / 1000000.0).ToString
        ValsToAdd(3) = "Volts"
        dgvParamRegisters.Rows.Add(ValsToAdd)
    End Sub
    Private Sub SetLabelColor(ByRef LabelToSet As Label, TheTextbox As TextBox, Bit0_7 As Integer)
        ' Set backcolor of LabelToSet according to the indicated bit
        ' However!!! If the label text is RSVD, just set the Reserved color (just like the TI bq76940 software
        Dim IsSet As Boolean = (Val("&H" & TheTextbox.Text) And 2 ^ Bit0_7) <> 0

        If LabelToSet.Text = "RSVD" Then
            LabelToSet.BackColor = Color.Bisque
        Else
            LabelToSet.BackColor = IIf(IsSet, Color.LightGreen, Color.LightPink)
        End If
    End Sub
    Private Sub txt0x0_TextChanged(sender As Object, e As EventArgs) Handles txt0x0.TextChanged
        ' Set label colors
        SetLabelColor(Me.Byte00, txt0x0, 0)
        SetLabelColor(Me.Byte01, txt0x0, 1)
        SetLabelColor(Me.Byte02, txt0x0, 2)
        SetLabelColor(Me.Byte03, txt0x0, 3)
        SetLabelColor(Me.Byte04, txt0x0, 4)
        SetLabelColor(Me.Byte05, txt0x0, 5)
        SetLabelColor(Me.Byte06, txt0x0, 6)
        SetLabelColor(Me.Byte07, txt0x0, 7)
    End Sub

    Private Sub txt0x4_TextChanged(sender As Object, e As EventArgs) Handles txt0x4.TextChanged
        SetLabelColor(Me.Byte40, txt0x4, 0)
        SetLabelColor(Me.Byte41, txt0x4, 1)
        SetLabelColor(Me.Byte42, txt0x4, 2)
        SetLabelColor(Me.byte43, txt0x4, 3)
        SetLabelColor(Me.byte44, txt0x4, 4)
        SetLabelColor(Me.byte45, txt0x4, 5)
        SetLabelColor(Me.byte46, txt0x4, 6)
        SetLabelColor(Me.byte47, txt0x4, 7)
    End Sub

    Private Sub txt0x5_TextChanged(sender As Object, e As EventArgs) Handles txt0x5.TextChanged
        SetLabelColor(Me.Byte50, txt0x5, 0)
        SetLabelColor(Me.Byte51, txt0x5, 1)
        SetLabelColor(Me.Byte52, txt0x5, 2)
        SetLabelColor(Me.Byte53, txt0x5, 3)
        SetLabelColor(Me.Byte54, txt0x5, 4)
        SetLabelColor(Me.Byte55, txt0x5, 5)
        SetLabelColor(Me.Byte56, txt0x5, 6)
        SetLabelColor(Me.Byte57, txt0x5, 7)
    End Sub

    Private Sub txt0x1_TextChanged(sender As Object, e As EventArgs) Handles txt0x1.TextChanged
        SetLabelColor(Me.Byte10, txt0x1, 0)
        SetLabelColor(Me.Byte11, txt0x1, 1)
        SetLabelColor(Me.Byte12, txt0x1, 2)
        SetLabelColor(Me.Byte13, txt0x1, 3)
        SetLabelColor(Me.Byte14, txt0x1, 4)
    End Sub
    Private Sub txt0x2_TextChanged(sender As Object, e As EventArgs) Handles txt0x2.TextChanged
        SetLabelColor(Me.Byte20, txt0x2, 0)
        SetLabelColor(Me.Byte21, txt0x2, 1)
        SetLabelColor(Me.Byte22, txt0x2, 2)
        SetLabelColor(Me.Byte23, txt0x2, 3)
        SetLabelColor(Me.Byte24, txt0x2, 4)
    End Sub
    Private Sub txt0x3_TextChanged(sender As Object, e As EventArgs) Handles txt0x3.TextChanged
        SetLabelColor(Me.Byte30, txt0x3, 0)
        SetLabelColor(Me.Byte31, txt0x3, 1)
        SetLabelColor(Me.Byte32, txt0x3, 2)
        SetLabelColor(Me.Byte33, txt0x3, 3)
        SetLabelColor(Me.Byte34, txt0x3, 4)
    End Sub
    Private Sub txt0x6_TextChanged(sender As Object, e As EventArgs) Handles txt0x6.TextChanged
        SetLabelColor(Me.Byte60, txt0x6, 0)
        SetLabelColor(Me.Byte61, txt0x6, 1)
        SetLabelColor(Me.Byte62, txt0x6, 2)
        SetLabelColor(Me.Byte63, txt0x6, 3)
        SetLabelColor(Me.Byte64, txt0x6, 4)
        SetLabelColor(Me.Byte65, txt0x6, 5)
        SetLabelColor(Me.Byte66, txt0x6, 6)
        SetLabelColor(Me.Byte67, txt0x6, 7)
    End Sub
    Private Sub txt0x7_TextChanged(sender As Object, e As EventArgs) Handles txt0x7.TextChanged
        SetLabelColor(Me.Byte70, txt0x7, 0)
        SetLabelColor(Me.Byte71, txt0x7, 1)
        SetLabelColor(Me.Byte72, txt0x7, 2)
        SetLabelColor(Me.Byte73, txt0x7, 3)
        SetLabelColor(Me.Byte74, txt0x7, 4)
        SetLabelColor(Me.Byte75, txt0x7, 5)
        SetLabelColor(Me.Byte76, txt0x7, 6)
        SetLabelColor(Me.Byte77, txt0x7, 7)
    End Sub
    Private Sub txt0x8_TextChanged(sender As Object, e As EventArgs) Handles txt0x8.TextChanged
        SetLabelColor(Me.Byte80, txt0x8, 0)
        SetLabelColor(Me.Byte81, txt0x8, 1)
        SetLabelColor(Me.Byte82, txt0x8, 2)
        SetLabelColor(Me.Byte83, txt0x8, 3)
        SetLabelColor(Me.Byte84, txt0x8, 4)
        SetLabelColor(Me.Byte85, txt0x8, 5)
        SetLabelColor(Me.Byte86, txt0x8, 6)
        SetLabelColor(Me.Byte87, txt0x8, 7)
    End Sub
    Private Sub txt0x9_TextChanged(sender As Object, e As EventArgs) Handles txt0x9.TextChanged
        SetLabelColor(Me.Byte90, txt0x9, 0)
        SetLabelColor(Me.Byte91, txt0x9, 1)
        SetLabelColor(Me.Byte92, txt0x9, 2)
        SetLabelColor(Me.Byte93, txt0x9, 3)
        SetLabelColor(Me.Byte94, txt0x9, 4)
        SetLabelColor(Me.Byte95, txt0x9, 5)
        SetLabelColor(Me.Byte96, txt0x9, 6)
        SetLabelColor(Me.Byte97, txt0x9, 7)
    End Sub
    Private Sub txt0xA_TextChanged(sender As Object, e As EventArgs) Handles txt0xA.TextChanged
        SetLabelColor(Me.ByteA0, txt0xA, 0)
        SetLabelColor(Me.ByteA1, txt0xA, 1)
        SetLabelColor(Me.ByteA2, txt0xA, 2)
        SetLabelColor(Me.ByteA3, txt0xA, 3)
        SetLabelColor(Me.ByteA4, txt0xA, 4)
        SetLabelColor(Me.ByteA5, txt0xA, 5)
        SetLabelColor(Me.ByteA6, txt0xA, 6)
        SetLabelColor(Me.ByteA7, txt0xA, 7)
    End Sub
    Private Sub txt0xB_TextChanged(sender As Object, e As EventArgs) Handles txt0xB.TextChanged
        SetLabelColor(Me.Byte00, txt0xB, 0)
        SetLabelColor(Me.ByteB1, txt0xB, 1)
        SetLabelColor(Me.ByteB2, txt0xB, 2)
        SetLabelColor(Me.ByteB3, txt0xB, 3)
        SetLabelColor(Me.ByteB4, txt0xB, 4)
        SetLabelColor(Me.ByteB5, txt0xB, 5)
    End Sub

    Private Sub btnScanData_Click(sender As Object, e As EventArgs) Handles btnScanData.Click
        Dim Hold As Boolean = sender.enabled
        sender.enabled = False
        Me.Text = TestSetControl.bq76940.ReadDevice().ToString
        sender.enabled = Hold
    End Sub

    Private Sub btnReleaseEV2400_Click(sender As Object, e As EventArgs) Handles btnReleaseEV2400.Click
        Dim Hold As Boolean = sender.enabled
        sender.enabled = False
        TestSetControl.EV2300.CloseDevice()
        sender.enabled = Hold
    End Sub

    Private Sub WriteAByteHander(sender As Object, e As EventArgs) Handles btnWriteByte.Click
        ' write byte to register
        ' Call-back indications will be handled in .bq76940 function
        Dim Hold As Boolean = sender.enabled
        sender.enabled = False
        TestSetControl.bq76940.WriteByteToRegister(Val("&H" & txtRegister.Text), Val("&H" & txtWriteVal.Text))
        sender.enabled = Hold
    End Sub
End Class