﻿

Partial Public Class DaqControlDataSet
    Partial Class dtDaqConfigurationDataTable

 
    End Class

End Class
