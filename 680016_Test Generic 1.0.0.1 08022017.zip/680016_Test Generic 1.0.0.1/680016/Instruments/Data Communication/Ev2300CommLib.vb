﻿Imports Microsoft.VisualBasic

'*****************************************************************************
' Author : Philip Liberatore
'
' Copyright: 2017, iTECH
' Plibertore@itecheng.com
'
'
' Description:
' These files contains communication related functions. It calls functions in
' the bq80xRW.ocx
'
'*****************************************************************************


Public Class clsEv2300Comm
    'Constants
    Public Const DEFAULT_TARGET_ADDR As Integer = &H17
    Public WithEvents Bq80xRW1 As AxBQ80XRWLib.AxBq80xRW
    Public Property MyDeviceID As String
    Public Event Ev2300Event(EventType As String, EventResult As String)
    Public Function OpenDevice() As Boolean
        ' Opens the previously discovered EV2300
        Try
            'Don't validate board name, just through an error
            If Not Bq80xRW1.OpenDevice(MyDeviceID) Then
                Throw New System.Exception("Cannot Open Device with MyDeviceID=" & MyDeviceID)
            End If
            OpenDevice = True
        Catch ex As Exception
            OpenDevice = False
        Finally
            RaiseEvent Ev2300Event("Open Device ID=" & MyDeviceID, OpenDevice.ToString)
        End Try
    End Function
    Public Function OpenFirstFreeDevice(Optional ByRef Boardname As String = "") As Boolean
        ' Function: OpenFirstFreeDevice()
        ' Opens the First FREE(Unopened) device that the system can find
        Dim nBrdsFound As Integer
        MyDeviceID = ""
        OpenFirstFreeDevice = False
        Call Bq80xRW1.GetFreeBoards(1, nBrdsFound, Boardname)
        Dim EndPos As Object
        If nBrdsFound >= 1 Then 'At least 1 board found
            EndPos = InStr(1, Boardname, ",", CompareMethod.Text) 'Should always have a "," at the end
            If Not IsDBNull(EndPos) And EndPos <> 0 Then
                Boardname = Left(Boardname, EndPos - 1)
            End If
            CloseDevice()
            If Bq80xRW1.OpenDevice(Boardname) = 0 Then 'return of 0 = success
                MyDeviceID = Boardname
                OpenFirstFreeDevice = True 'Success
            End If
        End If
        RaiseEvent Ev2300Event("OpenFirstFreeDevice ID=" & MyDeviceID, OpenFirstFreeDevice.ToString)

    End Function

    Public Function CloseDevice() As Boolean
        ' Function: CloseDevice()
        ' Closes the Device that is currently open 
        Try
            Bq80xRW1.CloseDevice()
            CloseDevice = True
        Catch ex As Exception
            ' Nothing to do here
            CloseDevice = False
        Finally
            RaiseEvent Ev2300Event("CloseDevice", CloseDevice.ToString)
        End Try
    End Function

    Public Function WriteSMBusWord_(ByVal ySubCommand As Byte, ByRef nWord As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode

        WriteSMBusWord_ = Bq80xRW1.WriteSMBusWord(ySubCommand, nWord, nTargetAddr) 'Non-Zero if error
        If WriteSMBusWord_ = EV2300_ErrorCode.VB_NO_ERROR Then
            WriteSMBusWord_ = CheckForError()
        End If
        Dim EventReport As String = "WriteSmbWord_(" & ySubCommand.ToString & ", " & nWord.ToString & ", " & nTargetAddr.ToString & ")"
        RaiseEvent Ev2300Event(EventReport, WriteSMBusWord_.ToString)
    End Function


    Public Function WriteSMBusWord(ByVal ySubCommand As Byte, ByRef yMSData As Byte, ByRef yLSData As Byte, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        ' Function: WriteSMBusWord()
        ' Writes a Word of data on SMBus as 2 bytes
        Dim nWord As Short
        nWord = 0
        If yMSData > 127 Then
            nWord = &H8000S
            yMSData = yMSData - 128
        End If
        nWord = nWord + yMSData * 256 + yLSData

        WriteSMBusWord = WriteSMBusWord_(ySubCommand, nWord, nTargetAddr) 'Non-Zero if error
        'Event raised in 'WriteSMBusWord_(...) function
    End Function

    Public Function WriteSMBusBlock(ByVal nCommand As Short, ByRef DataArray() As Byte, ByRef iNumBytes As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        ' Function: WriteSMBusBlock()
        ' Writes a block of data on SMBus
        WriteSMBusBlock = Bq80xRW1.WriteSMBusBlock(nCommand, DataArray, iNumBytes, nTargetAddr) ' Returns non 0 if error
        If WriteSMBusBlock = 0 Then
            WriteSMBusBlock = CheckForError()
        End If
        Dim EventReport As String = "WriteSMBusBlock(" & nCommand.ToString & ", ... )"
        RaiseEvent Ev2300Event(EventReport, WriteSMBusBlock.ToString)
    End Function

    '-----------------------------------------------------------------------------
    ' Function: WriteSMBusCommand()
    ' Writes a SMBus Command

    Public Function WriteSMBusCommand(ByVal nCommand As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode

        WriteSMBusCommand = Bq80xRW1.WriteSMBusCmd(nCommand, nTargetAddr)
        If WriteSMBusCommand = 0 Then
            WriteSMBusCommand = CheckForError()
        End If

        Dim EventReport As String = "WriteSMBusCommand(" & nCommand.ToString & ", " & nTargetAddr.ToString & ")"
        RaiseEvent Ev2300Event(EventReport, WriteSMBusCommand.ToString)
    End Function

    '-----------------------------------------------------------------------------


    Public Function ReadSMBusWord_(ByVal ySmbCommand As Byte, ByRef nData As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode

        ReadSMBusWord_ = Bq80xRW1.ReadSMBusWord(ySmbCommand, nData, nTargetAddr)
        Dim EventReport As String = "ReadSmbWord_(" & ySmbCommand.ToString & ", " & nData.ToString & ", " & nTargetAddr.ToString & ")"
        RaiseEvent Ev2300Event(EventReport, ReadSMBusWord_.ToString)

    End Function

    '-----------------------------------------------------------------------------
    ' Function ReadSMBusWord()
    ' Reads a word of data over SMBus as 2 bytes

    Public Function ReadSMBusWord(ByVal ySubCommand As Byte, ByRef yMSData As Byte, ByRef yLSData As Byte, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        ' Function ReadSMBusWord_()
        ' Reads a word of data over SMBus
        Dim SMBCmd As Short
        Dim nWord As Short

        SMBCmd = ySubCommand
        ReadSMBusWord = ReadSMBusWord_(SMBCmd, nWord, nTargetAddr)
        Dim NegSign As Boolean
        If ReadSMBusWord = 0 Then ' Put returned Word into MS and LS byte
            NegSign = False
            ReadSMBusWord = 0
            If nWord < 0 Then
                nWord = nWord + 32768
                NegSign = True
            End If
            yMSData = nWord \ 256
            yLSData = nWord - yMSData * 256
            If NegSign Then
                yMSData = yMSData + &H80
            End If
        End If
        ReadSMBusWord = ReadSMBusWord
        'Event is raised in ReadSMBusWord_(...) function
    End Function

    '-----------------------------------------------------------------------------
    ' Function ReadSMBusBlock_()
    ' Reads a block of data over SMBus

    Public Function ReadSMBusBlock_(ByVal ySubCommand As Byte, ByRef yResponse() As Byte, Optional ByRef nLen_ As Short = 0, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode

        Dim nLen As Short
        Dim nIdx As Short
        Dim V As Object
        'V = VB6.CopyArray(yResponse)
        Array.Copy(yResponse, V, yResponse.Length)
        ReadSMBusBlock_ = Bq80xRW1.ReadSMBusBlock(ySubCommand, V, nLen, nTargetAddr)

        For nIdx = 0 To nLen 'Copy from variant to array
            yResponse(nIdx) = V(nIdx)
        Next nIdx
        nLen_ = nLen

        Dim EventReport As String = "ReadSMBusBlock_(" & ReadSMBusBlock_.ToString & ", ... )"
        RaiseEvent Ev2300Event(EventReport, ReadSMBusBlock_.ToString)
    End Function


    '-----------------------------------------------------------------------------
    ' Function ReadSMBusBlock()
    ' Reads a block of data over SMBus and formats it as specified
    ' nReturnStrType 0=Hex data string, 1=Normal string

    Public Function ReadSMBusBlock(ByVal ySubCommand As Byte, ByRef sResponse As String, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR, Optional ByRef nReturnStrType As Short = 0) As EV2300_ErrorCode

        Dim Data(128) As Byte
        Dim nLen As Short
        Dim Subcmd As Short
        Subcmd = ySubCommand
        'To call ReadSMBusBlock() we need a pointer to variant containing array of bytes
        'So assign an array of bytes to variant v and use v as argument to the call
        Dim V As Object
        'V = VB6.CopyArray(Data)
        Array.Copy(Data, V, Data.Length)
        sResponse = ""
        ReadSMBusBlock = Bq80xRW1.ReadSMBusBlock(Subcmd, V, nLen, nTargetAddr)
        Dim X As Short
        Dim tmpStr As String
        If ReadSMBusBlock = 0 Then 'Stick return data into a string
            For X = 0 To nLen - 1
                tmpStr = Hex(V(X))
                If Len(tmpStr) < 2 Then
                    tmpStr = "0" & tmpStr
                End If
                If nReturnStrType = 1 Then sResponse = sResponse & Chr(V(X)) 'This will display actual string for mfg name
                If nReturnStrType = 0 Then sResponse = sResponse & tmpStr 'Hex string
            Next X
        End If

        ' Raise Event
    End Function

    '-----------------------------------------------------------------------------
    Public Function I2CPower(ByVal nData As Byte) As EV2300_ErrorCode
        Dim nDummy As Short
        I2CPower = Bq80xRW1.I2CReadWrite(BQ80XRWLib.I2COperation.vb_I2C_EE_POWER, nData, 0, nDummy)
        
        RaiseEvent Ev2300Event("I2CPower(" & nData.ToString & ") ", I2CPower.ToString)
    End Function

    Public Function I2CReadWrite(ByVal nOperation As BQ80XRWLib.I2COperation, ByVal nTargetAddr As Short, ByRef nWordAddr As Short, ByRef nData As Short) As EV2300_ErrorCode

        I2CReadWrite = Bq80xRW1.I2CReadWrite(nOperation, nTargetAddr, nWordAddr,nData)

        Dim EventReport As String = "I2CReadWrite(" & nOperation.ToString & ", " & nTargetAddr.ToString & ", " & nWordAddr.ToString & ", " & nData.ToString & ")"
        RaiseEvent Ev2300Event(EventReport, I2CReadWrite.ToString)
    End Function

    Public Function I2CReadWord(ByRef nWordAddr As Short, ByRef nWord As Short, ByVal nTargetAddr As Short) As EV2300_ErrorCode
        Dim lError As Integer
        Dim DataBlock As Object
        Dim nBlockSize As Short
        nBlockSize = 2

        lError = Bq80xRW1.I2CReadBlock(nWordAddr, DataBlock, nBlockSize, nTargetAddr)
        If (lError = 0) Then
            If nBlockSize <> 2 Then I2CReadWord = 772 : Exit Function
            'Copy from variant to array
            nWord = CShort(DataBlock(0) And &H7F) * 256 + DataBlock(1)
            If DataBlock(0) And &H80 Then nWord = nWord Or &H8000
        End If
        If lError = 0 Then lError = CheckForError()
        I2CReadWord = lError

        Dim EventReport As String = "I2CReadWord(" & nWordAddr.ToString & ", " & nWord.ToString & ", " & nTargetAddr.ToString & ")"
        RaiseEvent Ev2300Event(EventReport, I2CReadWord.ToString)
    End Function

    Const nTime_ms As Integer = 200 '' TODO Clear this out 
    Private frmBq As frmEv2300Container
    Public Sub New()
        ' AxBq80xRW1 ActiveX control must be placed on a form, otherwise it throws an exception
        ' frmBq only provides the control. It should never accessed directly.
        'frmBq = New frmEv2300Container
        frmBq = New frmEv2300Container
        Bq80xRW1 = frmBq.AxBq80xRW1
    End Sub

    Public Function CheckForError() As EV2300_ErrorCode
        ' Function: CheckForError()
        ' Returns an error is the previous function call communication failed.
        ' Normally used after writes because write functions do not wait for the
        ' communication to complete before returning success.
        ' Functions must wait for the time required for communication to complete
        ' before calling this function. The communication time is dependent on the
        ' PC hardware and free resources
        CheckForError = Bq80xRW1.CheckForError
        
    End Function

    '-----------------------------------------------------------------------------
    Public Sub Delay(ByVal nTime_ms As Integer)
        Bq80xRW1.Delay((nTime_ms))
        'Delay = CheckForError()
    End Sub
    '-----------------------------------------------------------------------------
    Public Sub ClearAllErrors(ByRef nTime_ms As Integer)
        Do
            While (CheckForError() <> 0)
            End While
            Delay(nTime_ms)
        Loop While (CheckForError() <> 0)
    End Sub


    Public Enum EV2300_ErrorCode As Integer
        VB_NO_ERROR = 0
        VB_LOST_SYNC = 1
        VB_NO_USB = 2  ' Was VB_NO_RS232
        VB_BAD_PEC = 3
        VB_WRONG_NUM_BYTES = 5
        VB_T2H_UNKNOWN = 6
        VB_SMBC_LOCKED = 260  'Unused but reserved for backward compatibility
        VB_SMBD_LOCKED = 516  'Unused but reserved for backward compatibility
        VB_T2H_NACK = 772
        VB_SMBD_LOW = 1028  'Unused but reserved for backward compatibility
        VB_SMB_LOCKED = 1284  'Unused but reserved for backward compatibility

        ' New error codes returned to VB
        VB_INCORRECT_PARAM = 7  ' Invalid parameter type passed to function - especially Variant argument.
        ' ex. Variant containing integer instead of Variant containing array of bytes
        VB_TIMEOUT_ERROR = 8  ' USB Timeout
        VB_INVALID_DATA = 9  ' AssemblePacket could not build a valid packet
        VB_ERR_UNSOLICITED_PKT = 10  ' Found an unsolicited non-error packet when looking for error packets
        VB_COMPARE_DIFFERENT = 11  ' Comparison failed and data read is different from srec

        ' Added codes for Programming/Compare
        ' Srec errors
        VB_BQ80XRW_OCX_INTERNAL_ERROR = 12  ' Problems with pointers being NULL etc.
        VB_SREC_OPEN_FAIL = 221
        VB_SREC_BAD_START_RECORD = 222
        VB_SREC_UNKNOWN_TYPE = 223
        VB_SREC_BAD_CHECKSUM = 224
        VB_SREC_BAD_RECORD_COUNT = 225
        ' SREC targets a different device than the one detected on the SMBus '
        VB_SREC_DEV_MISMATCH = 226

        ' Config errors
        VB_CONFIG_OPEN_FAIL = 227
        VB_CONFIG_UNEXPECTED_EOF = 228
        VB_CONFIG_BAD_FORMAT = 229

        ' The VER byte in the devices instruction flash does not match the range expected by this config file  '
        VB_PCFG_DEVVER_MISMATCH = 231
        ' The DEV byte in the devices instruction flash does not match what the config file expected '
        VB_PCFG_DEV_MISMATCH = 232
        ' The VER byte in the instruction flash image to be programed into the device does not match the one in config file '
        VB_PCFG_SRECDEVVER_MISMATCH = 233
        ' The DEV byte in the instruction flash image to be programed into the device does not match the one in config file '
        VB_PCFG_SRECDEV_MISMATCH = 234
        ' The VER byte in the devices instruction flash does not match the range expected by this config file  '
        VB_BCFG_DEVVER_MISMATCH = 235
        ' The DEV byte in the devices instruction flash does not match what the config file expected '
        VB_BCFG_DEV_MISMATCH = 236

        VB_USER_CANCELLED_OPERATION = 34
        VB_DF_CHECKSUM_MISMATCH = 51
        VB_IF_CHECKSUM_MISMATCH = 52
        VB_OPERATION_UNSUPPORTED = 53

        ' New Error codes corresponding to PKTSpec Error codes
        VB_ERR_TOO_MANY_QUERIES = 81
        VB_ERR_BAD_QUERY_ID = 82
        VB_BAD_CRC = 83
        VB_ERR_TOO_MANY_RESPONSES = 84
        VB_ERR_NO_QUERIES_TO_DELETE = 85
        VB_ERR_QUERY_UNAVAILABLE = 86
        VB_ERR_NO_RESPONSES_TO_DELETE = 87
        VB_ERR_RESPONSE_UNAVAILABLE = 88
        VB_ERR_TMMT_NO_RESPONSE = 90
        VB_T2H_ERR_TIMEOUT = 92
        VB_BUS_BUSY = 94
        VB_T2H_ERR_BAD_SIZE = 95
        VB_ERR_BAD_PAYLOAD_LEN = 97
        VB_ERR_TMMT_LIST_FULL = 98
        VB_ERR_TMMT_BAD_SELECTION = 99
        VB_UNKNOWN = 100

        ' New Generic error codes
        VB_UNEXPECTED_ERROR = 110  ' Should not happen
        VB_OUT_OF_MEMORY = 111

        'EVSW error codes reserved 5000 - 6000
        VB_ERR_NOTHINGTODO = 5001
        VB_ERR_VOLTAGE_LESSTHANZERO = 5002
        VB_ERR_TEMPERATURE_LESSTHANZERO = 5003
        VB_ERR_CURRENT_EQUALSZERO = 5004

        VB_ERR_NOT_IN_CAL_MODE = 5010

        VB_ERR_CALIBRATION_IN_FIRMWARE_FLASHWRITE = 5020
        VB_ERR_CALIBRATION_IN_FIRMWARE_AFE = 5021
        VB_ERR_CALIBRATION_IN_FIRMWARE_PACKV = 5022
        VB_ERR_CALIBRATION_IN_FIRMWARE_PACKG = 5023
        VB_ERR_CALIBRATION_IN_FIRMWARE_VGAIN = 5024
        VB_ERR_CALIBRATION_IN_FIRMWARE_CCIGAIN = 5025
        VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFEXT1 = 5026
        VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFEXT2 = 5027
        VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFINT = 5028
        VB_ERR_CALIBRATION_IN_FIRMWARE_ADCOFF = 5029
        VB_ERR_CALIBRATION_IN_FIRMWARE_BRDOFF = 5030
        VB_ERR_CALIBRATION_IN_FIRMWARE_CCIOFF = 5031
        '_RSVD can be used for future subcodes, we want it to be in sequence
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD0 = 5032
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD1 = 5033
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD2 = 5034
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD3 = 5035
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD4 = 5036
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD5 = 5037
        VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD6 = 5038
        VB_ERR_CALIBRATION_IN_FIRMWARE_UNDEFINED = 5039

        VB_ERR_DF_RD_REQ_B4_WR = 5041
        VB_ERR_INVALID_DATA_ENTERED = 5042
        VB_ERR_USB_ACQUIRE = 5043

        '*************************************************************'
        '           All error codes above 6000 are for iTECH use
        '*************************************************************'
        iTECH_UnknownError = 6000
    End Enum

End Class
