﻿Option Explicit On
Option Strict Off
Imports VB = Microsoft.VisualBasic
Imports Z_Pack_Generic.Ev2300CommInterface

Partial Friend Class Ev2300CommInterface
    'SBSCommInterface
    '
    'Public class to interface to Texas Instruments bq20zXX modules
    '
    'All calls should be through this class. This will be the public class when the module is wrapped into a DLL.
    '
    'P Liberatore
    'Copyright 2009, Nexergy Corporation
    '
    'Required applications on Target computer
    '   bqEVSW Software
    '   bqMultistation Test Software
    '   bwEVSW Source Code
    '
    'Required Project Components
    '
    '   bq80xRW ActiveX Control module      Windows\TI\bq80xRW.ocx
    '   bqEVSWHelper                        Windows\TI\bqEVSWHelper.ocx
    '   Custom Tester Helper ocx            Windows\system32\CustomTesterHelper.ocx
    '   TesterHelper by Shirish Kavoor      system32\TesterHelper.ocx
    '
    '   Optional Reference
    '   Windows/TI/ggfilemanipulater.dll (I don't know what this does, but it could be really useful)
    '
    Public Enum enSMBRegister_z80 As Byte
        ManufacturerAccess = &H0
        RemainingCapacityAlarm = &H1
        RemainingTimeAlarm = &H2
        BatteryMode = &H3
        AtRate = &H4
        AtRateTimeToFull = &H5
        AtRateTimeToEmpty = &H6
        AtRateOK = &H7
        Temperature = &H8
        voltage = &H9
        Current = &HA
        AverageCurrent = &HB
        MaxError = &HC
        RelStateOfOfCharge = &HD
        AbsStateOfCharge = &HE
        RemainingCapacity = &HF
        FullChargeCapacity = &H10
        RunTimeToEmpty = &H11
        AverageTimeToEmpty = &H12
        AverageTimeToFull = &H13
        ChargingCurrent = &H14
        ChargingVoltage = &H15
        BatteryStatus = &H16
        CycleCount = &H17
        DesignCapacity = &H18
        DesignVoltage = &H19
        SpecificationInfo = &H1A
        ManufactureDate = &H1B
        SerialNumber = &H1C
        ManufactureName = &H20
        DeviceName = &H21
        DeviceChemistry = &H22
        ManufacturerData = &H23
        Authenticate = &H2F
        CellVoltage4 = &H3C
        CellVoltage3 = &H3D
        CellVoltage2 = &H3E
        CellVoltage1 = &H3F
        'Extended SMB
        FET_Status = &H46
        SafetyAlert = &H50 'flags safety issues that have not yet timed out
        SafetyStatus = &H51 'Flags safety issues that have timed out
        PfAlert = &H52
        PfStatus = &H53
        OpStatus = &H54
    End Enum
    Public Event DataCommWriteComplete(ByVal CommandReg As Short, ByVal ArgString As String, ByVal Destination As Integer, ByVal RespCode As EV2300_ErrorCode)
    Public Event DataCommReadComplete(ByVal CommandReg As Short, ByVal ArgString As String, ByVal Destination As Integer, ByVal RespCode As EV2300_ErrorCode)
    Public Event DataCommBlockWriteComplete(ByVal BlockNumber As Short, Bytes() As Byte, RespCode As EV2300_ErrorCode)
    Public Event DataCommBlockReadComplete(ByVal BlockNumber As Short, Bytes() As Byte, RespCode As EV2300_ErrorCode)
    Public Event DataCommCommandComplete(CommandReg As Short, RespCode As EV2300_ErrorCode)
    Public Structure struCalDetail
        Public bDoCCOffset As Boolean
        Public bDoVoltage As Boolean
        Public bDoTemperature As Boolean
        Public bDoPackCurrent As Boolean
        Public iVoltage_mV As Short
        'Public cal_bFETOnForVoltage As Boolean
        Public iCellCountForVoltage As Short
        Public fTemperatureC As Single
        'Public cal_bDoIntTempSensor As Boolean 'These are set by the Glo values
        'Public cal_bDoExtSensor1 As Boolean
        'Public cal_bDoExtSensor2 As Boolean
        Public iPackCurrent_mA As Short
        Public Function ErrorString() As String
            Dim Str As New System.Text.StringBuilder
            If bDoTemperature And Not Utility.InRange(fTemperatureC, 10, 33) Then
                Str.AppendLine("Temperature Out of Range: " & fTemperatureC & NL)
            End If
            If bDoPackCurrent Then
                If (Not Utility.InRange(iPackCurrent_mA, -4000, -500)) And (Not Utility.InRange(iPackCurrent_mA, 500, 3000)) Then
                    Str.AppendLine("Reference Current Out Of Range: " & iPackCurrent_mA)
                End If
            End If
            If bDoVoltage And Not InRange(iVoltage_mV, 3000, 16000) Then
                Str.AppendLine("Reference Voltage Out of Range: " & iVoltage_mV)
            End If
            ErrorString = Str.ToString
            If ErrorString = "" Then ErrorString = OK
        End Function
        Public ReadOnly Property iTempFormat() As Short
            Get
                'The value the gets written into the reference temperature field
                'Write the value into cal_TemperatureC
                Return 10 * (Me.fTemperatureC + 273.15)
            End Get
        End Property
        Public Function CalibrControlArg() As Short
            'Bit 0	Coloumb Counter Offset
            'Bit 1	Reserved (0)
            'Bit 2	ADC Offset
            'Bit 3	Temperature, Internal
            'Bit 4	Temperature, External 1
            'Bit 5	Temperature, External 2
            'Bit 6	Current
            'Bit 7	Voltage
            '
            'Bit 8	Pack Gain
            'Bit 9	Pack Voltage
            'Bit 10	AFE Error
            'Bit 11	Reserved (0)
            'Bit 11	Reserved (0)
            'Bit 11	Reserved (0)
            'Bit 14	Run ADC Task Continuously
            'Bit 15	Run CC Task Continuously
            Dim TheArg As Short = &HC00 'Always run these
            If Me.bDoCCOffset Then TheArg = TheArg Or &H1S
            If Me.bDoTemperature And glo.Calibration_DoIntTempSensor Then TheArg = TheArg Or &H8S
            If Me.bDoTemperature And glo.Calibration_DoExtTempSensor1 Then TheArg = TheArg Or &H10S
            If Me.bDoTemperature And glo.Calibration_DoExtTempSensor2 Then TheArg = TheArg Or &H20S
            If Me.bDoPackCurrent Then TheArg = TheArg Or &H40
            If Me.bDoVoltage Then TheArg = TheArg Or &H80

            Return TheArg
        End Function
    End Structure
    Public Function Unseal(ByVal NumberOfRetryAttempts As Integer) As EV2300_ErrorCode
        'Dim Expected60() As Byte = {&H14, &H4, &H72, &H36}
        'Dim USealCode1 As Short = &H414S
        'Dim USealCode2 As Short = &H3672S
        Dim USealCode1 As Short = Limits.DataReport.UnsealWord1
        Dim USealCode2 As Short = Limits.DataReport.UnsealWord2

        'Dim FA1 As Short = &HFFFFS
        'Dim FA2 As Short = &HFFFFS
        Dim FA1 As Short = Limits.DataReport.FullAccessWord1
        Dim FA2 As Short = Limits.DataReport.FullAccessWord2
        Dim IAmSealed As Boolean
        Dim TryCount As Integer = 0
        Do
            TryCount += 1
            Unseal = Write_TwoWordCommand(0, USealCode1, USealCode2)
            Unseal = Write_TwoWordCommand(0, FA1, FA2)
            Unseal = PackIsSealed(IAmSealed)
            If IAmSealed Then
                Utility.Delay(250)
                Unseal = PackIsSealed(IAmSealed)
            End If
            If IAmSealed Then
                AddStatusMessage("Ev2300Comm.Unseal  Unseal attempted failed. Wait four seconds and retry")
                Dim Sw As New Stopwatch
                Sw.Start()
                Do
                    My.Application.DoEvents()
                Loop Until Sw.ElapsedMilliseconds >= 4100 'Must wait four seconds betw unseal commands.
                '                                           'bq20z45R1 Tech Reference A1.2.14

            End If
        Loop While IAmSealed And TryCount <= NumberOfRetryAttempts
        
    End Function
    Public Function Unseal() As EV2300_ErrorCode
        Dim Expected60() As Byte = {&H14, &H4, &H72, &H36}
        Dim USealCode1 As Short = &H414S
        Dim USealCode2 As Short = &H3672S

        Dim FA1 As Short = &HFFFFS
        Dim FA2 As Short = &HFFFFS
        Try
            Call InstruControl.Ev2300.Write_TwoWordCommand(0, USealCode1, USealCode2)
            Return InstruControl.Ev2300.Write_TwoWordCommand(0, FA1, FA2)
        Catch ex As Exception

        End Try
    End Function
    Public Function PfClear() As EV2300_ErrorCode
        'Dim Expected60() As Byte = {&H14, &H4, &H72, &H36}
        'Dim USealCode1 As Short = &H414S
        'Dim USealCode2 As Short = &H3672S
        Dim PfWord1 As Short = Limits.DataReport.PfClearKeyWord1
        Dim PfWord2 As Short = Limits.DataReport.PfClearKeyWord2

        Try
            Return InstruControl.Ev2300.Write_TwoWordCommand(0, PfWord1, PfWord2)
        Catch ex As Exception
            Return EV2300_ErrorCode.VB_UNKNOWN
        End Try
    End Function
    Public Function DumpGGfile(ByRef ToFile As String) As EV2300_ErrorCode
        'Dim FS As New FileSystem
        'FS.nDevice = 23
        ' DumpGGfile = modROMDF.ReadDataFlashInROMMode(ToFile)

        Dim yByte() As Byte
        ReDim yByte(33)
        DumpGGfile = modGGDF.ReadDataFlash(yByte, 0, 0, 32)

        modComm.Terminate()
        Dim Hnd As Integer
        Hnd = Shell("INIfile.EvalSoftware")

    End Function
    Public Function Read_Flash_HwRevsionZ80(ByRef HwRev As Short) As EV2300_ErrorCode
        Dim TheData() As Byte
        ReDim TheData(1)

        HwRev = 0

        'Read_Flash_HwRevsionZ80 = modGGDF.ReadDataFlash(TheData, 56, 6, 2)
        Read_Flash_HwRevsionZ80 = Me.ReadEEPROM_Int16(56, 6, HwRev)
        'Convert to short
        Utility.BytesToShort(TheData(0), TheData(1), HwRev)

    End Function
    Public Function Read_Flash_ManufInfoZ45(ByRef ManuInfo As String) As EV2300_ErrorCode
        Dim FirstByte As Integer = 0
        Dim Offset As Integer = 33

        Dim TheData() As Byte
        Dim iVal As Short
        Dim BigData() As Byte
        ReDim BigData(FirstByte)

        Read_Flash_ManufInfoZ45 = Me.ReadEEPROM_Int16(58, Offset, iVal, TheData)
        If Read_Flash_ManufInfoZ45 <> EV2300_ErrorCode.VB_NO_ERROR Then Exit Function

        ManuInfo = ""

        'Read_Flash_ManufInfoZ80 = modGGDF.ReadDataFlash(TheData, 58, 0, 8)
        'Read_Flash_ManufBlockZ45 = Me.ReadEEPROM_Word(58, EndOffset, iVal, TheData)
        'Convert to string
        Dim I As Short
        Dim StringLeng As Integer = TheData(FirstByte)

        For I = 1 To StringLeng  'First byte contains chr(32), whatever that is...
            ManuInfo = ManuInfo & Chr(TheData(FirstByte + I))
        Next
    End Function
    Public Function Read_Flash_ManufBlockZ45(ByVal BlockNumb0_4 As Integer, ByRef ManuInfo As String) As EV2300_ErrorCode
        Dim FirstByte As Integer
        Dim Offset As Integer
        Select Case BlockNumb0_4
            Case 0
                Offset = 0
                FirstByte = 0
            Case 1
                Offset = 53
                FirstByte = 32
            Case 2
                Offset = 74
                FirstByte = 53
            Case 3
                Offset = 95
                FirstByte = 74
            Case 4
                Offset = 107
                FirstByte = 95
            Case Else
                Return EV2300_ErrorCode.NEX_GENERIC_ERROR
        End Select


        Dim TheData() As Byte
        Dim iVal As Short
        Dim BigData() As Byte
        ReDim BigData(FirstByte)

        Read_Flash_ManufBlockZ45 = Me.ReadEEPROM_Int16(58, Offset, iVal, TheData)
        'If Read_Flash_ManufBlockZ45 <> EV2300_ErrorCode.VB_NO_ERROR Then Exit Function

        ManuInfo = ""

        'Read_Flash_ManufInfoZ80 = modGGDF.ReadDataFlash(TheData, 58, 0, 8)
        'Read_Flash_ManufBlockZ45 = Me.ReadEEPROM_Word(58, EndOffset, iVal, TheData)
        'Convert to string
        Dim I As Short

        Dim StringLeng As Integer
        Try
            StringLeng = TheData(FirstByte)
        Catch ex As Exception
            StringLeng = 0
        End Try
        If StringLeng > 20 Then StringLeng = 20
        For I = 1 To StringLeng  'First byte contains the string length
            Try
                ManuInfo = ManuInfo & Chr(TheData(FirstByte + I))
            Catch ex As Exception
                AddStatusMessage("Runtime Error: Ev2300CommInterface.Read_Flash_ManufBlockZ25  " & ex.Message)
            End Try
        Next
    End Function
    Public Function Read_Flash_ManufInfoZ80(ByRef ManuInfo As String) As EV2300_ErrorCode
        Dim TheData() As Byte
        Dim iVal As Short

        ManuInfo = ""

        'Read_Flash_ManufInfoZ80 = modGGDF.ReadDataFlash(TheData, 58, 0, 8)
        Read_Flash_ManufInfoZ80 = Me.ReadEEPROM_Int16(58, 0, iVal, TheData)
        'Convert to string
        Dim I As Short
        If Read_Flash_ManufInfoZ80 = EV2300_ErrorCode.VB_NO_ERROR Then
            For I = 0 To 7 'First byte contains chr(8), whatever that is...
                ManuInfo = ManuInfo & Chr(TheData(I))
            Next
        End If
    End Function
    Public Function Write_Flash_ManufBlockZ45(ByVal BlockNumb1_4 As Integer, ByVal ManuInfo As String) As EV2300_ErrorCode
        Dim TheData() As Byte
        ReDim TheData(0)

        Dim Offset As Integer
        Select Case BlockNumb1_4
            Case 1
                Offset = 32
            Case 2
                Offset = 53
            Case 3
                Offset = 74
            Case 4
                Offset = 95
            Case Else
                Return EV2300_ErrorCode.NEX_GENERIC_ERROR
        End Select
        ManuInfo = Left(ManuInfo, 20) 'max number of characters for bq20z45
        'ManuInfo = ManuInfo.PadRight(19, " ")
        Dim aVal As Short
        Write_Flash_ManufBlockZ45 = ReadEEPROM_Int16(58, 126, aVal, TheData) ''Do this to read all the data in the subclass

        Dim I As Short
        For I = 1 To Len(ManuInfo) 'Poke new data into the existing array
            TheData(Offset + I) = Asc(Mid(ManuInfo, I, 1))
        Next
        TheData(Offset) = ManuInfo.Length
        Write_Flash_ManufBlockZ45 = modGGDF.WriteDataFlash(TheData, 58, Offset, ManuInfo.Length + 0)

    End Function
    Public Function Write_Flash_Block(ByVal TheData() As Byte, ByVal SubclassID As Short, ByVal Offset As Short, ByVal NumbBytesToWrite As Short) As EV2300_ErrorCode
        'Writes BytesCount bytes into Dataflash, Subclass and Offset
        If TheData.Length < NumbBytesToWrite Then
            Err.Raise(1001, Me, "NumbBytesToWrite=" & NumbBytesToWrite.ToString & "   TheData().Length=" & TheData.Length)
        End If
        Try
            Write_Flash_Block = modGGDF.WriteDataFlash(TheData, SubclassID, Offset, NumbBytesToWrite)
        Catch ex As Exception
            If Write_Flash_Block = 0 Then Write_Flash_Block = EV2300_ErrorCode.VB_UNEXPECTED_ERROR

        End Try
        'Write_Flash_Block = modGGDF.WriteDataFlash(TheData, 58, 0, 32)

    End Function

    Public Function Write_Flash_ManufInfoZ45(ByVal ManuInfo As String) As EV2300_ErrorCode
        Dim TheData() As Byte
        ReDim TheData(33)
        ManuInfo = Left(ManuInfo, 32) 'max number of characters for bq20z45. Last char is \0
        TheData(0) = ManuInfo.Length
        'bq20z90 requires 20
        Dim I As Short
        For I = 1 To Len(ManuInfo)
            TheData(I) = Asc(Mid(ManuInfo, I, 1))
        Next
        ReDim Preserve TheData(32)
        If modGGDF Is Nothing Then modGGDF = New Ev2300CommInterface.strmodGGDF
        Write_Flash_ManufInfoZ45 = modGGDF.WriteDataFlash(TheData, 58, 0, 32)
        Utility.Delay(2000) 'Wait a while for the flash write to complete. Z45, Z60 takes a LONG time!!
    End Function
    Public Function Write_Flash_ManufInfoZ80(ByVal ManuInfo As String) As EV2300_ErrorCode
        Dim TheData() As Byte
        ManuInfo = Left(ManuInfo, 8) 'max number of characters for bq20z80
        'bq20z90 requires 20
        Do Until Len(ManuInfo) >= 8
            ManuInfo = ManuInfo & Chr(0)
        Loop

        ReDim TheData(9)

        Dim I As Short
        For I = 1 To Len(ManuInfo)
            TheData(I) = Asc(Mid(ManuInfo, I, 1))
        Next
        TheData(0) = 8 '?
        Write_Flash_ManufInfoZ80 = modGGDF.WriteDataFlash(TheData, 58, 0, 9)
    End Function

    Public Function PackIsSealed(ByRef IsSealed As Boolean) As EV2300_ErrorCode
        Dim By As Short
        PackIsSealed = ManufacturerAccessOperation(enSMBRegister_z80.OpStatus, By)
        By = By And &H2000S
        IsSealed = By <> 0
    End Function
    Public Function IT_IsEnabled(ByRef ItEnabled As Boolean) As EV2300_ErrorCode
        'Check for QEN bit set
        Dim By As Short
        IT_IsEnabled = Me.Read_SMBus_Word_en(enSMBRegister_z80.OpStatus, By)
        By = By And &H1S
        ItEnabled = By <> 0
    End Function
    Public Function ErrorCode2String(ByRef ErrorCode As EV2300_ErrorCode) As String
        'ErrorCode2String = modErrCodes.ErrorCode2String(ErrorCode)
        Return ErrorCode.ToString
    End Function
    Public Function Shutdown(ByVal MessageLevel As Integer) As EV2300_ErrorCode
        'Shuts down the pack
        '772=Success
        'Will not work with charge voltage applied!!
        Dim MaxFETOffRetry As Integer = 3
        Dim FetOffCnt As Integer
        Dim FetsAreOff As Boolean

        Dim DontCare As Short, FetStat As Short

        Dim ResetDelays() As Integer = {1000, 2000, 4000} 'Some units take longer to reset than others. Most seem to work OK with 1sec. 
        '                                                 'If this one takes longer, then retry with the longer delay
        Dim ThisDelay As Integer
        For Each ThisDelay In ResetDelays
            Shutdown = Unseal() 'Just in case
            Utility.Delay(200)
            Shutdown = Write_SMBus_Word_en(enSMBRegister_z80.ManufacturerAccess, &H41) 'reset
            Utility.Delay(ThisDelay) 'All to unseal, reset and unseal again
            Shutdown = Unseal()

            Utility.Delay(200)
            If Shutdown = 0 Then
                Do
                    FetOffCnt = FetOffCnt + 1
                    Shutdown = TurnOffFETs()
                    Utility.Delay(1500) 'Not too fast here
                    Shutdown = Read_SMBus_Word_en(enSMBRegister_z80.FET_Status, FetStat)
                    FetsAreOff = FetStat = 0
                    AddStatusMessage("Turn Off FETs, wait 1500ms Attempt: " & FetOffCnt & " of " & MaxFETOffRetry & "   FET Status now " & Hex(FetStat), MessageLevel)
                Loop Until FetsAreOff Or FetOffCnt >= MaxFETOffRetry
                AddStatusMessage("Attempt to turn off FETs was " & IIf(FetStat = 0, "Successful", "Not Successful"), MessageLevel)
            Else
                Shutdown = -1 'error code
            End If
            If Shutdown = EV2300_ErrorCode.VB_NO_ERROR Then
                'Bye Bye
                Shutdown = Write_SMBus_Word_en(enSMBRegister_z80.ManufacturerAccess, &H10)
                Utility.Delay(2000)
            Else
                Shutdown = EV2300_ErrorCode.NEX_GENERIC_ERROR 'error code
            End If
            If Shutdown = EV2300_ErrorCode.VB_NO_ERROR Then
                Shutdown = Read_SMBus_Word_en(enSMBRegister_z80.SerialNumber, DontCare) 'Should fail
            End If
            If Shutdown = EV2300_ErrorCode.VB_T2H_NACK Then
                Exit For
            End If
        Next
    End Function
    Public Function TurnOffFETs() As EV2300_ErrorCode
        TurnOffFETs = Me.Write_SMBus_Word_en(enSMBRegister_z80.FET_Status, &H0)
    End Function
    Public Function TurnOnFETs() As EV2300_ErrorCode
        TurnOnFETs = Me.Write_SMBus_Word_en(enSMBRegister_z80.FET_Status, &H6)
    End Function
    Public Function Read_Serial(ByRef Serial As UShort) As EV2300_ErrorCode
        Dim iSerial As Short
        Read_Serial = Me.Read_SMBus_Word_en(enSMBRegister_z80.SerialNumber, iSerial)
        Serial = Short2UShort(iSerial)
    End Function
    Public Function UShort2Short(ByVal UShrt As UShort) As Short
        Dim Mask As Short, i As Integer
        UShort2Short = 0
        For i = 0 To 14
            Mask = 2 ^ i
            If (UShrt And Mask) <> 0 Then
                UShort2Short = UShort2Short Or Mask 'Set the bit
            End If
        Next
        Mask = &H8000S
        If (UShrt And Mask) <> 0 Then
            UShort2Short = UShort2Short Or Mask 'Set the bit
        End If

    End Function
    Private Function Short2UShort(ByVal Shrt As Short) As UShort
        'This avoids overflow errors
        Dim FirstBit As Boolean = (Shrt And &H8000S) <> 0
        Short2UShort = (Shrt And &H7FFFS)
        If FirstBit Then Short2UShort = Short2UShort Or &H8000US
    End Function
    Public Function Write_Serial(ByVal NewSerial As UShort) As EV2300_ErrorCode
        Dim CheckSerial As UShort
        Dim iNewSerial As Short = UShort2Short(NewSerial)
        Unseal()
        'Write_Serial = Me.WriteEEPROM_Word(48, 14, NewSerial)
        Write_Serial = Me.Write_SMBus_Word_en(enSMBRegister_z80.SerialNumber, iNewSerial)
        'Write_Serial = Me.Write_SMBus_Word_en(enSMBRegister_z80.SerialNumber, NewSerial)
        If Write_Serial = EV2300_ErrorCode.VB_NO_ERROR Then
            '    Write_Serial = Me.ManufacturerAccessOperation(&H41, DontCare)
            Utility.Delay(500)
            'The bq20z80 does not need a reset after writing SN. 
            'This eliminates the problem of the bq20z80 needed a long time to settle in on a voltage measurement (>1 minute)
        End If
        If Write_Serial = EV2300_ErrorCode.VB_NO_ERROR Then
            Write_Serial = Me.Read_Serial(CheckSerial)
        End If
        If Write_Serial = EV2300_ErrorCode.VB_NO_ERROR And NewSerial <> CheckSerial Then
            Write_Serial = EV2300_ErrorCode.NEX_SERIAL_WRITE_NOT_CONFIRMED
        End If
    End Function
    Public Function Read_SMBus_Word_en(ByVal Subcmd As enSMBRegister_z80, ByRef TheData As Short) As EV2300_ErrorCode
        Dim sCmd As Short = Subcmd
        Read_SMBus_Word_en = Bq80xRW1.ReadSMBusWord(sCmd, TheData, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommReadComplete(Subcmd, Utility.Short2Hex(TheData), DEFAULT_TARGET_ADDR, Read_SMBus_Word_en)
        'Dim bSubcmd As Byte
        'bSubcmd = CByte(Subcmd)
        'Read_SMBus_Word_en = modComm.ReadSMBusWord_(Subcmd, TheData)
    End Function
    Public Function Write_SMBus_Word_en(ByVal Subcmd As enSMBRegister_z80, ByRef TheData As Short) As EV2300_ErrorCode
        Try
            Dim bSubcmd As Short
            bSubcmd = CByte(Subcmd)
            'Write_SMBus_Word_en = modComm.WriteSMBusWord_(bSubcmd, TheData)
            Write_SMBus_Word_en = Bq80xRW1.WriteSMBusWord(bSubcmd, TheData, DEFAULT_TARGET_ADDR)
        Catch ex As Exception
            Return -2
        End Try
        RaiseEvent DataCommWriteComplete(Subcmd, Short2Hex(TheData), DEFAULT_TARGET_ADDR, Write_SMBus_Word_en)
    End Function
    Public Function ReadDate(ByRef TheDate As Date) As EV2300_ErrorCode
        'ReadDate = modGGDF.ReadDate_(TheDate)
        Dim nDate As Short
        ReadDate = Me.Read_SMBus_Word_en(enSMBRegister_z80.ManufactureDate, nDate)
        Dim Mask As Short
        If ReadDate = 0 Then
            Dim MM, YY, DD As Short
            Mask = &HFE00S
            YY = nDate And &HFE00
            YY = YY / (2 ^ 9) + 1980

            Mask = &H1E0
            MM = nDate And Mask
            MM = MM / (2 ^ 5)

            Mask = &H1F
            DD = nDate And &H1F
            If DD = 0 Then DD = 1
            If MM = 0 Then MM = 1

            TheDate = CDate(MM & "/" & DD & "/" & YY)
        End If
    End Function
    Public Function WriteDate(ByVal NewDate As Date) As EV2300_ErrorCode
        Dim nDate As UShort
        'NewDate = "2/13/2009"
        nDate = (Year(NewDate) - 1980) * &H200 Or Month(NewDate) * &H20 Or VB.Day(NewDate) 'Conditional Current date
        WriteDate = Me.Write_SMBus_Word_en(enSMBRegister_z80.ManufactureDate, nDate)
        'Write_Serial = Me.Write_SMBus_Word_en(enSMBRegister_z80.SerialNumber, NewSerial)
        If WriteDate = EV2300_ErrorCode.VB_NO_ERROR Then
            '    Write_Serial = Me.ManufacturerAccessOperation(&H41, DontCare)
            Utility.Delay(500)
            'The bq20z80 does not need a reset after writing SN. 
            'This eliminates the problem of the bq20z80 needed a long time to settle in on a voltage measurement (>1 minute)
        End If
        Dim CheckDate As Date
        If WriteDate = EV2300_ErrorCode.VB_NO_ERROR Then
            WriteDate = Me.ReadDate(CheckDate)
        End If
        If WriteDate = EV2300_ErrorCode.VB_NO_ERROR And NewDate <> CheckDate Then
            WriteDate = EV2300_ErrorCode.NEX_DOM_WRITE_NOT_CONFIRMED
        End If

    End Function
    Public Function WriteDate_TruEEPROM(ByVal NewDate As Date) As EV2300_ErrorCode
        'WriteDate = modGGDF.WriteDate_(NewDate)
        Dim nDate As UShort
        'NewDate = "2/13/2009"
        nDate = (Year(NewDate) - 1980) * &H200 Or Month(NewDate) * &H20 Or VB.Day(NewDate) 'Conditional Current date
        'WriteDate_ = WriteDate(nDate)
        'For the Z80....
        'WriteDate_ = WriteGGModeDataFlashConstant(48, 12, nDate)
        'WriteDate = Me.Write_SMBus_Word_en(enSMBRegister_z80.ManufactureDate, nDate)

        'WriteDate = Me.Write_SMBus_Word_en(enSMBRegister_z80.ManufacturerAccess, &H41)
        WriteDate_TruEEPROM = Me.WriteEEPROM_UInt16(48, 12, nDate)
        Utility.Delay(500)

        Dim ChkDate As Date
        If WriteDate_TruEEPROM = EV2300_ErrorCode.VB_NO_ERROR Then
            WriteDate_TruEEPROM = ReadDate(ChkDate)
            If WriteDate_TruEEPROM = EV2300_ErrorCode.VB_NO_ERROR Then
                If VB6.Format(ChkDate, "MM/DD/YYYY") <> VB6.Format(NewDate, "MM/DD/YYYY") Then
                    WriteDate_TruEEPROM = EV2300_ErrorCode.NEX_DOM_WRITE_NOT_CONFIRMED
                End If
            End If
        End If
    End Function
    'Public Function Read_FLASH_Word(ByVal SubclassID As Short, ByRef offset As Short, ByRef TheValue As Object) As  EV2300_ErrorCode
    '    'TheValue can be byte or integer
    '    Read_FLASH_Word = modGGDF.ReadGGModeDataFlashConstant(SubclassID, offset, TheValue)

    'End Function
    'Public Function Write_FLASH_Word(ByVal SubclassID As Short, ByRef offset As Short, ByRef ValueToWrite As Short) As  EV2300_ErrorCode
    '    Write_FLASH_Word = modGGDF.WriteGGModeDataFlashConstant(SubclassID, offset, ValueToWrite)
    '    RaiseEvent DataCommComplete(Subcmd, nData, DEFAULT_TARGET_ADDR, Write_FLASH_Word)
    'End Function
    Public Function Read_SMBus_Word(ByVal Subcmd As Short, ByRef nData As Short) As EV2300_ErrorCode
        Read_SMBus_Word = Bq80xRW1.ReadSMBusWord(Subcmd, nData, DEFAULT_TARGET_ADDR)
        'Read_SMBus_Word = modComm.ReadSMBusWord_(Subcmd, nData)
        RaiseEvent DataCommReadComplete(Subcmd, Utility.Short2Hex(nData), DEFAULT_TARGET_ADDR, Read_SMBus_Word)
    End Function
    Public Function Write_SMBus_Word(ByVal Subcmd As Byte, ByRef nData As Short) As EV2300_ErrorCode
        Write_SMBus_Word = modComm.WriteSMBusWord_(Subcmd, nData)
        RaiseEvent DataCommWriteComplete(Subcmd, Utility.Short2Hex(nData), DEFAULT_TARGET_ADDR, Write_SMBus_Word)
    End Function
    Public Function Read_SMBus_Block(ByVal Subcmd As Short, ByRef sData As String, ByVal Len As Integer) As EV2300_ErrorCode
        Dim DBlock As Object
        Read_SMBus_Block = Bq80xRW1.ReadSMBusBlock(Subcmd, DBlock, Len, DEFAULT_TARGET_ADDR)
        If IsArray(DBlock) Then
            sData = Utility.ByteArr2String(DBlock)
        End If
        RaiseEvent DataCommWriteComplete(Subcmd, sData, DEFAULT_TARGET_ADDR, Read_SMBus_Block)
    End Function
    Public Function Read_SMBus_Block(ByVal Subcmd As Short, ByRef bData() As Byte, ByVal Len As Integer) As EV2300_ErrorCode
        Dim DBlock As Object
        Read_SMBus_Block = Bq80xRW1.ReadSMBusBlock(Subcmd, DBlock, Len, DEFAULT_TARGET_ADDR)
        If IsArray(DBlock) Then
            bData = DBlock.clone
        End If
        RaiseEvent DataCommReadComplete(Subcmd, Utility.ByteArr2String(bData), DEFAULT_TARGET_ADDR, Read_SMBus_Block)
    End Function
    Public Function Write_TwoWordCommand(ByVal Reg As Byte, ByRef W1 As Short, ByRef W2 As Short) As EV2300_ErrorCode
        Write_TwoWordCommand = Me.Write_SMBus_Word(Reg, W1)
        If Write_TwoWordCommand = EV2300_ErrorCode.VB_NO_ERROR Then
            Write_TwoWordCommand = Me.Write_SMBus_Word(Reg, W2)
        End If
    End Function
    Public Function ManufacturerAccessOperation(ByVal WriteValue As Short, ByRef Response As Short) As Integer
        'Writes OpNumber in MA Register (Reg &H0000) and reads back the result
        Dim Subcmd As Byte
        Subcmd = 0
        ManufacturerAccessOperation = Write_SMBus_Word(Subcmd, WriteValue)
        Call Utility.Delay(100)
        ManufacturerAccessOperation = ManufacturerAccessOperation And Read_SMBus_Word(&H0, Response)
    End Function
    Public Function GetChemCode(ByRef ChemCode As Short) As Integer
        GetChemCode = Me.ManufacturerAccessOperation(&H8, ChemCode)
    End Function
    Public Function GetFWversion(ByRef FW_Ver As Short) As Integer
        GetFWversion = ManufacturerAccessOperation(&H2, FW_Ver) '
    End Function
    Public Function GetFG_Value(ByRef FG_Value As Short) As Integer
        GetFG_Value = Me.Read_SMBus_Word(&HD, FG_Value)
    End Function
    Public Function GetPackTemperature(ByRef PackTemp As Double) As Integer
        Dim iPackTemp As Short
        GetPackTemperature = Me.Read_SMBus_Word_en(enSMBRegister_z80.Temperature, iPackTemp)
        PackTemp = iPackTemp / 10.0# - 273.15
    End Function
    Public Function GetPcaSerial(ByRef PcaSerial As Short) As Integer
        'GetPcaSerial = Me.Read_FLASH_Word(56, 2, PcaSerial)
        Return Me.ReadEEPROM_Int16(56, 2, PcaSerial)
    End Function
    Public Function WriteEEPROM_UByte8(ByVal SubclassID As Short, ByVal Offset As Short, ByVal TheValue As SByte) As EV2300_ErrorCode
        Try
            Dim DelMs As Integer = 100 'Dont hit the bq20z90 too quick

            Dim AllTheBytes() As Byte
            WriteEEPROM_UByte8 = ReadEEPROM_BigBlockOnly(SubclassID, Offset, AllTheBytes)

            If WriteEEPROM_UByte8 <> 0 Then Exit Function 'The read failed, don't continue

            Dim Sw As New Stopwatch
            Sw.Start()
            'Write new value into TheBytes
            AllTheBytes(Offset) = Utility.SByte2Byte(TheValue)

            'Break up TheBytes into 32 byte chunks
            Dim Chunk1(), Chunk2(), Chunk3(), Chunk4() As Byte
            Chunk1 = Nothing
            Chunk2 = Nothing
            Chunk3 = Nothing
            Chunk4 = Nothing
            Dim i As Integer, ThereIsMore As Boolean = True
            i = 0
            Do While ThereIsMore And i < 32
                If Chunk1 Is Nothing Then
                    ReDim Chunk1(0)
                Else
                    ReDim Preserve Chunk1(UBound(Chunk1) + 1)
                End If
                Chunk1(UBound(Chunk1)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 2
                If Chunk2 Is Nothing Then
                    ReDim Chunk2(0)
                Else
                    ReDim Preserve Chunk2(UBound(Chunk2) + 1)
                End If
                Chunk2(UBound(Chunk2)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 3
                If Chunk3 Is Nothing Then
                    ReDim Chunk3(0)
                Else
                    ReDim Preserve Chunk3(UBound(Chunk3))
                End If
                Chunk3(UBound(Chunk3)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 4
                If Chunk4 Is Nothing Then
                    ReDim Chunk4(0)
                Else
                    ReDim Preserve Chunk4(UBound(Chunk4))
                End If
                Chunk4(UBound(Chunk4)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)

            'write it back now...
            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            WriteEEPROM_UByte8 = Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1)
            RaiseEvent DataCommWriteComplete(&H77, SubclassID, DEFAULT_TARGET_ADDR, WriteEEPROM_UByte8)
            Dim Leng As Short
            If Not Chunk1 Is Nothing Then
                Leng = Chunk1.GetLength(0)
                WriteEEPROM_UByte8 = Bq80xRW1.WriteSMBusBlock(&H78S, Chunk1, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H78, Chunk1, WriteEEPROM_UByte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk2 Is Nothing Then
                Leng = Chunk2.GetLength(0)
                If Not Chunk2 Is Nothing Then WriteEEPROM_UByte8 = Bq80xRW1.WriteSMBusBlock(&H79, Chunk2, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H79, Chunk2, WriteEEPROM_UByte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()

            If Not Chunk3 Is Nothing Then
                Leng = Chunk3.GetLength(0)
                WriteEEPROM_UByte8 = Bq80xRW1.WriteSMBusBlock(&H7A, Chunk3, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7A, Chunk3, WriteEEPROM_UByte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk4 Is Nothing Then
                Leng = Chunk4.GetLength(0)
                WriteEEPROM_UByte8 = Bq80xRW1.WriteSMBusBlock(&H7B, Chunk4, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7B, Chunk4, WriteEEPROM_UByte8)
            End If
        Catch ex As Exception
            WriteEEPROM_UByte8 = EV2300_ErrorCode.NEX_WriteEEPROM_Word_RuntimeError 'This code generated an error
        End Try

    End Function
    Public Function WriteEEPROM_Byte8(ByVal SubclassID As Short, ByVal Offset As Short, ByVal TheValue As Byte) As EV2300_ErrorCode
        Try
            Dim DelMs As Integer = 100 'Dont hit the bq20z90 too quick

            Dim AllTheBytes() As Byte
            WriteEEPROM_Byte8 = ReadEEPROM_BigBlockOnly(SubclassID, Offset, AllTheBytes)

            If WriteEEPROM_Byte8 <> 0 Then Exit Function 'The read failed, don't continue

            Dim Sw As New Stopwatch
            Sw.Start()
            'Write new value into TheBytes
            AllTheBytes(Offset) = TheValue

            'Break up TheBytes into 32 byte chunks
            Dim Chunk1(), Chunk2(), Chunk3(), Chunk4() As Byte
            Chunk1 = Nothing
            Chunk2 = Nothing
            Chunk3 = Nothing
            Chunk4 = Nothing
            Dim i As Integer, ThereIsMore As Boolean = True
            i = 0
            Do While ThereIsMore And i < 32
                If Chunk1 Is Nothing Then
                    ReDim Chunk1(0)
                Else
                    ReDim Preserve Chunk1(UBound(Chunk1) + 1)
                End If
                Chunk1(UBound(Chunk1)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 2
                If Chunk2 Is Nothing Then
                    ReDim Chunk2(0)
                Else
                    ReDim Preserve Chunk2(UBound(Chunk2) + 1)
                End If
                Chunk2(UBound(Chunk2)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 3
                If Chunk3 Is Nothing Then
                    ReDim Chunk3(0)
                Else
                    ReDim Preserve Chunk3(UBound(Chunk3))
                End If
                Chunk3(UBound(Chunk3)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 4
                If Chunk4 Is Nothing Then
                    ReDim Chunk4(0)
                Else
                    ReDim Preserve Chunk4(UBound(Chunk4))
                End If
                Chunk4(UBound(Chunk4)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)

            'write it back now...
            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            WriteEEPROM_Byte8 = Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1)
            RaiseEvent DataCommWriteComplete(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1, WriteEEPROM_Byte8)
            'Note: This write operation does not work with one byte Sublclasses.
            'For example bq20z80, Host Comm, SubclassID 3 consists of only one byte. The DLL returns code 7 (VB_INCORRECT_PARAM)
            'TODO Fix this!!
            Dim Leng As Short
            If Not Chunk1 Is Nothing Then
                Leng = Chunk1.GetLength(0)
                WriteEEPROM_Byte8 = Bq80xRW1.WriteSMBusBlock(&H78S, Chunk1, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H78, Chunk1, WriteEEPROM_Byte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk2 Is Nothing Then
                Leng = Chunk2.GetLength(0)
                If Not Chunk2 Is Nothing Then WriteEEPROM_Byte8 = Bq80xRW1.WriteSMBusBlock(&H79, Chunk2, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H79, Chunk2, WriteEEPROM_Byte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()

            If Not Chunk3 Is Nothing Then
                Leng = Chunk3.GetLength(0)
                WriteEEPROM_Byte8 = Bq80xRW1.WriteSMBusBlock(&H7A, Chunk3, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7A, Chunk3, WriteEEPROM_Byte8)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk4 Is Nothing Then
                Leng = Chunk4.GetLength(0)
                WriteEEPROM_Byte8 = Bq80xRW1.WriteSMBusBlock(&H7B, Chunk4, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7B, Chunk4, WriteEEPROM_Byte8)
            End If
        Catch ex As Exception
            WriteEEPROM_Byte8 = EV2300_ErrorCode.NEX_WriteEEPROM_Word_RuntimeError 'This code generated an error
        End Try

    End Function
    Public Function WriteEEPROM_Int16(ByVal SubclassID As Short, ByVal Offset As Short, ByVal TheValue As Int16) As EV2300_ErrorCode
        Try
            Dim DelMs As Integer = 100 'Dont hit the bq20z90 too quick

            Dim PresVal As Short, AllTheBytes() As Byte
            WriteEEPROM_Int16 = ReadEEPROM_Int16(SubclassID, Offset, PresVal, AllTheBytes)

            If WriteEEPROM_Int16 <> 0 Then Exit Function 'The read failed, don't continue

            Dim Sw As New Stopwatch
            Sw.Start()
            'Write new value into TheBytes
            Dim Msb, Lsb As Short
            Utility.ShortToBytes(TheValue, Msb, Lsb)
            AllTheBytes(Offset) = Msb
            AllTheBytes(Offset + 1) = Lsb

            'Break up TheBytes into 32 byte chunks
            Dim Chunk1(), Chunk2(), Chunk3(), Chunk4() As Byte
            Chunk1 = Nothing
            Chunk2 = Nothing
            Chunk3 = Nothing
            Chunk4 = Nothing
            Dim i As Integer, ThereIsMore As Boolean = True
            i = 0
            Do While ThereIsMore And i < 32
                If Chunk1 Is Nothing Then
                    ReDim Chunk1(0)
                Else
                    ReDim Preserve Chunk1(UBound(Chunk1) + 1)
                End If
                Chunk1(UBound(Chunk1)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 2
                If Chunk2 Is Nothing Then
                    ReDim Chunk2(0)
                Else
                    ReDim Preserve Chunk2(UBound(Chunk2) + 1)
                End If
                Chunk2(UBound(Chunk2)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 3
                If Chunk3 Is Nothing Then
                    ReDim Chunk3(0)
                Else
                    ReDim Preserve Chunk3(UBound(Chunk3))
                End If
                Chunk3(UBound(Chunk3)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 4
                If Chunk4 Is Nothing Then
                    ReDim Chunk4(0)
                Else
                    ReDim Preserve Chunk4(UBound(Chunk4))
                End If
                Chunk4(UBound(Chunk4)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)

            'write it back now...
            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            WriteEEPROM_Int16 = Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1)
            RaiseEvent DataCommWriteComplete(&H77, Hex(SubclassID), DEFAULT_TARGET_ADDR, WriteEEPROM_Int16)
            Dim Leng As Short
            If Not Chunk1 Is Nothing Then
                Leng = Chunk1.GetLength(0)
                WriteEEPROM_Int16 = Bq80xRW1.WriteSMBusBlock(&H78S, Chunk1, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H78, Chunk1, WriteEEPROM_Int16)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk2 Is Nothing Then
                Leng = Chunk2.GetLength(0)
                If Not Chunk2 Is Nothing Then WriteEEPROM_Int16 = Bq80xRW1.WriteSMBusBlock(&H79, Chunk2, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H79, Chunk2, WriteEEPROM_Int16)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()

            If Not Chunk3 Is Nothing Then
                Leng = Chunk3.GetLength(0)
                WriteEEPROM_Int16 = Bq80xRW1.WriteSMBusBlock(&H7A, Chunk3, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7A, Chunk3, WriteEEPROM_Int16)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk4 Is Nothing Then
                Leng = Chunk4.GetLength(0)
                WriteEEPROM_Int16 = Bq80xRW1.WriteSMBusBlock(&H7B, Chunk4, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7B, Chunk4, WriteEEPROM_Int16)
            End If
        Catch ex As Exception
            WriteEEPROM_Int16 = EV2300_ErrorCode.NEX_WriteEEPROM_Word_RuntimeError 'This code generated an error
        End Try

    End Function
    Public Function WriteEEPROM_UInt16(ByVal SubclassID As Short, ByVal Offset As Short, ByVal TheValue As UInt16) As EV2300_ErrorCode
        Try
            Dim DelMs As Integer = 100 'Dont hit the bq20z90 too quick

            Dim PresVal As Short, AllTheBytes() As Byte
            WriteEEPROM_UInt16 = ReadEEPROM_Int16(SubclassID, Offset, PresVal, AllTheBytes)
            If WriteEEPROM_UInt16 <> 0 Then Exit Function 'The read failed, don't continue

            Dim Sw As New Stopwatch
            Sw.Start()
            'Write new value into TheBytes
            Dim Msb, Lsb As Short
            Utility.ShortToBytesU(TheValue, Msb, Lsb)
            AllTheBytes(Offset) = Msb
            AllTheBytes(Offset + 1) = Lsb

            'Break up TheBytes into 32 byte chunks
            Dim Chunk1(), Chunk2(), Chunk3(), Chunk4() As Byte
            Chunk1 = Nothing
            Chunk2 = Nothing
            Chunk3 = Nothing
            Chunk4 = Nothing
            Dim i As Integer, ThereIsMore As Boolean = True
            i = 0
            Do While ThereIsMore And i < 32
                If Chunk1 Is Nothing Then
                    ReDim Chunk1(0)
                Else
                    ReDim Preserve Chunk1(UBound(Chunk1) + 1)
                End If
                Chunk1(UBound(Chunk1)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 2
                If Chunk2 Is Nothing Then
                    ReDim Chunk2(0)
                Else
                    ReDim Preserve Chunk2(UBound(Chunk2) + 1)
                End If
                Chunk2(UBound(Chunk2)) = AllTheBytes(i)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 3
                If Chunk3 Is Nothing Then
                    ReDim Chunk3(0)
                Else
                    ReDim Preserve Chunk3(UBound(Chunk3))
                End If
                Chunk3(UBound(Chunk3)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)
            Do While ThereIsMore And i < 32 * 4
                If Chunk4 Is Nothing Then
                    ReDim Chunk4(0)
                Else
                    ReDim Preserve Chunk4(UBound(Chunk4))
                End If
                Chunk4(UBound(Chunk4)) = AllTheBytes(i + 1)
                i = i + 1
                ThereIsMore = i <= UBound(AllTheBytes)
            Loop
            ThereIsMore = i <= UBound(AllTheBytes)

            'write it back now...
            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            WriteEEPROM_UInt16 = Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1)
            RaiseEvent DataCommWriteComplete(&H77, SubclassID, DEFAULT_TARGET_ADDR - 1, WriteEEPROM_UInt16)
            Dim Leng As Short
            If Not Chunk1 Is Nothing Then
                Leng = Chunk1.GetLength(0)
                WriteEEPROM_UInt16 = Bq80xRW1.WriteSMBusBlock(&H78S, Chunk1, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H78, Chunk1, WriteEEPROM_UInt16)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk2 Is Nothing Then
                Leng = Chunk2.GetLength(0)
                If Not Chunk2 Is Nothing Then
                    WriteEEPROM_UInt16 = Bq80xRW1.WriteSMBusBlock(&H79, Chunk2, Leng, DEFAULT_TARGET_ADDR)
                    RaiseEvent DataCommBlockWriteComplete(&H79, Chunk2, WriteEEPROM_UInt16)
                End If

            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()

            If Not Chunk3 Is Nothing Then
                Leng = Chunk3.GetLength(0)
                WriteEEPROM_UInt16 = Bq80xRW1.WriteSMBusBlock(&H7A, Chunk3, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7A, Chunk3, WriteEEPROM_UInt16)
            End If

            Do Until Sw.ElapsedMilliseconds >= DelMs
                My.Application.DoEvents()
            Loop
            Sw.Reset()
            Sw.Start()
            If Not Chunk4 Is Nothing Then
                Leng = Chunk4.GetLength(0)
                WriteEEPROM_UInt16 = Bq80xRW1.WriteSMBusBlock(&H7B, Chunk4, Leng, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockWriteComplete(&H7B, Chunk4, WriteEEPROM_UInt16)
            End If
        Catch ex As Exception
            WriteEEPROM_UInt16 = EV2300_ErrorCode.NEX_WriteEEPROM_Word_RuntimeError 'This code generated an error
        End Try

    End Function
    Public Function ReadEEPROM_UInt16(ByVal SubclassID As Short, ByVal Offset As Short, ByRef TheValue As UInt16, Optional ByRef BigBlock() As Byte = Nothing) As EV2300_ErrorCode
        'Unsigned 8 bit byte
        Dim DontCare As Short
        ReadEEPROM_UInt16 = ReadEEPROM_Int16(SubclassID, Offset, DontCare, BigBlock)
        If ReadEEPROM_UInt16 = EV2300_ErrorCode.VB_NO_ERROR Then
            Try
                If DontCare >= 0 Then
                    'Fits into UInt16 
                    TheValue = DontCare
                Else
                    DontCare = DontCare And &H7FFFS
                    TheValue = DontCare
                    TheValue = TheValue Or &H8000US
                End If
            Catch ex As Exception
                AddStatusMessage("Error in Ev2300CommInterface.ReadEEPROM_U8  & " & ex.Message)
                Return EV2300_ErrorCode.NEX_ERROR_DURING_BLOCK_READ
            End Try
        End If
    End Function
    Public Function ReadEEPROM_Byte8(ByVal SubclassID As Short, ByVal Offset As Short, ByRef TheValue As Byte, Optional ByRef BigBlock() As Byte = Nothing) As EV2300_ErrorCode
        'Unsigned 8 bit byte
        ReadEEPROM_Byte8 = ReadEEPROM_BigBlockOnly(SubclassID, Offset, BigBlock)
        If ReadEEPROM_Byte8 = EV2300_ErrorCode.VB_NO_ERROR Then
            Try
                TheValue = BigBlock(Offset)
            Catch ex As Exception
                AddStatusMessage("Error in Ev2300CommInterface.ReadEEPROM_Byte8  & " & ex.Message)
                Return EV2300_ErrorCode.NEX_ERROR_DURING_BLOCK_READ
            End Try
        End If
    End Function
    Public Function ReadEEPROM_SByte8(ByVal SubclassID As Short, ByVal Offset As Short, ByRef TheValue As SByte, Optional ByRef BigBlock() As Byte = Nothing) As EV2300_ErrorCode
        'Unsigned 8 bit byte

        ReadEEPROM_SByte8 = ReadEEPROM_BigBlockOnly(SubclassID, Offset, BigBlock)
        If ReadEEPROM_SByte8 = EV2300_ErrorCode.VB_NO_ERROR Then
            Try
                TheValue = Utility.Byte2SByte(BigBlock(Offset))
            Catch ex As Exception
                AddStatusMessage("Error in Ev2300CommInterface.ReadEEPROM_SByte8  & " & ex.Message)
                Return EV2300_ErrorCode.NEX_ERROR_DURING_BLOCK_READ
            End Try
        End If
    End Function
    Public Function ReadEEPROM_Int16(ByVal SubclassID As Short, ByVal Offset As Short, ByRef TheValue As Short, Optional ByRef BigBlock() As Byte = Nothing) As EV2300_ErrorCode
        Dim DBlock1, DBlock2, DBlock3, DBlock4 As Object

        Try
            ReadEEPROM_Int16 = modComm.Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR)
            RaiseEvent DataCommWriteComplete( &H77 , Hex(SubclassID), DEFAULT_TARGET_ADDR, ReadEEPROM_Int16)
            ReadEEPROM_Int16 = Bq80xRW1.ReadSMBusBlock(&H78, DBlock1, 32, DEFAULT_TARGET_ADDR)
            RaiseEvent DataCommBlockReadComplete(&H78, DBlock1, ReadEEPROM_Int16)
            BigBlock = DBlock1.clone

            If Offset > 32 Then
                'Need the next block
                ReadEEPROM_Int16 = Bq80xRW1.ReadSMBusBlock(&H79, DBlock2, 32, &H16)
                RaiseEvent DataCommBlockReadComplete(&H79, DBlock2, ReadEEPROM_Int16)
                AppendArray(BigBlock, DBlock2)
            End If

            If Offset > 32 * 2 Then
                'Need the next block
                ReadEEPROM_Int16 = Bq80xRW1.ReadSMBusBlock(&H7A, DBlock3, 32, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockReadComplete(&H7A, DBlock3, ReadEEPROM_Int16)
                'Array.Copy(DBlock1, 0, BigBlock, 32, Len(DBlock1))
                AppendArray(BigBlock, DBlock3)
            End If
            If Offset > 32 * 3 Then
                'Need the next block
                ReadEEPROM_Int16 = Bq80xRW1.ReadSMBusBlock(&H7B, DBlock4, 32, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockReadComplete(&H7B, DBlock4, ReadEEPROM_Int16)
                'Array.Copy(DBlock1, 0, BigBlock, 32, Len(DBlock1))
                AppendArray(BigBlock, DBlock4)
            End If
            'Dim Tval As Integer = BigBlock(Offset)
            'Tval = Tval * (2 ^ 8)
            'Tval = Tval Or BigBlock(Offset + 1)
            'TheValue = Tval
            Utility.BytesToShort(BigBlock(Offset), BigBlock(Offset + 1), TheValue)

        Catch ex As Exception
            If ReadEEPROM_Int16 = EV2300_ErrorCode.VB_NO_ERROR Then
                ReadEEPROM_Int16 = EV2300_ErrorCode.NEX_ReadEEPROM_Word_RuntimeError 'This code generated an error
            Else
                ReadEEPROM_Int16 = EV2300_ErrorCode.NEX_ERROR_DURING_BLOCK_READ
            End If
        End Try
    End Function
    Public Function ReadEEPROM_BigBlockOnly(ByVal SubclassID As Short, ByVal Offset As Short, Optional ByRef BigBlock() As Byte = Nothing) As EV2300_ErrorCode
        Dim DBlock1, DBlock2, DBlock3, DBlock4 As Object
        ReadEEPROM_BigBlockOnly = EV2300_ErrorCode.VB_NO_ERROR
        Try
            ReadEEPROM_BigBlockOnly = modComm.Bq80xRW1.WriteSMBusWord(&H77, SubclassID, DEFAULT_TARGET_ADDR)
            RaiseEvent DataCommWriteComplete(&H77, SubclassID, DEFAULT_TARGET_ADDR, ReadEEPROM_BigBlockOnly)
            ReadEEPROM_BigBlockOnly = Bq80xRW1.ReadSMBusBlock(&H78, DBlock1, 32, DEFAULT_TARGET_ADDR)
            RaiseEvent DataCommBlockReadComplete(&H78, DBlock1, ReadEEPROM_BigBlockOnly)
            BigBlock = DBlock1.clone

            If Offset > 32 Then
                'Need the next block
                ReadEEPROM_BigBlockOnly = Bq80xRW1.ReadSMBusBlock(&H79, DBlock2, 32, &H16)
                RaiseEvent DataCommBlockReadComplete(&H79, DBlock2, ReadEEPROM_BigBlockOnly)
                AppendArray(BigBlock, DBlock2)
            End If

            If Offset > 32 * 2 Then
                'Need the next block
                ReadEEPROM_BigBlockOnly = Bq80xRW1.ReadSMBusBlock(&H7A, DBlock3, 32, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockReadComplete(&H7A, DBlock3, ReadEEPROM_BigBlockOnly)
                AppendArray(BigBlock, DBlock3)
            End If
            If Offset > 32 * 3 Then
                'Need the next block
                ReadEEPROM_BigBlockOnly = Bq80xRW1.ReadSMBusBlock(&H7B, DBlock4, 32, DEFAULT_TARGET_ADDR)
                RaiseEvent DataCommBlockReadComplete(&H7B, DBlock4, ReadEEPROM_BigBlockOnly)
                AppendArray(BigBlock, DBlock4)
            End If

        Catch ex As Exception
            If ReadEEPROM_BigBlockOnly = EV2300_ErrorCode.VB_NO_ERROR Then
                ReadEEPROM_BigBlockOnly = EV2300_ErrorCode.NEX_ReadEEPROM_Word_RuntimeError 'This code generated an error
            Else
                ReadEEPROM_BigBlockOnly = EV2300_ErrorCode.NEX_ERROR_DURING_BLOCK_READ
            End If
        End Try
    End Function
    Private Sub AppendArray(ByRef Targ() As Byte, ByVal Sourc() As Byte)
        Dim Dont As Boolean
        If Targ Is Nothing Then
            Dont = True
            ReDim Targ(0)
        End If
        Dim by As Byte
        For Each by In Sourc
            If Not Dont Then ReDim Preserve Targ(UBound(Targ) + 1)
            Dont = False
            Targ(UBound(Targ)) = by
        Next

    End Sub
    Function CalibrateBoardOffset_LinearApprox_withCentering(ByVal Window As Integer) As EV2300_ErrorCode
        '// Follows the procedure defined in TI SLUA379B
        '// There are some "magic numbers" with no explanation
        '
        '// bqEVSW reports the Board Offset value in uV. This alorithm calculates the Board Offset value as an INT16
        '// The documentation does not define how to convert between the INT16 and uV.
        '//
        '// Device under test must be powered from the Cell side, which
        '// allows the device current to flow through the sense resistor.
        '// Insure no other current is flowing through the sense resistor.
        '//
        '// I left my debug statements because there is precious little documentation. This may help
        '// P Liberatore    02Apr2012
        '//
        '// This version uses the LI method below. Then adds a final bounds check to be sure the final value falls in the center to the "Zero Range".
        '// This method is much slower than the other and does not seem to be necssary.

        Window = Math.Abs(Window)
        CalibrateBoardOffset_LinearApprox_withCentering = EV2300_ErrorCode.VB_NO_ERROR
        Dim TStep As Integer = 1

        Dim yData(32) As Byte

        '// READ EXTERNAL OFFSET CURRENT
        Dim PresVal As Short
        Dim HiVal, LoVal As Short
        Dim PresCurr, HiCurr, LoCurr As Short
        'Dim ValDelta As Short = 200
        Dim ThisCurr As Short
        Dim InterpertedValue As Short
        Dim CenteredValue As Short
        Dim sVal As String
        Do
            Select Case TStep
                Case 1
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.ReadEEPROM_Int16(104, 16, PresVal)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                    PresCurr = ThisCurr
                    AddStatusMessage("Present Value: " & PresVal.ToString, 3)
                    AddStatusMessage("Present Current: " & PresCurr.ToString & "mA", 3)
                Case 2
                    HiVal = PresVal + Window
                    Dim Tmp As UShort = Utility.ShortToUShort(HiVal)
                    sVal = Hex(HiVal)
                    sVal = Hex(Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                    Utility.Delay(4000)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                    HiCurr = ThisCurr
                    AddStatusMessage("High Value: " & HiVal.ToString, 3)
                    AddStatusMessage("High Current: " & HiCurr.ToString & "mA", 3)
                Case 3
                    LoVal = PresVal - Window
                    Dim Tmp As UShort = Utility.ShortToUShort(LoVal)
                    sVal = Hex(LoVal)
                    sVal = Hex(Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                    Utility.Delay(4000)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                    LoCurr = ThisCurr
                    AddStatusMessage("Low Value: " & LoVal.ToString, 3)
                    AddStatusMessage("Low Current: " & LoCurr.ToString & "mA", 3)
                Case 4
                    'Interpolate the correct value
                    Dim ThisAvgCurr As Short
                    InterpertedValue = (HiVal - LoVal) / (HiCurr - LoCurr) * (0 - LoCurr) + LoVal
                    Dim Tmp As UShort = Utility.ShortToUShort(InterpertedValue)
                    sVal = Hex(InterpertedValue)
                    sVal = Hex(Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                    Utility.Delay(4000)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.AverageCurrent, ThisAvgCurr)
                    AddStatusMessage("Corrected Value: " & InterpertedValue.ToString, 3)
                    AddStatusMessage("Corrected Current: " & ThisCurr.ToString & "mA", 3)
                    AddStatusMessage("Average Current: " & ThisAvgCurr.ToString & "mA", 3)
                Case 5
                    AddStatusMessage("Centering up the value", 1)
                    AddStatusMessage("Finding high side of zero range", 2)
                    Dim HighSideValue As Short
                    Dim i As Integer = 1
                    Dim Tmp As UShort
                    Do
                        HighSideValue = InterpertedValue + i
                        Tmp = Utility.ShortToUShort(HighSideValue)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                        Utility.Delay(3000)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        'CalibrateBoardOffset_Phil2 = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        AddStatusMessage("HighSideValue=" & HighSideValue.ToString, 3)
                        i += 1
                    Loop Until ThisCurr <> 0 Or CalibrateBoardOffset_LinearApprox_withCentering <> EV2300_ErrorCode.VB_NO_ERROR
                    AddStatusMessage("HighSideValue=" & HighSideValue.ToString, 2)

                    AddStatusMessage("Finding low side of zero range", 2)
                    Dim LowSideValue As Short
                    i = 1
                    Do
                        LowSideValue = InterpertedValue - i
                        Tmp = Utility.ShortToUShort(LowSideValue)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                        Utility.Delay(3000)
                        CalibrateBoardOffset_LinearApprox_withCentering = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        AddStatusMessage("LowSideValue=" & LowSideValue.ToString, 3)
                        i += 1
                    Loop Until ThisCurr <> 0 Or CalibrateBoardOffset_LinearApprox_withCentering <> EV2300_ErrorCode.VB_NO_ERROR
                    AddStatusMessage("LowSideValue=" & LowSideValue.ToString, 2)
                    CenteredValue = (HighSideValue + LowSideValue) / 2
                    AddStatusMessage("Centered Value is now: " & CenteredValue.ToString, 2)

                    Tmp = Utility.ShortToUShort(CenteredValue)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                    CalibrateBoardOffset_LinearApprox_withCentering = Me.ManufacturerAccessOperation(&H41, 0)
                    Utility.Delay(4000)

            End Select
            TStep += 1
        Loop While CalibrateBoardOffset_LinearApprox_withCentering = EV2300_ErrorCode.VB_NO_ERROR And TStep <= 10
    End Function
    Function CalibrateBoardOffset_LinearApprox(ByVal Window As Integer) As EV2300_ErrorCode
        '// Follows the procedure defined in TI SLUA379B
        '// There are some "magic numbers" with no explanation
        '
        '// bqEVSW reports the Board Offset value in uV. This alorithm calculates the Board Offset value as an INT16
        '// The documentation does not define how to convert between the INT16 and uV.
        '//
        '// Device under test must be powered from the Cell side, which
        '// allows the device current to flow through the sense resistor.
        '// Insure no other current is flowing through the sense resistor.
        '//
        '// I left my debug statements because there is precious little documentation. This may help
        '// P Liberatore    02Apr2012
        Window = Math.Abs(Window)
        CalibrateBoardOffset_LinearApprox = EV2300_ErrorCode.VB_NO_ERROR
        Dim TStep As Integer = 0

        Dim yData(32) As Byte

        '// READ EXTERNAL OFFSET CURRENT
        Dim PresVal As Short
        Dim HiVal, LoVal As Short
        Dim PresCurr, HiCurr, LoCurr As Short
        'Dim ValDelta As Short = 200
        Dim ThisCurr As Short
        Dim CorrectValue As Short
        Dim sVal As String
        Do
            Select Case TStep
                Case 0
                    Try
                        'Dim IsSealed As Boolean
                        'CalibrateBoardOffset_LinearApprox = PackIsSealed(IsSealed)
                        'If IsSealed Then
                        '    'Unseal()
                        '    Utility.Delay(500)
                        'End If

                    Catch ex As Exception
                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try
                Case 1
                    Try
                        CalibrateBoardOffset_LinearApprox = Me.ReadEEPROM_Int16(104, 16, PresVal)
                    Catch ex As Exception
                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try
                Case 2
                    Try

                        CalibrateBoardOffset_LinearApprox = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        PresCurr = ThisCurr
                        AddStatusMessage("Present Value: " & PresVal.ToString, 3)
                        AddStatusMessage("Present Current: " & PresCurr.ToString & "mA", 3)
                    Catch ex As Exception
                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try

                Case 3
                    Try
                        HiVal = PresVal + Window
                        Dim Tmp As UShort = Utility.ShortToUShort(HiVal)
                        sVal = Hex(HiVal)
                        sVal = Hex(Tmp)
                        CalibrateBoardOffset_LinearApprox = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                        'CalibrateBoardOffset_LinearApprox = Me.ManufacturerAccessOperation(&H41, 0)
                        'Unseal()
                        Utility.Delay(4000)
                        CalibrateBoardOffset_LinearApprox = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        HiCurr = ThisCurr
                        AddStatusMessage("High Value: " & HiVal.ToString, 3)
                        AddStatusMessage("High Current: " & HiCurr.ToString & "mA", 3)
                    Catch ex As Exception
                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try

                Case 4
                    Try
                        LoVal = PresVal - Window
                        Dim Tmp As UShort = Utility.ShortToUShort(LoVal)
                        sVal = Hex(LoVal)
                        sVal = Hex(Tmp)
                        CalibrateBoardOffset_LinearApprox = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                        'CalibrateBoardOffset_LinearApprox = Me.ManufacturerAccessOperation(&H41, 0)
                        'Unseal()
                        Utility.Delay(4000)
                        CalibrateBoardOffset_LinearApprox = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        LoCurr = ThisCurr
                        AddStatusMessage("Low Value: " & LoVal.ToString, 3)
                        AddStatusMessage("Low Current: " & LoCurr.ToString & "mA", 3)
                    Catch ex As Exception
                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try

                Case 5
                    Try
                        Dim ThisAvgCurr As Short
                        CorrectValue = (HiVal - LoVal) / (HiCurr - LoCurr) * (0 - LoCurr) + LoVal
                        Dim Tmp As UShort = Utility.ShortToUShort(CorrectValue)
                        sVal = Hex(CorrectValue)
                        sVal = Hex(Tmp)
                        CalibrateBoardOffset_LinearApprox = Me.WriteEEPROM_UInt16(104, 16, Tmp)
                        'CalibrateBoardOffset_LinearApprox = Me.ManufacturerAccessOperation(&H41, 0)
                        'Unseal()
                        Utility.Delay(4000)
                        CalibrateBoardOffset_LinearApprox = Me.Read_SMBus_Word_en(enSMBRegister_z80.Current, ThisCurr)
                        CalibrateBoardOffset_LinearApprox = Me.Read_SMBus_Word_en(enSMBRegister_z80.AverageCurrent, ThisAvgCurr)
                        AddStatusMessage("Corrected Value: " & CorrectValue.ToString, 3)
                        AddStatusMessage("Corrected Current: " & ThisCurr.ToString & "mA", 3)
                        AddStatusMessage("Average Current: " & ThisAvgCurr.ToString & "mA", 3)
                    Catch ex As Exception

                        Return EV2300_ErrorCode.BoardOffsetCal_UnexpectedError
                    End Try
                    'Interpolate the correct value

            End Select
            TStep += 1
        Loop While CalibrateBoardOffset_LinearApprox = EV2300_ErrorCode.VB_NO_ERROR And TStep <= 10
    End Function
    Function CalibrateBoardOffset(ByVal fSenseMilliohms As Single) As EV2300_ErrorCode
        '// Follows the procedure defined in TI SLUA379B
        '// There are some "magic numbers" with no explanation
        '
        '// bqEVSW reports the Board Offset value in uV. This alorithm calculates the Board Offset value as an INT16
        '// The documentation does not define how to convert between the INT16 and uV.
        '//
        '// Device under test must be powered from the Cell side, which
        '// allows the device current to flow through the sense resistor.
        '// Insure no other current is flowing through the sense resistor.
        '//
        '// I left my debug statements because there is precious little documentation. This may help
        '// P Liberatore    02Apr2012
        CalibrateBoardOffset = EV2300_ErrorCode.VB_NO_ERROR
        Dim TStep As Integer
        Dim lValue As Integer
        Dim I As Integer
        Dim iExternalOffset As Short
        Dim iInternalOffset As Short
        Dim iBoardOffset As Short
        Dim yData(32) As Byte
        Dim ByToWrite As UShort
        Dim Str As String
        '// READ EXTERNAL OFFSET CURRENT
        Do
            Select Case TStep
                Case 1
                    CalibrateBoardOffset = Write_SMBus_Word(&H40, &H8042S) '//Set address of coulomb counter
                    Call Utility.DelaySec(0.4) '// Extra settling time to clear the decimation filter
                    For I = 1 To 4
                        Call Utility.DelaySec(0.3) '// take 4 samples at 300 ms intervals
                        'lError = ReadSMBusUnsignedInteger(&H42, lValue) '// Peek Coulomb Counter
                        'CalibrateBoardOffset = Read_SMBus_UnsignedWord(&H42, lValue)
                        CalibrateBoardOffset = Read_SMBus_Word(&H42, lValue)
                        'lError = InstruControl.Ev2300.Read_SMBus_Word(&H42, lValue)
                        iExternalOffset = iExternalOffset + lValue
                    Next
                    AddStatusMessage("CalibrateBoardOffset: iExternalOffset=" & iExternalOffset.ToString, 2)
                    '// READ INTERNAL OFFSET CURRENT
                    CalibrateBoardOffset = Write_SMBus_Word(&H40, &H8040S) '//Set address of coulomb counter config register
                    CalibrateBoardOffset = Write_SMBus_Word(&H41, &H43S) '//Change configuration to internal mode
                    CalibrateBoardOffset = Write_SMBus_Word(&H40, &H8042S) '//Set address of Coulomb Counter
                    Utility.DelaySec(0.4) '// Extra settling time to clear the decimation filter
                    For I = 1 To 4
                        Utility.DelaySec(0.3)
                        'CalibrateBoardOffset = Read_SMBus_UnsignedWord(&H42, lValue) '// Read Coulomb Count
                        CalibrateBoardOffset = Read_SMBus_Word(&H42, lValue)
                        iInternalOffset = iInternalOffset + lValue
                    Next
                    AddStatusMessage("CalibrateBoardOffset iInternalOffset=" & iInternalOffset.ToString, 2)
                    CalibrateBoardOffset = Write_SMBus_Word(&H40, &H8040S) '//Set address of coulomb counter config register

                    ''
                    CalibrateBoardOffset = Write_SMBus_Word(&H41, &H2) '//Return configuration to external mode
                Case 2
                    '// CALCULATE BOARD OFFSET
                    iBoardOffset = Int(16 * (iExternalOffset - iInternalOffset) + (3745 * fSenseMilliohms / 1000))
                    Str = Hex(iBoardOffset)
                    AddStatusMessage("CalibrateBoardOffset: sBoardOffset = " & iBoardOffset.ToString & "  " & Str & "Hex16", 2)
                    'Dim iBoardOffset As Integer
                    'If sBoardOffset < 0 Then
                    '    iBoardOffset = 65536 + sBoardOffset '// fix negative case
                    '    sBoardOffset = (iBoardOffset And sBoardOffset)
                    'End If

                    '// WRITE BOARD OFFSET TO DATA FLASH. FROM DATA MANUAL, SUBCLASS=104, OFSET=16
                    'lError = InstruControl.Ev2300.Write_SMBus_Word(&H77, 104) '//Set subclass to 104
                    'lError = ReadSMBusByteArray(&H78, yData(), iLen) '// Read the page
                    Dim Dat As Short
                    CalibrateBoardOffset = ReadEEPROM_Int16(104, 16, Dat, yData)
                    Dim DaByte As Short = iBoardOffset
                    DaByte = DaByte And &HFF00S
                    DaByte = DaByte / 256
                    yData(16) = DaByte And &HFFS
                    'yData(16) = (sBoardOffset And &HFF00S) / 256 '// Modify MS byte
                    DaByte = iBoardOffset
                    DaByte = DaByte And &HFFS
                    yData(17) = DaByte
                    'yData(17) = sBoardOffset And &HFFS '// Modify LS byte
                    'lError = WriteSMBusByteArray(&H78, yData(), iLen) '//Write page back to flash
                    ByToWrite = yData(16)
                    ByToWrite = ByToWrite * 256S
                    ByToWrite = ByToWrite Or yData(17)

                    CalibrateBoardOffset = WriteEEPROM_UInt16(104, 16, ByToWrite)

                    Utility.DelaySec(0.5) '// Insure flash write is finished

                Case 3
                    'Verify the DF value is correct
                    Dim TheBlock() As Byte
                    AddStatusMessage("Verify Write", 2)
                    Dim CheckVal As Short
                    CalibrateBoardOffset = ReadEEPROM_Int16(104, 16, CheckVal, TheBlock)
                    'Make sure these are both the same value
                    Dim uCheckVal As UShort = Utility.ShortToUShort(CheckVal)
                    If uCheckVal = ByToWrite Then
                        AddStatusMessage("Data Flash Write (Subclass 104, Offset 16) Confirmed", 2)
                    Else
                        AddStatusMessage("Data Flash Write (Subclass 104, Offset 16) Error", 2)
                        AddStatusMessage("Data Written: " & Hex(ByToWrite).PadLeft(4, "0"), 2)
                        AddStatusMessage("Byte Read Back: " & Hex(CheckVal).PadLeft(4, "0"), 2)
                        CalibrateBoardOffset = EV2300_ErrorCode.NEX_ByteWrite_CanNotConfirm
                        AddStatusMessage(CalibrateBoardOffset.ToString, 2)
                    End If
            End Select
            TStep += 1
        Loop While CalibrateBoardOffset = EV2300_ErrorCode.VB_NO_ERROR And TStep <= 10
    End Function
    '''  END OF COPY
    Public Function CalibrateCurrent(ByVal mAref As Short) As Integer
        Dim Detail As struCalDetail
        With Detail
            .bDoCCOffset = False
            .bDoPackCurrent = True
            .bDoTemperature = False
            .bDoVoltage = False
            .iPackCurrent_mA = mAref
        End With
        CalibrateCurrent = DoTheCalibration(Detail, 10000)
    End Function
    Public Function CalibrateCCoffset() As Integer
        Dim Detail As struCalDetail
        With Detail
            .bDoCCOffset = True
            .bDoPackCurrent = False
            .bDoTemperature = False
            .bDoVoltage = False
        End With
        CalibrateCCoffset = DoTheCalibration(Detail, 10000)
    End Function

    Public Function CalibrateVoltsTemp(ByVal mVref As Short, ByVal TempC As Single) As Integer
        Dim Detail As struCalDetail
        With Detail
            .bDoCCOffset = False
            .bDoPackCurrent = False
            .bDoTemperature = True
            .bDoVoltage = True
            .fTemperatureC = TempC
            .iVoltage_mV = mVref
        End With
        CalibrateVoltsTemp = DoTheCalibration(Detail, 10000)

    End Function
    Public Function CalibrateVolts(ByVal mVref As Short, ByVal CellCount As Short) As Integer
        Dim Detail As struCalDetail
        With Detail
            .bDoCCOffset = False
            .bDoPackCurrent = False
            .bDoTemperature = False
            .bDoVoltage = True
            '.fTemperatureC = TempC
            .iVoltage_mV = mVref
            .iCellCountForVoltage = CellCount
        End With
        CalibrateVolts = DoTheCalibration(Detail, 10000)
    End Function
    Public Function CalibrateTemp(ByVal DegC As Single) As Integer
        Dim Detail As struCalDetail
        With Detail
            .bDoCCOffset = False
            .bDoPackCurrent = False
            .bDoTemperature = True
            .bDoVoltage = False
            .fTemperatureC = DegC
            .iVoltage_mV = 0
        End With
        CalibrateTemp = DoTheCalibration(Detail, 10000) 'Internal, Ext1 and Ext2 are handled by glo variables
    End Function
    Private Function DoTheCalibration(ByVal params As struCalDetail, ByVal TimeOutms As Integer) As EV2300_ErrorCode
        '// iVoltage is in millivolts
        '// iCurrent is in milliamps (normally negative, such as -2000)
        '// iTemperature is in Kelvin/10 units, so the argument is: 10 * (Celsius + 273.15)
        Dim lError As EV2300_ErrorCode
        Dim bDoingCal As Boolean

        'Check arguments
        If params.ErrorString <> OK Then
            'Maybe make better later
            Return -1
        End If

        '// GO TO CALIB MODE
        lError = Bq80xRW1.WriteSMBusWord(&H0, &H40, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H0, &H40, DEFAULT_TARGET_ADDR, lError)
        '// WRITE THE NUMBER OF CELLS
        lError = Bq80xRW1.WriteSMBusWord(&H63, glo.Calibration_VoltageCellCount, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H63, glo.Calibration_VoltageCellCount, DEFAULT_TARGET_ADDR, lError)
        '// WRITE THE ACTUAL VOLTAGE, CURRENT & TEMPERATURE
        lError = Bq80xRW1.WriteSMBusWord(&H60, params.iPackCurrent_mA, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H60, params.iPackCurrent_mA, DEFAULT_TARGET_ADDR, lError)
        lError = Bq80xRW1.WriteSMBusWord(&H61, params.iVoltage_mV, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H61, params.iVoltage_mV, DEFAULT_TARGET_ADDR, lError)
        lError = Bq80xRW1.WriteSMBusWord(&H62, params.iTempFormat, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H61, params.iTempFormat, DEFAULT_TARGET_ADDR, lError)
        '// START CALIBRATION
        '// Useful cal lo byte &HD5 - External temperature sensor 1
        '// &HF5 - External temperature sensor 1 and 2
        '// &HCD - Internal temperature sensor
        'Dim Ctrl As Short = &HC090S

        lError = Bq80xRW1.WriteSMBusWord(&H51, params.CalibrControlArg, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommWriteComplete(&H51, params.CalibrControlArg, DEFAULT_TARGET_ADDR, lError)
        '// POLL STATUS
        Dim TheWord As Short
        bDoingCal = True
        Dim SW As New Stopwatch
        SW.Start()
        Do While bDoingCal And SW.ElapsedMilliseconds <= TimeOutms
            'lError = ReadSMBusWord(&H52, yMS, yLS)
            lError = Bq80xRW1.ReadSMBusWord(&H52, TheWord, DEFAULT_TARGET_ADDR)
            RaiseEvent DataCommReadComplete(&H52, TheWord, DEFAULT_TARGET_ADDR, lError)
            TheWord = TheWord And &HC0S
            bDoingCal = TheWord <> 0
            'bDoingCal = (yMS And &H3F) Or yLS
            Utility.DelaySec(0.2) '// check every 200 millisecond
        Loop
        If bDoingCal Then
            'Must have timed out to get here. Something is wrong, I guess

        End If
        '// TRANSFER RESULTS TO DATAFLASH
        'lError = WriteSMBusCommand(&H72)
        lError = Bq80xRW1.WriteSMBusCmd(&H72, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommCommandComplete(&H72, lError)
        Utility.DelaySec(0.3) '// Insure write process is finished
        '// EXIT CALIB MODE
        lError = Bq80xRW1.WriteSMBusCmd(&H73, DEFAULT_TARGET_ADDR)
        RaiseEvent DataCommCommandComplete(&H73, lError)
    End Function

    'UPGRADE_NOTE: Class_Initialize was upgraded to Class_Initialize_Renamed. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
    Private Sub Class_Initialize_Renamed()
        'Initializes the Modules
        modComm.Initialize()
        '    modCommFunc.Initialize
        '   modCalBoard.Initialize  ' Initialize the Cal board - Resets cal board, uses modComm
        modDelays.Initialize()
        'modShared.Initialize ' This gets called in Main(), so do not call here
        'modCalibrateZ80.Initialize
        'modCustom.Initialize

        '    modShared.InitBQSoftware (False)
    End Sub
    Public Sub New()
        MyBase.New()
        Class_Initialize_Renamed()
    End Sub
    'Public Property Get MainFormVisible() As Boolean
    '    MainFormVisible = frmMainS.Visible
    'End Property
    'Public Property Let MainFormVisible(bNew As Boolean)
    '    If bNew Then frmMainS.Show Else frmMainS.Hide
    'End Property
    Public Sub CloseDevice()
        modComm.CloseDevice()
    End Sub
    Public Function OpenFirstFreeDevice() As Boolean
        OpenFirstFreeDevice = modComm.OpenFirstFreeDevice
    End Function

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub
End Class

Module modDelays
    '*****************************************************************************
    ' Author : Shirish Kavoor
    ' Contact Information: s-kavoor@ti.com 1-512-2630588 Ext 22
    '
    ' Copyright: Shirish Kavoor, Texas Instruments 2005, Austin Design Center
    '
    ' Terms and conditions:
    ' Use and distribution of this code is subject to the terms and conditions
    ' of the license agreement.
    ' If you do not have a copy of the license agreement, then you must request
    ' a copy of the license agreement.
    '
    ' Filename: modDelays.bas
    ' Date Created: September 06, 2005
    ' Last Modified: January 26, 2005
    '
    ' Description:
    ' This module holds variables that specify the delays used in the tester.
    ' Delay values are stored in Delay.ini
    ' All values are in millseconds

    '*****************************************************************************


    Public Declare Function GetPrivateProfileInt Lib "kernel32" Alias "GetPrivateProfileIntA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal nDefault As Integer, ByVal lpFileName As String) As Integer

    Public m_nTIManufAccessCmd As Short

    'Calibration board hardware related
    Public m_nCalBoardVoltSettlingTime As Integer 'Settling time for Voltage on Cal board after being turned on
    Public m_nCalBoardCurrSettlingTime As Integer 'Settling time for Current on Cal board after being turned on
    Public m_nLoadVISettlingTime As Integer 'Settling time for Voltage & Current in Load after FETs are turned on
    Public m_nUSBResponseTime As Integer ' Time taken for an error packet to be returned to program - Used for clearing errors especially from Cal board

    'Programming related, all in milliseconds
    Public m_nMassEraseDelay As Integer
    Public m_nEraseRowDelay As Integer
    Public m_nGGProgRowDelay As Integer
    Public m_nSBSWrDelay As Integer
    Public m_nDFProgRowDelay As Integer
    Public m_nExecuteFWDelay As Integer
    Public m_nCalWrDelay As Integer
    Public m_nCalWrSignalsDelay As Integer

    Public m_nTIMAC As Short
    Public m_nDFImageSz As Integer
    Public m_nRetROMCmd As Short
    Public m_nRetROMWord As Short

    'Public m_nGGModeCommProtocol As Integer '0=SMB, 1=bq27350 style I2C

    'Tester only entries
    Public m_nDateClassID As Short
    Public m_nDateClassOffset As Short
    Public m_nMfgDataClassID As Short
    Public m_nMfgDataPackLotCodeOffset As Short
    Public m_nPkLotCodeValid As Short

    Public m_nPlatform As Integer

    Public m_nDFBaseAddr As Short
    Public m_nDFMaxSize As Short
    Public m_nDFProgRowSize As Short
    Public m_nDFEraseRowSize As Short
    Public m_nDFChkSumBlkSize As Short

    Public m_nIntTempOff_DFOffset As Short
    Public m_nExt1TempOff_DFOffset As Short
    Public m_nExt2TempOff_DFOffset As Short

    Const conDelayIniFile As String = "C:\EV2300_ConfigDly.ini"
    Const conDelaySection As String = "Delay"
    Const conCalBoardVoltSettlingTime As String = "CB_V_SETTLE"
    Const conCalBoardCurrSettlingTime As String = "CB_I_SETTLE"
    Const conLoadVISettlingTime As String = "LOAD_VI_SETTLE"
    Const conCommResponseTime As String = "USB_RESP_TIME"
    Const conExecFWDelay As String = "GG_FWEXEC"
    Const conCalWrDelay As String = "CalWr"
    Const conCalWrSigDelay As String = "CalWrSig"
    Const conGGProgBlockDelay As String = "GGModeDFDelay"
    Const conSBSWrDelay As String = "SBSWrDelay"
    Const conPlatform As String = "Platform"
    Const conMassEraseDelay As String = "DF_MASSERASE"
    Const conEraseRowDelay As String = "DF_ERASEROW"
    Const conProgRowDelay As String = "DF_PROGROW"
    Const conTIManufAccCmd As String = "TIMAC"
    Const conDFImageSz As String = "DF_IMAGE_SZ"
    Const conRetROMCmd As String = "RetROMCmd"
    Const conRetROMWord As String = "RetROMWd"

    'Const conGGModeCommProtocol = "GGComm"

    Const conDateClsID As String = "DateClsID"
    Const conDateOffset As String = "DateOffset"
    Const conMfgDataClsID As String = "MfDataClsID"
    Const conPkLotOffset As String = "PkLotOffset"
    Const conPkLotCodeValid As String = "PkLotValid"

    Const conDFBaseAddr As String = "DF_BASE_ADDR"
    Const conDFMaxSize As String = "DF_MAX_SZ"
    Const conDFProgRowSize As String = "DF_PROGROW_SZ"
    Const conDFEraseRowSize As String = "DF_ERASEROW_SZ"
    Const conDFChkSumBlkSize As String = "DF_CHKSUM_SZ"

    Const conIntTempOff_DFOffset As String = "ITOff_DFOff"
    Const conExt1TempOff_DFOffset As String = "ET1Off_DFOff"
    Const conExt2TempOff_DFOffset As String = "ET2Off_DFOff"


    Function Initialize(Optional ByRef sDevVer As String = "800.1.02") As Boolean
        'Dim sReturn As String * MAX_STRING_SIZE
        'Dim nLen As Long
        Initialize = False
        'Read GG/platform independent values
        m_nCalBoardVoltSettlingTime = GetPrivateProfileInt(conDelaySection, conCalBoardVoltSettlingTime, 1000, conDelayIniFile)
        m_nCalBoardCurrSettlingTime = GetPrivateProfileInt(conDelaySection, conCalBoardCurrSettlingTime, 1000, conDelayIniFile)
        m_nLoadVISettlingTime = GetPrivateProfileInt(conDelaySection, conLoadVISettlingTime, 200, conDelayIniFile)

        m_nUSBResponseTime = GetPrivateProfileInt(conDelaySection, conCommResponseTime, 1, conDelayIniFile) 'Default to 1, Use the [CalBrd] Use entry when cal board not present

        Dim sDevCfgSection As String
        Dim sVerCfgSection As String
        Dim sPlatformSection As String
        Dim nTmp As Integer
        Initialize = False
        If Not GetConfigSection(sDevVer, sDevCfgSection, sVerCfgSection) Then
            Exit Function 'Will leave all values uninitialized resulting in fails
        End If
        'Read GG specific values and override if different per version entry in ini file exists
        m_nTIMAC = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conTIManufAccCmd, 0, conDelayIniFile)
        m_nExecuteFWDelay = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conExecFWDelay, 200, conDelayIniFile)
        m_nCalWrDelay = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conCalWrDelay, 30, conDelayIniFile)
        m_nCalWrSignalsDelay = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conCalWrSigDelay, 60, conDelayIniFile)
        m_nDFImageSz = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conDFImageSz, &H700, conDelayIniFile)
        m_nRetROMCmd = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conRetROMCmd, 0, conDelayIniFile)
        m_nRetROMWord = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conRetROMWord, &HF00, conDelayIniFile)

        'm_nGGModeCommProtocol = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conGGModeCommProtocol, 0, conDelayIniFile)

        m_nDateClassID = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conDateClsID, 48, conDelayIniFile)
        m_nDateClassOffset = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conDateOffset, 10, conDelayIniFile)
        m_nMfgDataClassID = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conMfgDataClsID, 56, conDelayIniFile)
        m_nMfgDataPackLotCodeOffset = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conPkLotOffset, 0, conDelayIniFile)
        m_nPkLotCodeValid = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conPkLotCodeValid, 1, conDelayIniFile)

        'GG Platform
        nTmp = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conPlatform, &H8024, conDelayIniFile)
        m_nPlatform = nTmp
        sPlatformSection = "P" & Replace(VB6.Format(Hex(nTmp), "@@@@"), " ", "0")
        'Read Platform specific values
        m_nEraseRowDelay = GetPrivateProfileInt(sPlatformSection, conEraseRowDelay, 10, conDelayIniFile)
        m_nMassEraseDelay = GetPrivateProfileInt(sPlatformSection, conMassEraseDelay, 200, conDelayIniFile)
        m_nDFProgRowDelay = GetPrivateProfileInt(sPlatformSection, conProgRowDelay, 2, conDelayIniFile)

        m_nDFBaseAddr = GetPrivateProfileInt(sPlatformSection, conDFBaseAddr, &H4000, conDelayIniFile)
        m_nDFMaxSize = GetPrivateProfileInt(sPlatformSection, conDFMaxSize, &H800, conDelayIniFile)
        m_nDFProgRowSize = GetPrivateProfileInt(sPlatformSection, conDFProgRowSize, 32, conDelayIniFile)
        m_nDFEraseRowSize = GetPrivateProfileInt(sPlatformSection, conDFEraseRowSize, 32, conDelayIniFile)
        m_nDFChkSumBlkSize = GetPrivateProfileInt(sPlatformSection, conDFChkSumBlkSize, &H7E0, conDelayIniFile)
        'Calculated values
        m_nGGProgRowDelay = (m_nEraseRowDelay + (m_nDFEraseRowSize \ m_nDFProgRowSize) * m_nDFProgRowDelay) * 6 'Each write results in copying the row, writing semaphore row, writing and Double because some classes span 2 rows
        m_nSBSWrDelay = m_nGGProgRowDelay / 2

        'Provide an override facility - GG config section
        m_nGGProgRowDelay = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conGGProgBlockDelay, m_nGGProgRowDelay, conDelayIniFile)
        m_nSBSWrDelay = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conSBSWrDelay, m_nSBSWrDelay, conDelayIniFile)

        'Post calibration checks constants
        m_nIntTempOff_DFOffset = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conIntTempOff_DFOffset, 17, conDelayIniFile)
        m_nExt1TempOff_DFOffset = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conExt1TempOff_DFOffset, 18, conDelayIniFile)
        m_nExt2TempOff_DFOffset = ReadGGIniWithOverride(sDevCfgSection, sVerCfgSection, conExt2TempOff_DFOffset, 19, conDelayIniFile)

        'Temporary adjustments 'To do - remove g_nTIManufAccessCmd definition from project and replace with m_ntimac
        m_nTIManufAccessCmd = m_nTIMAC
        Initialize = True
    End Function

    Function ReadGGIniWithOverride(ByRef sBaseSection As String, ByRef sOverrideSection As String, ByRef sKeyname As String, ByRef nDefaultValue As Integer, ByRef sFilename As String) As Integer
        ReadGGIniWithOverride = GetPrivateProfileInt(sBaseSection, sKeyname, nDefaultValue, sFilename)
        ReadGGIniWithOverride = GetPrivateProfileInt(sOverrideSection, sKeyname, ReadGGIniWithOverride, sFilename)
    End Function



    Public Function GetConfigSection(ByRef sDevVer As String, ByRef sDeviceConfigSection As String, ByRef sVersionConfigSection As String) As Boolean
        Dim nIdx As Short
        GetConfigSection = False
        nIdx = InStr(1, sDevVer, ".")
        If nIdx <= 0 Then Exit Function
        sDeviceConfigSection = "D" & Left(sDevVer, nIdx - 1)
        sVersionConfigSection = Replace(sDevVer, ".", "_")
        GetConfigSection = True
    End Function
End Module
Module modComm
    '*****************************************************************************
    ' Author : Shirish Kavoor
    ' Contact Information: s-kavoor@ti.com 1-512-2630588 Ext 22
    '
    ' Copyright: Shirish Kavoor, Texas Instruments 2005, Austin Design Center
    '
    ' Terms and conditions:
    ' Use and distribution of this code is subject to the terms and conditions
    ' of the license agreement.
    ' If you do not have a copy of the license agreement, then you must request
    ' a copy of the license agreement.
    '
    ' Filename: modComm.bas
    ' Date Created: April 26, 2005
    ' Last Modified: June 12, 2005
    '
    ' Description:
    ' This module contains communication related functions. It calls functions in
    ' the bq80xRW.ocx
    ' It is recommended that this file be treatedas read only.
    ' Users may add their custom communication functions in modCommFunc.bas

    '*****************************************************************************


    'Constants
    Public Const DEFAULT_TARGET_ADDR As Integer = &H17
    'Public WithEvents Bq80xRW1 As AxBQ80XRWLib.AxBq80xRW
    Public WithEvents Bq80xRW1 As AxBQ80XRWLib.AxBq80xRW

    '-----------------------------------------------------------------------------
    ' Function: OpenFirstFreeDevice()
    ' Opens the First FREE(Unopened) device that the system can find

    Public Function OpenFirstFreeDevice() As Boolean
        Dim BrdName As String
        Dim nBrdsFound As Integer
        Call Bq80xRW1.GetFreeBoards(1, nBrdsFound, BrdName)
        Dim EndPos As Object
        If nBrdsFound >= 1 Then 'At least 1 board found
            EndPos = InStr(1, BrdName, ",", CompareMethod.Text) 'Should always have a "," at the end
            If Not IsDBNull(EndPos) And EndPos <> 0 Then
                BrdName = Left(BrdName, EndPos - 1)
            End If
            If Not Bq80xRW1.OpenDevice(BrdName) Then 'return of 0 = success
                OpenFirstFreeDevice = True 'Success
                Exit Function
            End If
        End If
        OpenFirstFreeDevice = False 'Failure
    End Function

    '-----------------------------------------------------------------------------
    ' Function: CloseDevice()
    ' Closes the Device that is currently open

    Public Sub CloseDevice()
        Bq80xRW1.CloseDevice()
    End Sub

    '-----------------------------------------------------------------------------
    ' Function: WriteSMBusWord()
    ' Writes a Word of data on SMBus

    Public Function WriteSMBusWord_(ByVal ySubCommand As Byte, ByRef nWord As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        lError = Bq80xRW1.WriteSMBusWord(ySubCommand, nWord, nTargetAddr) 'Non-Zero if error
        If lError = 0 Then
            lError = CheckForError()
        End If
        WriteSMBusWord_ = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function: WriteSMBusWord()
    ' Writes a Word of data on SMBus as 2 bytes

    Public Function WriteSMBusWord(ByVal ySubCommand As Byte, ByRef yMSData As Byte, ByRef yLSData As Byte, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        lError = 0

        Dim nWord As Short
        nWord = 0
        If yMSData > 127 Then
            nWord = &H8000S
            yMSData = yMSData - 128
        End If
        nWord = nWord + yMSData * 256 + yLSData

        lError = WriteSMBusWord_(ySubCommand, nWord, nTargetAddr) 'Non-Zero if error
        WriteSMBusWord = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function: WriteSMBusBlock()
    ' Writes a block of data on SMBus

    Public Function WriteSMBusBlock(ByVal nCommand As Short, ByRef DataArray() As Byte, ByRef iNumBytes As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        lError = Bq80xRW1.WriteSMBusBlock(nCommand, DataArray, iNumBytes, nTargetAddr) ' Returns non 0 if error
        '    If lError = 0 Then
        '      lError = CheckForError
        '    End If
        WriteSMBusBlock = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function: WriteSMBusCommand()
    ' Writes a SMBus Command

    Public Function WriteSMBusCommand(ByVal nCommand As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        lError = Bq80xRW1.WriteSMBusCmd(nCommand, nTargetAddr)
        If lError = 0 Then
            lError = CheckForError()
        End If
        WriteSMBusCommand = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function ReadSMBusWord_()
    ' Reads a word of data over SMBus

    Public Function ReadSMBusWord_(ByVal ySmbCommand As Byte, ByRef nData As Short, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        lError = Bq80xRW1.ReadSMBusWord(ySmbCommand, nData, nTargetAddr)
        ReadSMBusWord_ = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function ReadSMBusWord()
    ' Reads a word of data over SMBus as 2 bytes

    Public Function ReadSMBusWord(ByVal ySubCommand As Byte, ByRef yMSData As Byte, ByRef yLSData As Byte, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        Dim SMBCmd As Short
        Dim nWord As Short

        SMBCmd = ySubCommand
        lError = ReadSMBusWord_(SMBCmd, nWord, nTargetAddr)
        Dim NegSign As Boolean
        If lError = 0 Then ' Put returned Word into MS and LS byte
            NegSign = False
            lError = 0
            If nWord < 0 Then
                nWord = nWord + 32768
                NegSign = True
            End If
            yMSData = nWord \ 256
            yLSData = nWord - yMSData * 256
            If NegSign Then
                yMSData = yMSData + &H80
            End If
        End If
        ReadSMBusWord = lError
    End Function

    '-----------------------------------------------------------------------------
    ' Function ReadSMBusBlock_()
    ' Reads a block of data over SMBus

    Public Function ReadSMBusBlock_(ByVal ySubCommand As Byte, ByRef yResponse() As Byte, Optional ByRef nLen_ As Short = 0, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR) As EV2300_ErrorCode
        Dim lError As Integer
        Dim nLen As Short
        Dim nIdx As Short
        Dim V As Object
        'UPGRADE_WARNING: Couldn't resolve default property of object V. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
        V = VB6.CopyArray(yResponse)
        lError = Bq80xRW1.ReadSMBusBlock(ySubCommand, V, nLen, nTargetAddr)

        For nIdx = 0 To nLen 'Copy from variant to array
            'UPGRADE_WARNING: Couldn't resolve default property of object V(). Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6A50421D-15FE-4896-8A1B-2EC21E9037B2"'
            yResponse(nIdx) = V(nIdx)
        Next nIdx
        nLen_ = nLen
        ReadSMBusBlock_ = lError
    End Function


    '-----------------------------------------------------------------------------
    ' Function ReadSMBusBlock()
    ' Reads a block of data over SMBus and formats it as specified
    ' nReturnStrType 0=Hex data string, 1=Normal string

    Public Function ReadSMBusBlock(ByVal ySubCommand As Byte, ByRef sResponse As String, Optional ByRef nTargetAddr As Short = DEFAULT_TARGET_ADDR, Optional ByRef nReturnStrType As Short = 0) As EV2300_ErrorCode
        Dim lError As Integer
        Dim Data(128) As Byte
        Dim nLen As Short
        Dim Subcmd As Short
        Subcmd = ySubCommand
        'To call ReadSMBusBlock() we need a pointer to variant containing array of bytes
        'So assign an array of bytes to variant v and use v as argument to the call
        Dim V As Object
        V = VB6.CopyArray(Data)
        sResponse = ""
        lError = Bq80xRW1.ReadSMBusBlock(Subcmd, V, nLen, nTargetAddr)
        Dim X As Short
        Dim tmpStr As String
        If lError = 0 Then 'Stick return data into a string
            For X = 0 To nLen - 1
                tmpStr = Hex(V(X))
                If Len(tmpStr) < 2 Then
                    tmpStr = "0" & tmpStr
                End If
                If nReturnStrType = 1 Then sResponse = sResponse & Chr(V(X)) 'This will display actual string for mfg name
                If nReturnStrType = 0 Then sResponse = sResponse & tmpStr 'Hex string
            Next X
        End If
        ReadSMBusBlock = lError
    End Function

    '-----------------------------------------------------------------------------
    Public Function I2CPower(ByVal nData As Byte) As EV2300_ErrorCode
        Dim nDummy As Short
        I2CPower = Bq80xRW1.I2CReadWrite(BQ80XRWLib.I2COperation.vb_I2C_EE_POWER, nData, 0, nDummy)
    End Function

    Public Function I2CReadWrite(ByVal nOperation As BQ80XRWLib.I2COperation, ByVal nTargetAddr As Short, ByRef nWordAddr As Short, ByRef nData As Short) As EV2300_ErrorCode
        I2CReadWrite = Bq80xRW1.I2CReadWrite(nOperation, nTargetAddr, nWordAddr, nData)
    End Function

    Public Function I2CReadWord(ByRef nWordAddr As Short, ByRef nWord As Short, ByVal nTargetAddr As Short) As EV2300_ErrorCode
        Dim lError As Integer
        Dim DataBlock As Object
        Dim nBlockSize As Short
        nBlockSize = 2
        lError = Bq80xRW1.I2CReadBlock(nWordAddr, DataBlock, nBlockSize, nTargetAddr)
        If (lError = 0) Then
            If nBlockSize <> 2 Then I2CReadWord = 772 : Exit Function
            'Copy from variant to array
            nWord = CShort(DataBlock(0) And &H7F) * 256 + DataBlock(1)
            If DataBlock(0) And &H80 Then nWord = nWord Or &H8000
        End If
        If lError = 0 Then lError = CheckForError()
        I2CReadWord = lError
    End Function


    '-----------------------------------------------------------------------------
    ' Function: CheckForError()
    ' Returns an error is the previous function call communication failed.
    ' Normally used after writes because write functions do not wait for the
    ' communication to complete before returning success.
    ' Functions must wait for the time required for communication to complete
    ' before calling this function. The communication time is dependent on the
    ' PC hardware and free resources.

    Public Function CheckForError() As EV2300_ErrorCode
        CheckForError = Bq80xRW1.CheckForError
    End Function

    '-----------------------------------------------------------------------------
    Public Sub Delay(ByVal nTime_ms As Integer)
        Bq80xRW1.Delay((nTime_ms))
        'Delay = CheckForError()
    End Sub
    '-----------------------------------------------------------------------------
    Public Sub ClearAllErrors(ByRef nTime_ms As Integer)
        Do
            While (CheckForError() <> 0)
            End While
            DoDelayms(nTime_ms)
        Loop While (CheckForError() <> 0)
    End Sub
    '-----------------------------------------------------------------------------

    '-----------------------------------------------------------------------------
    ' The Initialize() procedure is called by the main program on startup

    Sub Initialize()
        Bq80xRW1 = frmTestMain.AxBq80xRW1
        'Bq80xRW1 = New BQ80XRWLib.Bq80xRW
        'If Not OpenFirstFreeDevice() Then MsgBox LoadResString(IDS_NO_EV2300)
    End Sub

    '-----------------------------------------------------------------------------
    ' The Terminate() procedure is called by the main program on Close

    Sub Terminate()
        CloseDevice()
        'UPGRADE_NOTE: Object Bq80xRW1 may not be destroyed until it is garbage collected. Click for more: 'ms-help://MS.VSCC.v90/dv_commoner/local/redirect.htm?keyword="6E35BFF6-CD74-4B09-9689-3E1A43DF8969"'
        Bq80xRW1 = Nothing
    End Sub

    '-----------------------------------------------------------------------------
End Module
Friend Module modCommFunc
    '*****************************************************************************
    ' Author : Shirish Kavoor
    ' Contact Information: s-kavoor@ti.com 1-512-2630588 Ext 22
    '
    ' Copyright: Shirish Kavoor, Texas Instruments 2005, Austin Design Center
    '
    ' Terms and conditions:
    ' Use and distribution of this code is subject to the terms and conditions
    ' of the license agreement.
    ' If you do not have a copy of the license agreement, then you must request
    ' a copy of the license agreement.
    '
    ' Filename: modCommFunc.bas
    ' Date Created: April 26, 2005
    ' Last Modified: April 26, 2005
    '
    ' Description:
    ' This module contains functions that communicate with the EV2300 but consist
    ' of more than 1 function call into bq80xRW.ocx

    '*****************************************************************************


    Const MFG_ACCESS_CMD As Integer = &H0
    Const MFG_ACCESS_DEV_WORD As Integer = &H1
    Const MFG_ACCESS_VER_WORD As Integer = &H2
    Const RETURN_TO_ROM_CMD As Integer = &H0
    Const RETURN_TO_ROM_WORD As Integer = &HF00
    Const READ_ROM_VER_CMD As Integer = &HD
    Const RUN_GG_CODE_CMD As Integer = &H8
    Const MFG_ACCESS_SEAL_WORD As Integer = &H20
    '-----------------------------------------------------------------------------
    ' Function: GetGGDeviceVersion()
    'Returns the Gas gauge version

    Public Function GetGGDeviceVersion(ByRef sDevVer As String, ByRef nMfgAccCmd As Short, Optional ByRef nDevWd As Short = MFG_ACCESS_DEV_WORD, Optional ByRef nVerWd As Short = MFG_ACCESS_VER_WORD) As Integer
        Dim lError As Integer
        Dim nDevice As Short
        Dim yMSVer As Byte
        Dim yLSVer As Byte
        sDevVer = "" 'Initialize to blank
        'Device number
        'Write manufacturer access command 0x1
        lError = modComm.WriteSMBusWord_(nMfgAccCmd, MFG_ACCESS_DEV_WORD) 'Manufacturer access code for Device type
        If lError <> 0 Then GoTo Err_Renamed
        'Read Manufacturer access word
        lError = modComm.ReadSMBusWord_(nMfgAccCmd, nDevice) 'Get Device Type
        If lError <> 0 Then GoTo Err_Renamed

        'Version number
        'Write manufacturer access command 0x2
        lError = modComm.WriteSMBusWord_(nMfgAccCmd, MFG_ACCESS_VER_WORD) 'Manufacturer access code for Device firmware version
        If lError <> 0 Then GoTo Err_Renamed
        'Read Manufacturer access word
        lError = modComm.ReadSMBusWord(nMfgAccCmd, yMSVer, yLSVer) 'GetDevice Firmware version
        If lError <> 0 Then GoTo Err_Renamed
        sDevVer = Hex(nDevice) & "." & Hex(yMSVer) & "." & Replace(VB6.Format(Hex(yLSVer), "@@"), " ", "0")
        GetGGDeviceVersion = 0
        Exit Function
Err_Renamed:
        GetGGDeviceVersion = lError
        'MsgBox LoadResString(IDS_ERR_GG_RD)
    End Function

    '-----------------------------------------------------------------------------
    ' Function: SendGGtoROM()
    ' Sends the Gas Gauge code to execute in ROM mode
    Function SendGGtoROM(ByRef nReturnToROMCmd As Short, ByRef nReturnToROMWd As Short) As Boolean
        Dim nROMVer As Short
        SendGGtoROM = False
        'Send the return to ROM command
        'If 0 <> modComm.WriteSMBusWord_(RETURN_TO_ROM_CMD, RETURN_TO_ROM_WORD) Then
        If 0 <> modComm.WriteSMBusWord_(nReturnToROMCmd, nReturnToROMWd) Then
            Exit Function
        End If
        If ReadROMVer(nROMVer) <> 0 Then
            Exit Function
        End If
        If nROMVer > 100 Then SendGGtoROM = True
    End Function
    '-----------------------------------------------------------------------------

    ' Function: ReadROMVer()
    ' Reads the ROM version. Gas Gauge must already be in ROM mode
    Function ReadROMVer(ByRef nROMVer As Short) As Integer
        ReadROMVer = modComm.ReadSMBusWord_(READ_ROM_VER_CMD, nROMVer)
    End Function

    '-----------------------------------------------------------------------------

    ' Function: RunGGCode()
    ' Runs the gas gauge code. Gas Gauge must already be in ROM mode, otherwise
    ' results are undefined.
    Function RunGGCode() As Integer
        RunGGCode = modComm.WriteSMBusCommand(RUN_GG_CODE_CMD)
    End Function

    '-----------------------------------------------------------------------------
    Sub Delay(ByRef nTimems As Integer)
        modComm.Delay(nTimems)
        DoDelayms(nTimems)
    End Sub

    '-----------------------------------------------------------------------------
    ' Procedure DoDelayms(nWaitTime as long):
    ' Waits for nWaitTime milliseconds before returning.
    ' Allows other applications/ processes to execute by yielding

    Public Sub DoDelayms(ByRef nWaitTime As Integer) ' In milliseconds
        Dim PauseTime, Start As Single
        PauseTime = CSng(nWaitTime) / 1000 ' Set duration.
        Start = VB.Timer() ' Set start time.
        System.Windows.Forms.Application.DoEvents() ' Yield to other processes.
        Do While VB.Timer() < Start + PauseTime
            System.Windows.Forms.Application.DoEvents() ' Yield to other processes.
        Loop
    End Sub
    '-----------------------------------------------------------------------------
    ' The Initialize() procedure is called by the main program on startup

    Public Sub Initialize()
        'Add your custom code here
    End Sub

    '-----------------------------------------------------------------------------
    ' The Terminate() procedure is called by the main program on Close

    Public Sub Terminate()
        'Add your custom code here
    End Sub

    Public Sub WordToBytes(ByVal nWord As Short, ByRef msb As Byte, ByRef lsb As Byte)
        Dim NegSign As Boolean
        NegSign = False
        If nWord < 0 Then
            nWord = nWord + 32768
            NegSign = True
        End If
        msb = nWord \ 256
        lsb = nWord - msb * 256
        If NegSign Then
            msb = msb + &H80
        End If
    End Sub

    Public Sub BytesToWord(ByRef msb As Byte, ByRef lsb As Byte, ByRef nWord As Short)
        If (msb > 127) Then
            nWord = (msb - 128) * 256 + &H8000 + lsb
        Else
            nWord = msb * 256 + lsb
        End If
    End Sub
    '-----------------------------------------------------------------------------

    Function Seal(Optional ByRef nSealWd As Short = MFG_ACCESS_SEAL_WORD) As Integer
        Seal = modComm.WriteSMBusWord_(modDelays.m_nTIMAC, nSealWd)
    End Function
    '-----------------------------------------------------------------------------

    Function Poke(ByRef nAddress As Short, ByRef nPokeCmd As Byte, ByRef nWrAddrCmd As Byte, ByRef nData As Short, ByRef nTargetAddress As Byte) As Integer
        Poke = modComm.WriteSMBusWord_(nWrAddrCmd, nAddress, CShort(nTargetAddress))
        If Poke <> 0 Then
            Exit Function
        End If
        Poke = modComm.WriteSMBusWord_(nPokeCmd, nData, CShort(nTargetAddress))
        If Poke = 0 Then
            Poke = modComm.CheckForError
        End If
    End Function

    Function Peek(ByRef nAddress As Short, ByRef nPeekCmd As Byte, ByRef nWrAddrCmd As Byte, ByRef nData As Short, ByRef nTargetAddress As Byte) As Integer
        Peek = modComm.WriteSMBusWord_(nWrAddrCmd, nAddress, CShort(nTargetAddress))
        If Peek <> 0 Then
            Exit Function
        End If
        Peek = modComm.ReadSMBusWord_(nPeekCmd, nData, CShort(nTargetAddress))
    End Function
End Module

Public Enum EV2300_ErrorCode As Integer
    VB_NO_ERROR = (0)
    VB_LOST_SYNC = (1)
    VB_NO_USB = (2) ' Was VB_NO_RS232
    VB_BAD_PEC = (3)
    VB_WRONG_NUM_BYTES = (5)
    VB_T2H_UNKNOWN = (6)
    VB_SMBC_LOCKED = (260) 'Unused but reserved for backward compatibility
    VB_SMBD_LOCKED = (516) 'Unused but reserved for backward compatibility
    VB_T2H_NACK = (772)
    VB_SMBD_LOW = (1028) 'Unused but reserved for backward compatibility
    VB_SMB_LOCKED = (1284) 'Unused but reserved for backward compatibility

    ' New error codes returned to VB
    VB_INCORRECT_PARAM = (7) ' Invalid parameter type passed to function - especially Variant argument.
    ' ex. Variant containing integer instead of Variant containing array of bytes
    VB_TIMEOUT_ERROR = (8) ' USB Timeout
    VB_INVALID_DATA = (9) ' AssemblePacket could not build a valid packet
    VB_ERR_UNSOLICITED_PKT = (10) ' Found an unsolicited non-error packet when looking for error packets
    VB_COMPARE_DIFFERENT = (11) ' Comparison failed and data read is different from srec

    ' Added codes for Programming/Compare
    ' Srec errors
    VB_BQ80XRW_OCX_INTERNAL_ERROR = (12) ' Problems with pointers being NULL etc.
    VB_SREC_OPEN_FAIL = (221)
    VB_SREC_BAD_START_RECORD = (222)
    VB_SREC_UNKNOWN_TYPE = (223)
    VB_SREC_BAD_CHECKSUM = (224)
    VB_SREC_BAD_RECORD_COUNT = (225)
    ' SREC targets a different device than the one detected on the SMBus '
    VB_SREC_DEV_MISMATCH = (226)

    ' Config errors
    VB_CONFIG_OPEN_FAIL = (227)
    VB_CONFIG_UNEXPECTED_EOF = (228)
    VB_CONFIG_BAD_FORMAT = (229)

    ' The VER byte in the devices instruction flash does not match the range expected by this config file  '
    VB_PCFG_DEVVER_MISMATCH = (231)
    ' The DEV byte in the devices instruction flash does not match what the config file expected '
    VB_PCFG_DEV_MISMATCH = (232)
    ' The VER byte in the instruction flash image to be programed into the device does not match the one in config file '
    VB_PCFG_SRECDEVVER_MISMATCH = (233)
    ' The DEV byte in the instruction flash image to be programed into the device does not match the one in config file '
    VB_PCFG_SRECDEV_MISMATCH = (234)
    ' The VER byte in the devices instruction flash does not match the range expected by this config file  '
    VB_BCFG_DEVVER_MISMATCH = (235)
    ' The DEV byte in the devices instruction flash does not match what the config file expected '
    VB_BCFG_DEV_MISMATCH = (236)

    VB_USER_CANCELLED_OPERATION = (34)
    VB_DF_CHECKSUM_MISMATCH = (51)
    VB_IF_CHECKSUM_MISMATCH = (52)
    VB_OPERATION_UNSUPPORTED = (53)

    ' New Error codes corresponding to PKTSpec Error codes
    VB_ERR_TOO_MANY_QUERIES = (81)
    VB_ERR_BAD_QUERY_ID = (82)
    VB_BAD_CRC = (83)
    VB_ERR_TOO_MANY_RESPONSES = (84)
    VB_ERR_NO_QUERIES_TO_DELETE = (85)
    VB_ERR_QUERY_UNAVAILABLE = (86)
    VB_ERR_NO_RESPONSES_TO_DELETE = (87)
    VB_ERR_RESPONSE_UNAVAILABLE = (88)
    VB_ERR_TMMT_NO_RESPONSE = (90)
    VB_T2H_ERR_TIMEOUT = (92)
    VB_BUS_BUSY = (94)
    VB_T2H_ERR_BAD_SIZE = (95)
    VB_ERR_BAD_PAYLOAD_LEN = (97)
    VB_ERR_TMMT_LIST_FULL = (98)
    VB_ERR_TMMT_BAD_SELECTION = (99)
    VB_UNKNOWN = (100)

    ' New Generic error codes
    VB_UNEXPECTED_ERROR = (110) ' Should not happen
    VB_OUT_OF_MEMORY = (111)

    'EVSW error codes reserved 5000 - 6000
    VB_ERR_NOTHINGTODO = 5001
    VB_ERR_VOLTAGE_LESSTHANZERO = 5002
    VB_ERR_TEMPERATURE_LESSTHANZERO = 5003
    VB_ERR_CURRENT_EQUALSZERO = 5004

    VB_ERR_NOT_IN_CAL_MODE = 5010

    VB_ERR_CALIBRATION_IN_FIRMWARE_FLASHWRITE = 5020
    VB_ERR_CALIBRATION_IN_FIRMWARE_AFE = 5021
    VB_ERR_CALIBRATION_IN_FIRMWARE_PACKV = 5022
    VB_ERR_CALIBRATION_IN_FIRMWARE_PACKG = 5023
    VB_ERR_CALIBRATION_IN_FIRMWARE_VGAIN = 5024
    VB_ERR_CALIBRATION_IN_FIRMWARE_CCIGAIN = 5025
    VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFEXT1 = 5026
    VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFEXT2 = 5027
    VB_ERR_CALIBRATION_IN_FIRMWARE_TMPOFFINT = 5028
    VB_ERR_CALIBRATION_IN_FIRMWARE_ADCOFF = 5029
    VB_ERR_CALIBRATION_IN_FIRMWARE_BRDOFF = 5030
    VB_ERR_CALIBRATION_IN_FIRMWARE_CCIOFF = 5031
    '_RSVD can be used for future subcodes, we want it to be in sequence
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD0 = 5032
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD1 = 5033
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD2 = 5034
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD3 = 5035
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD4 = 5036
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD5 = 5037
    VB_ERR_CALIBRATION_IN_FIRMWARE_RSVD6 = 5038
    VB_ERR_CALIBRATION_IN_FIRMWARE_UNDEFINED = 5039

    VB_ERR_DF_RD_REQ_B4_WR = 5041
    VB_ERR_INVALID_DATA_ENTERED = 5042
    VB_ERR_USB_ACQUIRE = 5043

    '!!! Do not modify this code : End of restriction !!!

    '*************************************************************'
    'All error codes below 65536 are reserved for use by TI Austin
    '*************************************************************'

    'User defined error codes must be above 65536
    VBUSER_INVALID_FILENAME = 65537
    VBUSER_DEVICE_VERSION_MISMATCH = 65538
    VBUSER_RETURN_TO_ROM_FAILED = 65539
    VBUSER_RUNGG_FAILED = 65541
    VBUSER_WRITEFLASH_GG_FAILED = 65542
    VBUSER_CALIBRATE_FAILED = 65543
    VBUSER_POST_CAL_CHECKS_FAILED = 65544
    VBUSER_WRITESERIAL_FAILED = 65545
    VBUSER_ERR_UNEXPECTED = 65552
    VBUSER_ERR_FILE = 65553 ' Error opening/processing File
    VBUSER_ERR_NOT_IN_ROM = 65554 'GG not in ROM mode when expected - communication failure?
    VBUSER_ERR_ENTER_CALMODE = 65555 'Cannot put GG in Cal mode
    VBUSER_ERR_CUSTOM_FUNC = 65556
    VBUSER_BAD_FILE_FORMAT = 65557 'Header bad or format bad
    VBUSER_ERR_WRITE_MFG_DATA = 65558 'Failed to write manufacturer data
    VBUSER_ERR_READ_DEV_VER = 65559 'Communication error reading device version

    VBUSER_CAL_VOLT_LESSTHANZERO = 65600 'Calibration voltage must be greater than 0
    VBUSER_CAL_TEMP_LESSTHANZERO = 65601 'Calibration current must be greater than 0
    VBUSER_CAL_CURR_LESSTHANZERO = 65602 'Calibration current must be greater than 0

    'Renumbered as per Travis' request
    VBUSER_WRITEFLASH_ROM_FAILED = 65560

    VBUSER_SENSE_RES_CAL_HIGH = 65570
    VBUSER_SENSE_RES_CAL_LOW = 65571
    VBUSER_VOLT_CAL_HIGH = 65580
    VBUSER_VOLT_CAL_LOW = 65581
    VBUSER_TEMP_CAL_HIGH = 65590
    VBUSER_TEMP_CAL_LOW = 65591

    VBUSER_SEAL_CMD_FAILED = 65610
    VBUSER_ERR_READ_CB_INT_TEMP_SENSOR = 65611
    VBUSER_ERR_READ_CB_EXT_TEMP_SENSOR = 65612

    VBUSER_ERR_CALIBRATION_OUTOFSPEC = 65613
    VBUSER_ERR_WORKAROUND_ROUTINE = 65614
    'These are Nexergy error codes
    NEX_GENERIC_ERROR = 70000
    NEX_SERIAL_WRITE_NOT_CONFIRMED = 70001
    NEX_DOM_WRITE_NOT_CONFIRMED = 70002
    NEX_ReadEEPROM_Word_RuntimeError = 70003
    NEX_WriteEEPROM_Word_RuntimeError = 70004
    NEX_CalibrationVpackOutOfRange = 70011
    NEX_ArgumentOutOfRange = 70012
    NEX_ByteWrite_CanNotConfirm = 70013

    BoardOffsetCal_UnexpectedError = 70014
    BoardOffsetCal_DivideByZeroError = 70015
    BoardOffsetCal_IsSealedError = 70016
    NEX_ERROR_DURING_BLOCK_READ = 70017
End Enum

