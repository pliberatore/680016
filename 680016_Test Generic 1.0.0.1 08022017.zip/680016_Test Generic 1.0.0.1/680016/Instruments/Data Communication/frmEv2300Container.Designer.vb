﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmEv2300Container
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmEv2300Container))
        Me.AxBq80xRW1 = New AxBQ80XRWLib.AxBq80xRW()
        CType(Me.AxBq80xRW1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AxBq80xRW1
        '
        Me.AxBq80xRW1.Enabled = True
        Me.AxBq80xRW1.Location = New System.Drawing.Point(0, 0)
        Me.AxBq80xRW1.Name = "AxBq80xRW1"
        Me.AxBq80xRW1.OcxState = CType(resources.GetObject("AxBq80xRW1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxBq80xRW1.Size = New System.Drawing.Size(100, 50)
        Me.AxBq80xRW1.TabIndex = 0
        '
        'frmEv2300Container
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.AxBq80xRW1)
        Me.Name = "frmEv2300Container"
        Me.Text = "frmEv2300Container"
        CType(Me.AxBq80xRW1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents AxBq80xRW1 As AxBQ80XRWLib.AxBq80xRW
End Class
