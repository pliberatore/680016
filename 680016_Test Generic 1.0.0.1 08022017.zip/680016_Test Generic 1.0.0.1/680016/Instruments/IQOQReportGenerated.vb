﻿'Copyright 2017, iTECH

Public Class IOQReportGenerater
    ' Class to generate IQ/OQ report
    ' Installation Flags are set to TRUE when the various equipment items are found
    Public Property CellPowerFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.1") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.1", "Cell Power Supply Found", value)
        End Set
    End Property
    Public Property PackPowerFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.2") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.2", "Pack Power Supply Found", value)
        End Set
    End Property

    Public Property AuxPowerFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.3") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.3", "Aux Power Supply Found", value)
        End Set
    End Property
    Public Property CellEloadFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.4") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.4", "Cell E-Load Found", value)
        End Set
    End Property
    Public Property PackEloadFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.5") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.5", "Pack E-Load Found", value)
        End Set
    End Property

    Public Property RelayDriverFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.6") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.6", "Relay Driver Found", value)
        End Set
    End Property

    Public Property DAQFound As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.7") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.7", "DAQ Found", value)
        End Set
    End Property
    Public Property EV2400Found As Boolean
        Get
            Return DataReport.GetMeasuredValue("IQ10.1.8") = 1
        End Get
        Set(value As Boolean)
            DataReport.AddMeasurement_Boolean("IQ10.1.8", "EV2400 Found", value)
        End Set
    End Property
    Public Property R112Gain As Double

    Public DataReport As New DataCollection

    Public Function AllEquipmentFound()
        Return Me.CellEloadFound And
            Me.PackEloadFound And
            Me.CellPowerFound And
            Me.PackPowerFound And
            Me.AuxPowerFound And
            Me.EV2400Found And
            Me.DAQFound And
            Me.RelayDriverFound
    End Function

    Public Function DoIOQTest() As Boolean
        ' Performs Installation/Operation Test as defined in Test Plan
        ' The purpose is to determine the TEST3 and Fixture Connections are correct
        Dim TStep As Integer = 0
        DoIOQTest = True
        Dim StepResult As Boolean = True

        Const VSetPoint As Double = 48.0
        Const ISetPoint As Double = 3.0
        Const TheRange As Double = 0.05

        Dim InRange As Boolean

        Const VsetPointAux As Double = 5

        ' Perform each verification listed in Test Plan, IOQ section
        With TestSetControl
            Do
                Select Case TStep
                    Case 1
                        ' Verify all the required equipment is communication. No point in continuing if that's not true
                        StepResult = AllEquipmentFound()
                    Case 2
                        ' Connect Cell PS to Cell Load through the B09851 relays.
                        ' Verify the PS and EL see each other
                        .RelayDriver.ClearAllBits()
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        .PsCell.VoltageSet = VSetPoint
                        .PsCell.CurrentSet = 5.0
                        .ELoadCell.ConstantCurrentSetting = ISetPoint

                        .PsCell.IsEnabled = True
                        .ELoadCell.InputEnabledState = True

                        ' Cycle the relays to clean the relay contacts
                        For i As Integer = 1 To 6
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                            Delay(100)
                        Next
                        For i As Integer = 1 To 6
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                            Delay(100)
                        Next
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        ' Wait a sec for the values to come up
                        Do
                            Delay(100)

                            Dim PsVolt As Double = .PsCell.OutputVoltage
                            Dim ElVolt As Double = .ELoadCell.GetInputVoltage
                            InRange = True
                            InRange = InRange And Utility.InRange(PsVolt, VSetPoint * (1 - TheRange), VSetPoint * (1 + TheRange))
                            InRange = InRange And Utility.InRange(ElVolt, VSetPoint * (1 - TheRange), VSetPoint * (1 + TheRange))

                            Dim PsCurr As Double = .PsCell.OutputCurrent
                            Dim ElCurr As Double = .ELoadCell.GetInputCurrent
                            InRange = InRange And Utility.InRange(PsCurr, ISetPoint * (1 - TheRange), ISetPoint * (1 + TheRange))
                            InRange = InRange And Utility.InRange(ElCurr, ISetPoint * (1 - TheRange), ISetPoint * (1 + TheRange))
                        Loop Until InRange Or Sw.ElapsedMilliseconds > 1000

                        StepResult = DataReport.AddMeasurement_Boolean("IQ10.2", "Cell Power Connections", InRange)
                    Case 3
                        ' Switch 12x10 ohm (12s) cell divider resistors across the Cell PS
                        ' The current should now be up to 48V/(12*10 ohm) = 0.4A
                        ' Turn off the E-load relay, but leave the E-load enabled, just in case the relay is stuck on.
                        .RelayDriver.ClearBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        ' Switch divider to output
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_A)
                        For i = 1 To 6
                            ' Do the toggle thing to clean the contacts
                            Delay(100)
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Cell_A)
                        Next
                        Dim PSCurr As Double
                        Dim ExpectedCurr As Double = VSetPoint / (12 * 10) 'Amps. Twelve 10-ohm resistors (12s) across the PS
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(100)
                            PSCurr = .PsCell.OutputCurrent
                            InRange = DataReport.AddMeasurement_Double("IQ10.3", "Cell Divider Current", ExpectedCurr * (1 - TheRange), ExpectedCurr * (1 + TheRange), PSCurr, "A")
                        Loop Until InRange Or Sw.ElapsedMilliseconds > 1000
                        StepResult = InRange
                        ' No need for cell loads anymore
                        .RelayDriver.ClearAllBits()
                        .PsCell.IsEnabled = False
                        .ELoadCell.InputEnabledState = False
                    Case 4

                    Case 5
                        ' Connect Pack PS to Cell Load through the B09851 relays.
                        ' Verify the PS and EL see each other
                        .RelayDriver.ClearAllBits()
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_EL)
                        .PsPack.VoltageSet = VSetPoint
                        .PsPack.CurrentSet = 5.0
                        .EloadPack.ConstantCurrentSetting = ISetPoint

                        .PsPack.IsEnabled = True
                        .EloadPack.InputEnabledState = True
                        ' Operate the relays under load to clean the relay contacts
                        For i As Integer = 1 To 6
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                            Delay(100)
                        Next
                        For i As Integer = 1 To 6
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Pack_EL)
                            Delay(100)
                        Next

                        Dim Sw As New Stopwatch
                        Sw.Start()
                        ' Wait a sec for the values to come up
                        Do
                            Delay(100)

                            Dim PsVolt As Double = .PsPack.OutputVoltage
                            Dim ElVolt As Double = .EloadPack.GetInputVoltage
                            InRange = True
                            InRange = InRange And Utility.InRange(PsVolt, VSetPoint * (1 - TheRange), VSetPoint * (1 + TheRange))
                            InRange = InRange And Utility.InRange(ElVolt, VSetPoint * (1 - TheRange), VSetPoint * (1 + TheRange))

                            Dim PsCurr As Double = .PsPack.OutputCurrent
                            Dim ElCurr As Double = .EloadPack.GetInputCurrent
                            InRange = InRange And Utility.InRange(PsCurr, ISetPoint * (1 - TheRange), ISetPoint * (1 + TheRange))
                            InRange = InRange And Utility.InRange(ElCurr, ISetPoint * (1 - TheRange), ISetPoint * (1 + TheRange))
                        Loop Until InRange Or Sw.ElapsedMilliseconds > 1000

                        StepResult = DataReport.AddMeasurement_Boolean("IQ10.4", "Pack Power Connections", InRange)
                        .RelayDriver.ClearAllBits()
                        .PsPack.IsEnabled = False
                        .EloadPack.InputEnabledState = False

                    Case 7
                        ' Verify the AUX Power connections
                        .PSAux.VoltageSet = VsetPointAux
                        .PSAux.CurrentSet = 2   ' Not too high in case of a short
                        .PSAux.IsEnabled = True
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Aux_PS)
                        ' Exercise this relay
                        For i As Integer = 1 To 6
                            Delay(100)
                            .RelayDriver.ToggleBit_En(clsRelayDriver.enBitFunctions.Aux_PS)
                        Next
                        Dim ExpectedCurrent = VsetPointAux / 10.0   ' One 10.0 ohm across ouput, 1s
                        Dim TheCurr As Double
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(100)
                            TheCurr = TestSetControl.PSAux.OutputCurrent
                            StepResult = DataReport.AddMeasurement_Double("IQ10.5", "Aux PS Current, Balance Off", ExpectedCurrent * (1 - TheRange), ExpectedCurrent * (1 + TheRange), TheCurr, "A")

                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 1000
                        If Not StepResult Then Stop
                    Case 8
                        ' Cycle through the balancing relays. 
                        ' Each balancing relays should result in PS_AUX with 1.000Amps at 5V
                        Dim ExpectedCurr As Double = VsetPointAux / 10 / 2 ' Two 10 ohm (2p)
                        ExpectedCurr = 1.0
                        Dim UL As Double = ExpectedCurr * (1 + TheRange)
                        Dim LL As Double = ExpectedCurr * (1 - TheRange)
                        StepResult = True
                        For RelayChan As Integer = 1 To 12
                            .DAQ.CloseSwitch(RelayChan + 200) ' Enable the balanced channel
                            Dim PsCurrent As Double
                            Dim Sw As New Stopwatch
                            Sw.Start()
                            Do
                                Delay(200)
                                PsCurrent = .PSAux.OutputCurrent
                            Loop Until Sw.ElapsedMilliseconds > 2000 Or Utility.InRange(PsCurrent, LL, ul)
                            StepResult = StepResult And
                                DataReport.AddMeasurement_Double("IQ10.6." & RelayChan.ToString, "Balance Current, Cell " & RelayChan.ToString, LL, UL, PsCurrent, "A")
                            .DAQ.OpenSwitch(RelayChan + 200)
                        Next
                       ' .PSAux.IsEnabled = False
                    Case 10
                        ' Verify Vcell1 can be measured on DAQ Channel 113
                        TestSetControl.PSAux.IsEnabled = True
                        .DAQ.CloseSwitch(201)
                        Delay(100)
                        Dim Vcell1Volts As Double
                        .DAQ.ReadDCVolts(113, Vcell1Volts, "", True)
                        Dim VAux As Double = .PSAux.OutputVoltage
                        Dim DeltaV = Math.Abs(Vcell1Volts - VAux)
                        Dim IsOk As Boolean = (DeltaV / VAux) < 0.05 ' 10% difference is OK
                        StepResult = DataReport.AddMeasurement_Boolean("IQ10.7", "Vcell1 Measurement", IsOk)
                        .RelayDriver.ClearAllBits()
                        .DAQ.OpenSwitch(201)    '' All done
                        .PSAux.IsEnabled = False
                    Case 12
                        'So far, so good. Now do the Fixture Auto-Calibration
                        ' Apply nominal stack voltage with PS_Cell
                        ' Set Pack E-Load to 0.9Amps
                        ' Enable PACK_B relay. This connects the pack e-load to "other" side of R112 sense resistor, through DAQ Ch 121.
                        ' Read the reference current with Ch 112. Read R112 voltage with Ch 112. Do the math do determine the resistance value.
                        ' This resistance is used in the test sequence for current calibration.
                        '
                        ' Note: DAQ Ch 122 can only measure up to 1 Amp. Don't set the reference current too high!
                        .PsCell.VoltageSet = VSetPoint
                        .PsCell.CurrentSet = 5    ' Enough
                        .ELoadCell.ConstantCurrentSetting = 0.9    ' Still in range of the DAQ current sense
                        ' Route the Cell PS to "Cell_A" on FIXTURE 1 connector
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_A)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        ' Route the Pack E-Load to "Pack_B" on FIXTURE 1 connector
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_B)
                        ' Current is now flowing. Let the equipment settle any transients
                        Delay(1000) 'Way long enough
                        Dim RefCurrent As Double
                        .DAQ.ReadDCAmps(121, RefCurrent, "auto", True)
                        Dim RefVoltage As Double
                        .DAQ.ReadDCVolts(112, RefVoltage, "", True)
                        If RefVoltage <> 0 Then
                            Me.R112Gain = RefCurrent / RefVoltage
                        Else
                            Me.R112Gain = Double.MaxValue ' Overange, but don't divide-by-zero error
                        End If
                        Dim R112Nominal = 0.1 ' Nominal value
                        Dim LL As Double = R112Nominal * 0.98   ' 2% variance, max, otherwise something is wrong
                        Dim UL As Double = R112Nominal * 1.02
                        StepResult = DataReport.AddMeasurement_Double("IQ10.7", "R112 Gain", LL, UL, Me.R112Gain, "S", "0.0000")
                End Select
                TStep += 1
                DoIOQTest = DoIOQTest And StepResult
                If Not DoIOQTest Then Stop
            Loop While DoIOQTest And TStep < 11
            DataReport.EndTest()
            DataReport.WriteXMLDataFile("IOQ Report.xml")
            Return DataReport.TestStatus = DataCollection.enTestStatus.TEST_PASS
        End With
    End Function
    Public Sub WriteIqOqReport()
        AddStatusMessage("Cell E-Load Found=" & Me.CellEloadFound.ToString)
        AddStatusMessage("Cell Power Supply Found=" & Me.PackEloadFound.ToString)

        AddStatusMessage("Pack E-Load Found=" & Me.PackEloadFound.ToString)
        AddStatusMessage("Pack Power Supply Found=" & Me.PackPowerFound.ToString)

        AddStatusMessage("Aux Power supply found=" & Me.AuxPowerFound.ToString)

        AddStatusMessage("DAQ Found=" & DAQFound.ToString)
        AddStatusMessage("Relay Driver Found=" & RelayDriverFound.ToString)
        AddStatusMessage("EV2400 Found" = EV2400Found.ToString)
    End Sub
    Private Sub Delay(msec As Integer)
        Dim Sw As New Stopwatch
        Sw.Start()
        Do
            My.Application.DoEvents()
        Loop Until Sw.ElapsedMilliseconds >= msec
    End Sub
End Class
