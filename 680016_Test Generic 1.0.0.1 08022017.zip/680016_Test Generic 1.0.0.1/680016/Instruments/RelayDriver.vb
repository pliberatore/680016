﻿Public Class clsRelayDriver
    ' Copyright 2017, iTECH
    ' P Liberatore
    ' PLiberatore@itech.com

    'Class to control Elexol USBIO/24 device
    'Assumes all ports are configured as output-only
    'Each bit individually address

    ' The state of each bit is communicated to the client objects through Status Report Events
    ' This class raises an events reporting the state of each bit. Any "interested" objects may handle these events to update status indicators
    ' The events are triggered
    '   - When a bit is set or cleared
    '   - When a bit is queried

    ' The USBIO/24 contains a FTDI FT1245R USB-to-Serial converter generates a Virtual COM Port (VCP) on the system. This device appears on the system like any other COM port.
    ' Windows10 appears to load the device with no problem. If needed, the VCP drivers are available from ftdichip.com
    Public Enum enBitFunctions
        Cell_A = 0
        Cell_B = 1
        Cell_C = 2
        Cell_D = 3
        Cell_E = 4
        Cell_F = 5
        Cell_G = 6
        Cell_H = 7

        Pack_A = 8
        Pack_B = 9
        Pack_C = 10
        Pack_D = 11
        Pack_E = 12
        Pack_F = 13
        Pack_G = 14
        Pack_H = 15

        Cell_PS = 16
        Cell_EL = 17

        Pack_PS = 18
        Pack_EL = 19
        Aux_PS = 20

        Relay_21 = 21
        Relay_22 = 22
        Relay_23 = 23
    End Enum
    Public MyCommPort As System.IO.Ports.SerialPort

    Public Event BitStatus(BitNumber0_23 As Integer, BitIsSet As Boolean)

    Public Sub ClearAllBits()
        For i As Integer = 0 To 23
            Call WriteBitState(i, False)
        Next
    End Sub
    Public Function GetBitState(Bit0_23 As Integer) As Boolean

        If Not MyCommPort.IsOpen Then MyCommPort.Open()

        Dim Cmd As String
        Dim Offset As Integer
        Select Case Bit0_23
            Case 0 To 7
                Cmd = "a"
                Offset = Bit0_23
            Case 8 To 15
                Cmd = "b"
                Offset = Bit0_23 - 8
            Case 16 To 23
                Cmd = "c"
                Offset = Bit0_23 - 16
            Case Else
                Err.Raise(3001, Me, "GetBitState:Invalid Bit Number: " & Bit0_23)
        End Select
        MyCommPort.Write(Cmd)
        Dim ResponseByte As Byte = MyCommPort.ReadByte
        Dim mask As Integer
        mask = 2 ^ Offset
        GetBitState = (ResponseByte And mask) <> 0

        RaiseEvent BitStatus(Bit0_23, GetBitState)
    End Function

    Public Sub WriteBitState(Bit0_23 As Integer, SetTheBit As Boolean)
        If Not MyCommPort.IsOpen Then MyCommPort.Open()
        Dim Cmd As String = "'"

        Select Case Bit0_23
            Case 0 To 23
                Cmd = IIf(SetTheBit, "H", "L") & Chr(Bit0_23)
            Case Else
                Err.Raise(3001, Me, "WRiteBitState:Invalid Bit Number: " & Bit0_23)
        End Select
        MyCommPort.Write(Cmd)

        RaiseEvent BitStatus(Bit0_23, SetTheBit)
    End Sub
    Public Sub ToggleBit_En(BitToToggle As enBitFunctions)
        ToggleBit(BitToToggle)
    End Sub
    Public Sub ToggleBit(Bit0_23)
        Dim PresentState As Boolean
        PresentState = GetBitState(Bit0_23)
        WriteBitState(Bit0_23, Not PresentState)
    End Sub
    Public Sub ClearBit_En(BitToClear As enBitFunctions)
        Call ClearBit(BitToClear)
    End Sub
    Public Sub ClearBit(Bit0_23 As Integer)
        Call WriteBitState(Bit0_23, False)
    End Sub
    Public Sub SetBit_En(BitToSet As enBitFunctions)
        Call SetBit(BitToSet)
    End Sub
    Public Sub SetBit(Bit0_23 As Integer)
        Call WriteBitState(Bit0_23, True)
    End Sub
    Public Function FindDevice() As Boolean
        'Last COM port is stored in User Setting USBIO24_ComPort. Look there first for the device. 
        'If not found, then look at all other port
        MyCommPort = New System.IO.Ports.SerialPort
        AddStatusMessage("Locating USBIO/24 Relay Driver Device", 0)
        ' First look at the last port number that had a USBIO/24 device
        Try
            MyCommPort.BaudRate = 19200
            MyCommPort.Handshake = IO.Ports.Handshake.None
            MyCommPort.DataBits = 8
            MyCommPort.StopBits = 1
            MyCommPort.PortName = My.Settings.Usbio24_ComPort
            FindDevice = Me.PingPort  'true if there is a port here
        Catch ex As Exception
            ' Not here. Look somewhere else
            FindDevice = False
        End Try

        ' Each each port on the system
        For Each PortToTry As String In My.Computer.Ports.SerialPortNames
            Try
                MyCommPort.PortName = PortToTry
                FindDevice = PingPort()
                If FindDevice Then Exit For
            Catch ex As Exception
                '' Couldn't open the device. Try next
                FindDevice = False
            End Try
        Next
        Try
            If Not FindDevice Then Err.Raise(3001, "clsRelayDriver.FindDevice", "Cannot Find USBIO/24 COM Port")
        Catch ex As Exception
            ' Call general error handler
            Utility.ErrorHandler_General(ex, My.Settings.DisplayErrorMessagebox)
        Finally
            If FindDevice Then
                My.Settings.Usbio24_ComPort = MyCommPort.PortName
                Me.SetPortDirection()
                Me.ClearAllBits()
            End If
        End Try

    End Function
    Private Function PingPort() As Boolean
        Dim ExpectedIDResponse As String = "USB I/O 24".Replace(" ", "") 'The ID change can change wil Firmware. Don't verify reponse too strictly
        PingPort = False
        Dim Resp As String
        Try
            If Not MyCommPort.IsOpen Then
                MyCommPort.Open()
            End If
            MyCommPort.Write("?")
            Utility.Delay(250)
            Resp = MyCommPort.ReadExisting
            Resp = Resp.Trim.Replace(" ", "").ToUpper
            PingPort = Resp.Contains(ExpectedIDResponse)
        Catch ex As Exception
            PingPort = False
        Finally
            Try
                MyCommPort.Close()
            Catch ex As Exception
                PingPort = False
            End Try
        End Try
    End Function
    Private Function SetPortDirection() As Boolean
        'sets all 24 bits to 'Output from Device'.
        Dim Cmd As String
        Dim BitMapOut0_In1 As Short = &H0
        AddStatusMessage("Configuring Port Direction", 1)
        Try
            Cmd = "!" & "A" & Chr(BitMapOut0_In1)
            If Not MyCommPort.IsOpen Then
                MyCommPort.Open()
            End If
            MyCommPort.Write(Cmd)

            Cmd = "!" & "B" & Chr(BitMapOut0_In1)
            If Not MyCommPort.IsOpen Then
                MyCommPort.Open()
            End If
            MyCommPort.Write(Cmd)

            Cmd = "!" & "C" & Chr(BitMapOut0_In1)
            If Not MyCommPort.IsOpen Then
                MyCommPort.Open()
            End If
            MyCommPort.Write(Cmd)
            Return True
        Catch ex As Exception
            ErrorHandler_General(ex, "clsRelayDriver.SetPortDirection")
            Return False
        End Try
    End Function

End Class
