﻿Public Class VisaDevice
    '' 
    '' 
    ' I/O Operations.
    ' These subs raise events
    Public Event VisaOperation(ByVal data As String, ByVal EventType As String, ByVal IsError As Boolean)

    Private MyVisaInst As New Ivi.Visa.Interop.FormattedIO488
    Private io_mgr As New Ivi.Visa.Interop.ResourceManager ' to be used for the resource manager
    Public Connected As Boolean
    Public SerialOptionsString As String


    Public Function OpenPort(ByVal ConnString As String) As Boolean
        '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        ' This function opens a port (the communication between the instrument and computer).
        '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        ' Exceptions are handled by the client
        ' Get the instrument address form the text box
        'If Not ConnString.EndsWith("::INSTR") Then ConnString = ConnString & "::INSTR"
        ' Check if address is GPIB or RS-232
        Try
            If InStr(ConnString, "ASRL") Then
                ' Use the optionstring to setup the RS-232 parameters

                ' Open serial I/O session with the driver
                'DataLogger.IO = io_mgr.Open(addr, True, True, OptionString)
                MyVisaInst.IO = io_mgr.Open(ConnString, Ivi.Visa.Interop.AccessMode.NO_LOCK, 10000, SerialOptionsString)
                RaiseEvent VisaOperation("Open Resource Manager" & NL & ConnString, "RM", False)
            Else
                ' Open USB, GPIB or LAN resource session
                MyVisaInst.IO = io_mgr.Open(ConnString)
                'Dim DD() As String = io_mgr.FindRsrc("USB0::0x0957::0x2007::MY49017646::0::INSTR")
                RaiseEvent VisaOperation("Open Resource Manager" & NL & ConnString, "RM", False)
            End If
            Return True
        Catch ex As Exception
            RaiseEvent VisaOperation("Open Resource Manager" & NL & ConnString, "RM", True)
            Return False
        End Try
    End Function

    Public Function ReadList() As Object
        Try
            ReadList = MyVisaInst.ReadList(Ivi.Visa.Interop.IEEEASCIIType.ASCIIType_R8)
            Dim TheMsg As New System.Text.StringBuilder("ReadList ... Data: ")
            Dim EvMsg As New System.Text.StringBuilder("ReadList ... Data: ")
            If IsArray(ReadList) Then
                For Each Val As Object In ReadList
                    EvMsg.Append(Val.ToString & ", ")
                Next
                EvMsg.Remove(EvMsg.Length - 2, 2)
            End If
            RaiseEvent VisaOperation(EvMsg.ToString, "ReadList", False)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            RaiseEvent VisaOperation("VISA 'ReadList' ERROR: " & ex.Message, "ReadListError", True)
            Throw New Exception(ex.Message)
        End Try
    End Function

    Public Function WriteString(ByVal data As System.Text.StringBuilder) As Boolean
        Return WriteString(data.ToString)
    End Function
    Public Function WriteString(ByVal data As String) As Boolean
        Try
            MyVisaInst.WriteString(data)
            RaiseEvent VisaOperation("WriteString ... Data: " & data, "WriteString", False)
            Return True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            RaiseEvent VisaOperation("VISA 'WriteString' ERROR: " & ex.Message, "WriteStringError", True)
            Return False
        End Try
    End Function
    Public Function WriteNumber(ByVal data As Object, Optional ByVal TheType As Ivi.Visa.Interop.IEEEASCIIType = Ivi.Visa.Interop.IEEEASCIIType.ASCIIType_Any) As Boolean
        Try
            MyVisaInst.WriteNumber(data)
            RaiseEvent VisaOperation("WriteNumber ... Data: " & data, "WriteNumber", False)
            Return True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            RaiseEvent VisaOperation("VISA 'WriteNumber' ERROR: " & ex.Message, "WriteNumberError", True)
        End Try
    End Function
    Public Function ReadString() As String
        Try
            ReadString = MyVisaInst.ReadString()
            RaiseEvent VisaOperation("ReadString ... " & ReadString, "ReadString", False)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            RaiseEvent VisaOperation("VISA 'ReadString' ERROR: " & ex.Message, "ReadStringError", True)
        End Try
    End Function
    Public Function ReadNumber() As Double
        Return ReadNumber(Ivi.Visa.Interop.IEEEASCIIType.ASCIIType_Any, True)
    End Function
    Public Function ReadNumber(ByVal TheType As Ivi.Visa.Interop.IEEEASCIIType, Optional ByVal FlushToEnd As Boolean = True) As Double
        Try
            ReadNumber = MyVisaInst.ReadNumber(TheType, FlushToEnd)
            RaiseEvent VisaOperation("ReadNumber ... " & ReadNumber, "ReadNumber", False)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            RaiseEvent VisaOperation("VISA 'ReadNumber' ERROR: " & ex.Message, "ReadNumberError", True)
            Return 0
        End Try
    End Function
    Public Function ResetDevice() As Boolean
        Return Me.WriteString("*RST")
    End Function
    Public Sub CloseVisaSession()
        Try
            RaiseEvent VisaOperation("Close VISA Session", "CloseVisa", False)
            Me.Connected = False
            MyVisaInst.IO.Close()
        Catch ex As Exception
            'Error out if not open
        End Try
        connected = False
    End Sub
    Public Sub WaitForOpComplete(ByVal Timeoutms As Integer)
        Dim Sw As New Stopwatch
        Sw.Start()

        Dim i As Integer = 0
        Dim Resp As String
        Dim TheResps As New Collection
        Do
            WriteString("*opc?")
            Resp = Me.ReadString
            TheResps.Add(Resp)
        Loop Until Sw.ElapsedMilliseconds >= Timeoutms

        For Each re As String In Resp
            AddStatusMessage("*OPC?  " & i & re)
        Next

    End Sub
End Class
