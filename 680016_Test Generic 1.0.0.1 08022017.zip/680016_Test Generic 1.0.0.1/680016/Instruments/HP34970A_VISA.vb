Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Imports System.Windows.Forms.Application
Imports System.Data
Imports System.Text

Public Class HP34970A_VISA
    'Copyright 2017. iTECH Corporation
    ' P. Liberatore
    'Class to drive Keysight 3470A/34972A Data Aquistion Unit

    Public Event VisaOperation(data As String, EventType As String, IsErrorMessage As Boolean)
    Public Event SwitchState(Channel As Integer, IsClosed As Boolean)
    Public Event ResetComplete(TheError As Exception)

    Private Function VerifyChannel(TheChannel As Integer) As Boolean
        Select Case TheChannel
            Case 101 To 122
                Return Me.pBoardType100(1) = "34901A"
            Case 201 To 220
                Return Me.pBoardType200(1) = "34903A"
            Case 301 To 322
                Return Me.pBoardType300(1) = "34901A"
            Case Else
                Return False
        End Select
    End Function

    Private WithEvents pTheConfigTable As DaqControlDataSet.dtDaqConfigurationDataTable
    Public WithEvents ConfigurationDataGridView As DataGridView

    'VISA Comm
    Private connected As Boolean = False ' Sets flag to determine if instrument is connected or not
    'Public dtDataGridValues As New DataSet.dtDaqSettingsDataTable
    Private pBoardType100() As String
    Private pBoardType200() As String
    Private pBoardType300() As String

    Public Function BoardType(ByRef Slot As Short) As String
        If Slot = 100 Or Slot = 200 Or Slot = 300 Then
            VisaDev.WriteString("SYST:CTYP? " & Slot)
            BoardType = VisaDev.ReadString
        Else
            BoardType = "Invalid Slot Number: " & Slot
        End If
    End Function

    Public Property Autozero() As Boolean
        'Pg 122
        'The instrument is more accurate with Autozero=True
        Get
            VisaDev.WriteString("ZERO:AUTO?")
            Autozero = VisaDev.ReadNumber = 1
        End Get
        Set(ByVal Value As Boolean)
            Dim Msg As String
            Msg = "ZERO:AUTO " & IIf(Value, "ON", "OFF")
            VisaDev.WriteString(Msg)
        End Set
    End Property

    Public Sub New()
        MyBase.New()

    End Sub
    Public Function ResetDAQ() As Boolean
        'Sends *RST to device
        ' Initializes configuration table to keep it in synch

        ResetDAQ = Me.VisaDev.WriteString("*RST")
        ' Now init the data table and displaying Data Grid View
        ' DataGridView is automatically bound. No need to mess with it directly
        If pTheConfigTable Is Nothing Then
            pTheConfigTable = New DaqControlDataSet.dtDaqConfigurationDataTable

            Do Until pTheConfigTable.Rows.Count = 0
                pTheConfigTable.Rows.Remove(pTheConfigTable.Rows(0))
            Loop

            For TheChan As Integer = 101 To 120
                pTheConfigTable.AdddtDaqConfigurationRow(TheChan,
                                                                              False,
                                                                              "DCV",
                                                                              "Auto",
                                                                              False,
                                                                              1,
                                                                              0,
                                                                              "")
            Next
            For TheChan As Integer = 121 To 122
                pTheConfigTable.AdddtDaqConfigurationRow(TheChan,
                                                                              False,
                                                                              "DCA",
                                                                              "Auto",
                                                                              False,
                                                                              1,
                                                                              0,
                                                                              "")
            Next

        End If

        If ConfigurationDataGridView Is Nothing Then
            ConfigurationDataGridView = New DataGridView
            With ConfigurationDataGridView
                .AllowDrop = False
                .AllowUserToAddRows = False
                .AllowUserToDeleteRows = False
                .AllowUserToOrderColumns = False
                .AllowUserToResizeColumns = True
                .AllowUserToResizeRows = True
                .RowHeadersVisible = False
                ConfigurationDataGridView.DataSource = pTheConfigTable
                ConfigurationDataGridView.ColumnHeadersHeight = ConfigurationDataGridView.ColumnHeadersHeight
                ConfigurationDataGridView.AutoResizeColumns()
                ConfigurationDataGridView.AutoResizeRows()

                For i As Integer = 0 To ConfigurationDataGridView.Columns.GetColumnCount(False) - 1
                    ConfigurationDataGridView.Columns(i).HeaderText = pTheConfigTable.Columns(i).Caption
                    ConfigurationDataGridView.Columns(i).DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
                    ConfigurationDataGridView.Columns(i).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
                    ConfigurationDataGridView.Columns(i).SortMode = DataGridViewColumnSortMode.NotSortable
                Next
                ' Trigger all events needed to set 'ReadOnly'
                For Each row As DataGridViewRow In ConfigurationDataGridView.Rows
                    row.Cells(4).Value = True
                    row.Cells(4).Value = False
                Next

            End With
        End If
        My.Application.DoEvents()
        ' Set grids to default values here
        For RowCnt As Integer = 0 To pTheConfigTable.Rows.Count - 1
            Dim TheRow As DaqControlDataSet.dtDaqConfigurationRow
            TheRow = pTheConfigTable.Rows(RowCnt)
            TheRow.ScalingGain = 1
            TheRow.ScalingOffset = 0
            TheRow.ScalingLabel = ""
            TheRow.Scaling = False
            TheRow.Scan = False
            My.Application.DoEvents()
        Next

    End Function
    Private Sub dgvDaqConfig_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles ConfigurationDataGridView.CellValueChanged
        Static IgnoreClicks As Boolean = False ' Dont double-trigger this event
        If IgnoreClicks Then Return
        IgnoreClicks = True
        Dim dgv As DataGridView = sender

        Dim Sndr As DataGridView = sender
        Sndr.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = System.Drawing.SystemColors.Window

        Try
            Dim Row As DataGridViewRow = dgv.Rows(e.RowIndex)
            Select Case e.ColumnIndex
                Case 0 ' Channel
                Case 1 ' In scan list
                Case 2 ' Function

                Case 3 ' Range
                    Dim Rng As String = Row.Cells(e.ColumnIndex).Value
                    If Not IsNumeric(Rng) Then dgv.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = "Auto"
                Case 4 'Scaling. True = Scaling is active
                    Dim DoScaling As Boolean = Row.Cells(e.ColumnIndex).Value
                    ' Set Gain, Offset, Label boxes. Set to default if not checked
                    Row.Cells(e.ColumnIndex + 1).ReadOnly = Not DoScaling
                    Row.Cells(e.ColumnIndex + 2).ReadOnly = Not DoScaling
                    Row.Cells(e.ColumnIndex + 3).ReadOnly = Not DoScaling
                    If DoScaling Then
                        Row.Cells(e.ColumnIndex + 1).Value = 1
                        Row.Cells(e.ColumnIndex + 2).Value = 0
                        Row.Cells(e.ColumnIndex + 3).Value = ""
                    Else
                        Row.Cells(e.ColumnIndex + 1).Value = 1
                        Row.Cells(e.ColumnIndex + 2).Value = 0
                        Row.Cells(e.ColumnIndex + 3).Value = ""
                    End If
                Case 5 ' Gain
                   ' Row.Cells(e.ColumnIndex) =
                Case 6 ' Offset
                Case 7 ' Label
            End Select
        Catch ex As Exception
            ' Don't do anything on exceptions
            Utility.ErrorHandler_General(ex)
        Finally
            IgnoreClicks = False '' All done
        End Try
    End Sub

    Private Sub dgvDaqConfig_DataError(sender As Object, e As DataGridViewDataErrorEventArgs) Handles ConfigurationDataGridView.DataError
        Dim Sndr As DataGridView = sender
        Utility.ErrorHandler_General(e.Exception)
        Sndr.Rows(e.RowIndex).Cells(e.ColumnIndex).Style.BackColor = Color.Yellow
        e.Cancel = False
    End Sub


    Public Enum enDaqMeasurement
        Volt_DC ' "_" characters get replaced with ":" characters
        Volt_AC
        Curr_DC
        Curr_AC
        Freq
        Res
        FRes    ' 4-wire resistance
        Temp
    End Enum
    Public Sub GetSingleMeasurementsFromLastScan(Channel As Integer, ByRef TheMeasurement As Double)
        ' Returns only the first value scanned
        Dim Values() As Double
        Me.GetMeasurementsFromLastScan(Channel, Values)
        TheMeasurement = Values(0)
    End Sub
    Public Sub GetMeasurementsFromLastScan(Channel As Integer, ByRef Value As Double)
        Call GetMeasurementsFromLastScan(Channel, Value, "")
    End Sub
    Public Sub GetMeasurementsFromLastScan(Channel As Integer, ByRef Value As Double, ByRef Units As String)
        Dim Values() As Double = Nothing
        Dim arUnits() As String = Nothing
        Call GetMeasurementsFromLastScan(Channel, Values, arUnits)
        Try
            Value = Values(0)
            Units = arUnits(0)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
        End Try
    End Sub
    Public Sub GetMeasurementsFromLastScan(ByVal Channel As Integer, ByRef Values() As Double)
        Call GetMeasurementsFromLastScan(Channel, Values, Nothing)
    End Sub
    Public Sub GetMeasurementsFromLastScan(ByVal Channel As Integer, ByRef Values() As Double, ByRef Units() As String)
        On Error Resume Next ' Forget error handling for now TODO--add handling!!
        ' Fetch values presently in the non-volatile memory.
        ' Filter by Channel (since you probably are only interested in one channel)
        ' Assign all values to Values()
        Dim AllRawData As String
        ' Add in channel number, and units to data returned by FETCH? command
        VisaDev.WriteString("FORMat:READing:CHAN On")
        ' And add units (might need it later)
        VisaDev.WriteString("FORMat:READing:UNIT On")
        VisaDev.WriteString("FETCH?")
        AllRawData = VisaDev.ReadString
        'Stop
        ' Parse out
        Dim Delim() As String = {","}
        Values = Nothing
        ' DataPoints elements are {Measurement Units, Channel, Measurement Units, Channel, Measurement Units, Channel, ...}
        ' For example:
        ' AllRawData = "-1.04700000E-06 VDC,101,-7.85000000E-07 VDC,102,-7.58340000E-04 VDC,103,-2.62000000E-07 VDC,104,-1.42851200E-03 VDC,105" & vbLf
        Dim DataPoints() As String = AllRawData.Replace(NL, "").Split(Delim, StringSplitOptions.RemoveEmptyEntries)
        Dim MeasSplit() As String ' Split measurement string into <Measurement> <Units> (space separated)

        For i = 0 To DataPoints.Count - 1 Step 2
            If DataPoints(i + 1) = Channel Then
                ' The previous record is from Channel
                If Values Is Nothing Then
                    ReDim Values(0)
                    ReDim Units(0)
                Else
                    ReDim Preserve Values(UBound(Values) + 1)
                End If
                Delim(0) = " "
                MeasSplit = DataPoints(i).Split(Delim, StringSplitOptions.RemoveEmptyEntries)
                Values(UBound(Values)) = MeasSplit(0) ' Split measurement into value and units (space separated)
                Units(UBound(Units)) = MeasSplit(1).Replace(vbCrLf, "")
            End If
        Next
    End Sub
    Public Function ScanChannels(Count As Integer, Timeoutms As Integer) As Boolean
        ' Monitors each channel in Scan List count number of times
        ' 
        If Count <= 0 Then Count = 1

        Dim NumberOfChannelsInList As Integer
        Dim Cmd As String = "Rout:scan:size?"

        Try
            VisaDev.WriteString(Cmd)
            NumberOfChannelsInList = VisaDev.ReadNumber

            VisaDev.WriteString("TRIGGER:COUNT " & Count.ToString) 'Tell DAQ number of scans to make
            VisaDev.WriteString("INIT") 'Start the scan

            Dim ExpectedNumberOfReadings = NumberOfChannelsInList * Count
            Dim DataPointCount As Integer

            Dim Sw As New Stopwatch
            Sw.Start()
            Do
                Delay(100) ' Not too fast.
                VisaDev.WriteString("data:points?")
                DataPointCount = VisaDev.ReadNumber
                If Sw.ElapsedMilliseconds >= Timeoutms Then
                    Throw New Exception("HP34970A_VISA.DoScanList Timeout Error" & NL &
                                        "Timeout=" & Timeoutms & "ms" & NL &
                                        "Consider increasing timeout value")
                End If
            Loop Until DataPointCount >= ExpectedNumberOfReadings
            Return True

        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            Return False
        End Try

    End Function

    Public Function ConfigureScaling(SingleChannel As Integer, Gain As Double, Offset As Double, Units As String) As Boolean
        Dim ChanList() As Integer = {SingleChannel}
        Return ConfigureScaling(ChanList, Gain, Offset, Units)
    End Function
    Public Function ConfigureScaling(ChannelList() As Integer, Gain As Double, Offset As Double, Units As String) As Boolean
        Try
            Dim Cmd As New System.Text.StringBuilder("CALCulate:SCale:GAIN " & Gain.ToString & ", (@")
            For Each Chan As String In ChannelList
                Cmd.Append(Chan & ",")
            Next
            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)

            Cmd = New System.Text.StringBuilder("CALCulate:SCale:OFFSet " & Offset.ToString & ", (@")
            For Each Chan As String In ChannelList
                Cmd.Append(Chan & ",")
            Next
            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)

            Cmd = New System.Text.StringBuilder("CALCulate:SCale:UNIT " & Chr(34) & Units & Chr(34) & ", (@")
            For Each Chan As String In ChannelList
                Cmd.Append(Chan & ",")
            Next
            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)

            Cmd = New System.Text.StringBuilder("CALCulate:SCale:STATe " & "ON" & ", (@")
            For Each Chan As String In ChannelList
                Cmd.Append(Chan & ",")
            Next
            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)
            ' Now update table showing new scaling functions
            Dim ThisChan As Integer
            Dim ThisRow As DaqControlDataSet.dtDaqConfigurationRow
            For Each ThisChan In ChannelList
                For Each ThisRow In pTheConfigTable.Rows
                    If ThisRow.Channel = ThisChan Then
                        ThisRow.Scaling = True
                        ThisRow.ScalingGain = Gain
                        ThisRow.ScalingOffset = Offset
                        ThisRow.ScalingLabel = Units
                    End If
                Next
            Next
            ConfigureScaling = True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            ConfigureScaling = False
        End Try
    End Function


    Public Function ConfigureChannel(Configuration As enDaqMeasurement, Channel As Integer, Range As String) As Boolean
        Dim ChanList() As Integer = {Channel}
        Return ConfigureChannel(Configuration, ChanList, Range)
    End Function
    Public Function ConfigureChannel(Configuration As enDaqMeasurement, ChannelList() As Integer, Range As String) As Boolean
        Try
            If Range Is Nothing Then Range = "auto"
            If Not IsNumeric(Range) Then Range = "auto"

            Dim Cmd As New System.Text.StringBuilder
            Cmd.Append("CONFigure:" & Configuration.ToString.Replace("_", ":") & "   " & Range & ", (@")
            For Each chan As String In ChannelList
                Cmd.Append(chan.ToString & ",")
            Next

            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)
            ' Update settings in table
            ' Find row with this channel
            Dim ThisChan As Integer
            Dim ThisRow As DaqControlDataSet.dtDaqConfigurationRow
            For Each ThisChan In ChannelList
                For Each ThisRow In pTheConfigTable.Rows
                    If ThisRow.Channel = ThisChan Then
                        ThisRow.Funct = Configuration.ToString
                        ThisRow.Range = Range
                    End If
                Next
            Next
            ConfigureChannel = True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            ConfigureChannel = False
        End Try

    End Function
    Public Function SetScanList(Channel As Integer) As Boolean
        ' Sets a single channel to the scan list
        Dim SingleChannel() As Integer = {Channel}
        Return SetScanList(SingleChannel)
    End Function
    Public Function SetScanList(ChannelList() As Integer) As Boolean
        ' Sets the channels in the scan list
        Try
            Dim Cmd As New System.Text.StringBuilder("Rout:scan (@")
            For Each Chan As String In ChannelList
                Cmd.Append(Chan & ",")
            Next

            Cmd.Remove(Cmd.Length - 1, 1)  ' Remove last comma
            Cmd.Append(")")
            VisaDev.WriteString(Cmd)
            Dim ThisChan As Integer
            Dim ThisRow As DaqControlDataSet.dtDaqConfigurationRow
            ' clear out scan list
            For Each ThisRow In pTheConfigTable.Rows
                ThisRow.Scan = False
                My.Application.DoEvents()
            Next
            For Each ThisChan In ChannelList
                For Each ThisRow In pTheConfigTable.Rows
                    If ThisRow.Channel = ThisChan Then
                        ThisRow.Scan = True
                        My.Application.DoEvents
                    End If
                Next
            Next
            Return True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            Return False
        End Try
    End Function

    Public Function MonitorChannel(Channel As Integer) As Boolean
        ' Sets the front panel to this monitor channel
        MonitorChannel = VisaDev.WriteString(":Rout:Mon:chan " & Channel.ToString) ' No error handling
        MonitorChannel = MonitorChannel And VisaDev.WriteString("Rout:mon:stat on")
    End Function

    Sub WaitforOPC()
        Dim sw As New Stopwatch
        sw.Start()
        Do
            'VisaDev.WriteString("*OPC?")
            'Dim REp As String = VisaDev.ReadString
            'Utility.AddStatusMessage("OPC " & REp & "   " & sw.ElapsedMilliseconds & "ms")
        Loop While sw.ElapsedMilliseconds < 250
    End Sub
    Public Function ReadDCVolts(Channel As Integer, ByRef Volts As Double, ByVal Range As String, ByVal ConfigureChannel As Boolean)
        ' Reads volts from a single channel.
        ' ConfigureChannel saves a little bit of time
        If ConfigureChannel Then Me.ConfigureChannel(enDaqMeasurement.Volt_DC, Channel, Range)
        If ConfigureChannel Then Me.SetScanList(Channel)
        Me.ScanChannels(1, 1000)
        Me.GetSingleMeasurementsFromLastScan(Channel, Volts)
        Return True
    End Function
    Public Function ReadDCAmps(Channel As Integer, ByRef Amps As Double, ByVal Range As String, ByVal ConfigureChannel As Boolean)
        ' Reads volts from a single channel.
        ' ConfigureChannel saves a little bit of time
        If ConfigureChannel Then Me.ConfigureChannel(enDaqMeasurement.Curr_DC, Channel, Range)
        If ConfigureChannel Then Me.SetScanList(Channel)
        Me.ScanChannels(1, 1000)
        Me.GetSingleMeasurementsFromLastScan(Channel, Amps)
        Return True
    End Function

    Public Function CloseSwitch(ByRef Channel As Short) As Boolean
        Try
            Err.Clear()
            Dim MyBoard As Integer = Channel / 100
            MyBoard = MyBoard * 100
            If Me.BoardType(MyBoard) Like "*34903*" Then
                Call VisaDev.WriteString("Rout:Close (@" & Channel & ")")
                CloseSwitch = True
                RaiseEvent SwitchState(Channel, True)
            Else
                Err.Raise(1001, "", "Invalid Channel")
            End If
            Return True
        Catch ex As Exception
            Err.Source = "HP34970A_Visa.CloseSwitch"
            Utility.ErrorHandler_General(ex, False)
            Return False
        End Try
    End Function
    Public Function OpenSwitch(ByRef Channel As Integer) As Boolean
        Try
            Err.Clear()
            Dim MyBoard As Integer = Channel / 100
            MyBoard = MyBoard * 100
            If Me.BoardType(MyBoard) Like "*34903*" Then
                Call VisaDev.WriteString("Rout:Open (@" & Channel & ")")
                OpenSwitch = True
                RaiseEvent SwitchState(Channel, False)
            Else
                Err.Raise(1001, "", "Invalid Channel")
            End If

            Return True
        Catch ex As Exception
            Err.Source = "HP34970A_Visa.OpenSwitch"
            Utility.ErrorHandler_General(ex, False)
            Return False
        End Try
    End Function
    Public Function ToggleSwitch(Channel As Integer) As Boolean
        Try
            'Closed State = True
            Dim ThisState As Boolean
            ToggleSwitch = Me.ReadSwitch(Channel, ThisState)
            If ThisState And ToggleSwitch Then
                ToggleSwitch = Me.OpenSwitch(Channel)
            Else
                ToggleSwitch = Me.CloseSwitch(Channel)
            End If
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            Return False
        End Try
    End Function
    Public Function ReadSwitch(ByVal Channel As Integer, ByRef State As Boolean) As Boolean
        Try
            ReadSwitch = VisaDev.WriteString("Rout:Close? (@" & Channel & ")")
            State = VisaDev.ReadString Like "*1*"

            RaiseEvent SwitchState(Channel, State)

        Catch ex As Exception
            Utility.ErrorHandler_General(ex, False)
            ReadSwitch = False
        End Try
    End Function
    Public Function Ping() As Boolean
        VisaDev.WriteString("*IDN?")
        Ping = VisaDev.ReadString Like "*3497?A*" 'Allow 34970A or 34972A units
    End Function
    Public ReadOnly Property Serial As String
        Get
            'pIDNResponseFields(0) = "Agilent Technologies"
            'pIDNResponseFields(1) = "34972A" Or "34970A"
            'pIDNResponseFields(2) = Serial
            'pIDNResponseFields(3) = Firmware
            Return pIDNResponseFields(2)
        End Get
    End Property
    Private pIDNResponseFields() As String
    Public WithEvents VisaDev As VisaDevice
    Public Function OpenVisaPort(ByVal MyVisaString As String) As Boolean
        '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        ' This function opens a port (the communication between the instrument and computer).
        '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
        ' Check for exceptions
        VisaDev = New VisaDevice
        Dim ExpectedIDN As String = "*3497?A*"
        Try
            ' Get the instrument address form the text box
            OpenVisaPort = VisaDev.OpenPort(MyVisaString)
            If Not OpenVisaPort Then
                Err.Raise(1001, "HP34970A_VISA.OpenVisaPort", "Device Not Found")
            End If
            ' If RS-232, set to remote
            If InStr(MyVisaString, "ASRL") Then
                VisaDev.WriteString("SYSTem:REMote")
            End If

            ' Query instrument ID string
            VisaDev.WriteString("*IDN?")
            Dim IdnStr As String = VisaDev.ReadString
            ' Check if correct instrument is addressed
            If Not IdnStr.ToUpper Like ExpectedIDN Then
                Dim ErrStr As String = "Incorrected instrument detected at " & MyVisaString & NL
                ErrStr &= "Expected: " & ExpectedIDN & NL
                ErrStr &= "Rec'd: " & IdnStr & NL
                Err.Raise(10001, , ErrStr)
            End If
            pIDNResponseFields = IdnStr.Split(",")
            If pIDNResponseFields.GetUpperBound(0) < 3 Then ReDim Preserve pIDNResponseFields(3)

            ' Check and make sure the 34901A Module is installed in slot 100;
            ' Exit program if not correct
            Dim SlotResponse As String, ErrMsg As String, ExpResp As String

            ExpResp = My.Settings.DAQ_Resp_Channel100.ToUpper.Trim
            SlotResponse = Me.BoardType(100)
            If Not SlotResponse.ToUpper Like ExpResp.ToUpper.Trim And Not String.IsNullOrEmpty(ExpResp) Then
                ErrMsg = "Invalid Module in Data Acquisition Unit, Slot " & "100" & NL
                ErrMsg &= "Response: " & SlotResponse.Replace(vbCr, "").Replace(vbLf, "") & NL2
                ErrMsg &= "Expected: " & ExpResp
                Err.Raise(10001, , ErrMsg)
            Else
                'All is OK
                Me.pBoardType100 = SlotResponse.Split(",")
            End If

            ExpResp = My.Settings.DAQ_Resp_Channel200.ToUpper.Trim
            SlotResponse = Me.BoardType(200)
            If Not SlotResponse.ToUpper Like ExpResp.ToUpper.Trim And Not String.IsNullOrEmpty(ExpResp) Then
                ErrMsg = "Invalid Module in Data Acquisition Unit, Slot " & "200" & NL
                ErrMsg &= "Response: " & SlotResponse.Replace(vbCr, "").Replace(vbLf, "") & NL2
                ErrMsg &= "Expected: " & ExpResp
                Err.Raise(10001, , ErrMsg)
            Else
                'All is OK
                Me.pBoardType200 = SlotResponse.Split(",")
            End If

            ExpResp = My.Settings.DAQ_Resp_Channel300.ToUpper.Trim
            SlotResponse = Me.BoardType(300)
            If Not SlotResponse.ToUpper Like ExpResp.ToUpper.Trim And Not String.IsNullOrEmpty(ExpResp) Then
                ErrMsg = "Invalid Module in Data Acquisition Unit, Slot " & "300" & NL
                ErrMsg &= "Response: " & SlotResponse.Replace(vbCr, "").Replace(vbLf, "") & NL2
                ErrMsg &= "Expected: " & ExpResp
                Err.Raise(10001, , ErrMsg)
            Else
                'all is OK
                Me.pBoardType300 = SlotResponse.Split(",")
            End If


            'Check to see if DMM is installed
            Dim GetNum As Integer
            VisaDev.WriteString("INSTrument:DMM:INSTalled?")
            GetNum = VisaDev.ReadNumber(Ivi.Visa.Interop.IEEEASCIIType.ASCIIType_I2, True)
            If GetNum <> 1 Then
                ErrMsg = "'INSTrument:DMM:INSTalled?' returned '" & GetNum.ToString & "'" & NL
                ErrMsg &= "Expected Response: '1'" & NL
                ErrMsg &= "DAQ does not appear to have the DMM installed."
                Err.Raise(1002, , ErrMsg)
            End If
            ' Check if the DMM is enabled; enable if not enabled
            VisaDev.WriteString("INSTrument:DMM?")
            GetNum = VisaDev.ReadNumber(Ivi.Visa.Interop.IEEEASCIIType.ASCIIType_I2)
            If GetNum = 0 Then
                VisaDev.WriteString("INSTrument:DMM ON")
            End If
            VisaDev.ResetDevice()
            VisaDev.Connected = True
            OpenVisaPort = True
        Catch ex As Exception
            ex.Source = "34970A.OpenVisaPort"
            Utility.ErrorHandler_General(ex, My.Settings.DisplayErrorMessagebox)
            'Utility.ErrorHandler_General(ex, True)
            VisaDev.CloseVisaSession()
            OpenVisaPort = False
        End Try
    End Function
    Public Function RestoreDisplay() As Boolean
        '" Clears off all messages and restore to normal operation
        RestoreDisplay = VisaDev.WriteString("display 1")
    End Function
    Public Sub FlashDisplayMessage(TheMessage As String)
        'Flashes message on DAQ screen
        Dim ReadOK As Boolean
        Dim Resp As Boolean
        Dim TheStringNowOnDisplay As String

        VisaDev.WriteString("display 0") ' Turn off display, which means meter measurements will not show up. These messages will still show up
        'Now see if a Message is currently displayed. If so, then show "" message. If not, shuw TheMessage string
        '
        Resp = VisaDev.WriteString("display:text?")
        TheStringNowOnDisplay = VisaDev.ReadString

        ReadOK = Not TheStringNowOnDisplay Is Nothing ' Got a proper response
        If Not ReadOK Then Return
        TheStringNowOnDisplay = TheStringNowOnDisplay.Replace(Chr(34), "").Replace(" ", "").Replace(vbLf, "").Replace(vbCr, "") ' Get rid of quote marks and spaces
        If TheStringNowOnDisplay.Length > 0 Then
            VisaDev.WriteString("display:text " & Chr(34) & Chr(34))    'Turn it off
        Else
            VisaDev.WriteString("display:text " & Chr(34) & TheMessage & Chr(34))
        End If
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
        VisaDev.CloseVisaSession()
    End Sub

    Private Sub VisaDev_VisaOperation(data As String, EventType As String, IsErrorMessage As Boolean) Handles VisaDev.VisaOperation
        'This sub passes the VisaDev events thru to the Power Supply clients, in case anyone is listening
        RaiseEvent VisaOperation(data, EventType, IsErrorMessage)
    End Sub
End Class