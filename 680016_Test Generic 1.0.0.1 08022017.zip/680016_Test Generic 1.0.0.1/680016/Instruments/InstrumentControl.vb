﻿Public Enum enPowerSupplyChannelID As Integer
    None = 0
    ONE = 1
    TWO = 2
End Enum
Public Interface IPowerSupply
    Sub SetMyChannelID(ChanID As String)
    Property MyChannelID As enPowerSupplyChannelID
    Property VoltageSet As Double
    Property CurrentSet As Double
    Property OverVoltageProtect As Double
    Property OverCurrentProtect As Double
    ReadOnly Property OutputVoltage As Double
    ReadOnly Property OutputCurrent As Double
    Property IsEnabled As Boolean

    ReadOnly Property Manufacturer As String
    ReadOnly Property Model As String
    ReadOnly Property Serial As String
    ReadOnly Property Firmware As String

    Event Enabled(NewEnabled As Boolean, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event VoltageSetpoint(VoltageLimit As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event CurrentSetpoint(CurrentLimit As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event VoltageOutputMeasurement(VoltageOutput As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event CurrentOutputMeasurement(CurrentOutput As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event OverVoltageProtectValue(OVP_Volts As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)
    Event OverCurrentProtectValue(OCP_Amps As Double, PSChannel As enPowerSupplyChannelID, ErrorStatus As Boolean)

    Event VisaOperation(Data As String, EventType As String, IsErrorMessage As Boolean)
    Function OpenVisaPort(VisaString As String) As Boolean
    'Shared ReadOnly Property ExpectedIDN As String ' Shared doesn't work with interfaces. Be sure to add this to each base class

    Sub ReadAllParameters()

End Interface
Public Class InstrumentControl
    ' Class managing most of the instruments in the TEST3.
    ' 
    Public bq76940 As New bq769x0_Comm

    Public PsCell As IPowerSupply
    Public PsPack As IPowerSupply
    Public PSAux As IPowerSupply
    Public ELoadCell As Array372xA
    Public EloadPack As Array372xA
    Public RelayDriver As clsRelayDriver
    Public DAQ As HP34970A_VISA
    Public EV2300 As clsEv2300Comm

    Public IOQReport As New IOQReportGenerater

    Public Function Initialize() As Boolean
        Initialize = False
        IOQReport = New IOQReportGenerater
        IOQReport.DataReport.MyStatusDisplay.Name = "IQ / OQ Report"

        IOQReport.DataReport.StartNewTest()  ' Initialize data objects

        'Challenge each device with *IDN.
        ' Assign iPowerSupply to a class depending on *IDN response
        Dim VisaDev As New VisaDevice
        Dim Resp As Boolean
        PsCell = Nothing

        If My.Settings.PowerSupplyCell_IsPopulated Then
            Try
                ' See if XPF works
                PsCell = New SorensenXPFDual
                Resp = PsCell.OpenVisaPort(My.Settings.PowerSupplyCell_VISA)
                If Not Resp Then
                    ' See if BK9201 works
                    PsCell = New BK920x
                    Resp = PsCell.OpenVisaPort(My.Settings.PowerSupplyCell_VISA)
                    If Not Resp Then Throw New System.Exception("Unable to identify Power_Supply_Cell" & NL &
                                                "VISA Alias: " & My.Settings.PowerSupplyCell_VISA)
                End If
                PsCell.SetMyChannelID(My.Settings.PowerSupplyCell_ChannelID)
                IOQReport.CellPowerFound = True
            Catch ex As Exception
                PsCell = Nothing
                Utility.ErrorHandler_General(ex, True)
                IOQReport.CellPowerFound = False
                Initialize = False
            End Try
        End If
        If My.Settings.PowerSupplyPack_IsPopulated Then
            Try
                ' See if XPF works
                PsPack = New SorensenXPFDual
                Resp = PsPack.OpenVisaPort(My.Settings.PowerSupplyPack_VISA)
                If Not Resp Then
                    ' See if BK9201 works
                    PsPack = New BK920x
                    Resp = PsPack.OpenVisaPort(My.Settings.PowerSupplyPack_VISA)
                    If Not Resp Then Throw New System.Exception("Unable to identify Power_Supply_Pack" & NL &
                                                "VISA Alias: " & My.Settings.PowerSupplyPack_VISA)
                End If
                PsPack.SetMyChannelID(My.Settings.PowerSupplyPack_ChannelID)
                IOQReport.PackPowerFound = True
            Catch ex As Exception
                PsPack = Nothing
                Utility.ErrorHandler_General(ex, True)
                Initialize = False
                IOQReport.PackPowerFound = False
            End Try
        End If

        If My.Settings.PowerSupplyAux_IsPopulated Then
            Try
                ' See if XPF works
                Resp = False
                'PSAux = New SorensenXPFDual
                'Resp = PSAux.OpenVisaPort(My.Settings.PowerSupplyAux_VISA)
                If Not Resp Then
                    ' See if BK9201 works
                    PSAux = New BK920x
                    Resp = PSAux.OpenVisaPort(My.Settings.PowerSupplyAux_VISA)
                    If Not Resp Then Throw New System.Exception("Unable to identify Power_Supply_Aux" & NL &
                                                "VISA Alias: " & My.Settings.PowerSupplyAux_VISA)
                End If
                PSAux.SetMyChannelID(My.Settings.PowerSupplyAux_ChannelID)
                IOQReport.AuxPowerFound = True
            Catch ex As Exception
                PSAux = Nothing
                Utility.ErrorHandler_General(ex, True)
                Initialize = False
                IOQReport.AuxPowerFound = False
            End Try
        End If

        If My.Settings.ELoad_Cell_IsPopulated Then
            Try
                ELoadCell = New Array372xA
                If ELoadCell.OpenVisaPort(My.Settings.VISA_ELoadA, "*372*") Then
                    ' ELoadCell.ReadAllParameters()
                Else
                    Throw New System.Exception("Unable to identify Cell E-Load" & NL &
                                               "VISA Alias: " & My.Settings.VISA_ELoadA)
                End If
                IOQReport.CellEloadFound = True
            Catch ex As Exception
                ELoadCell = Nothing
                Utility.ErrorHandler_General(ex, True)
                Initialize = False
                IOQReport.CellEloadFound = False
            End Try
        End If

        If My.Settings.ELoad_Pack_IsPopulated Then
            Try
                EloadPack = New Array372xA
                If EloadPack.OpenVisaPort(My.Settings.VISA_ELoadB, "*372*") Then
                    EloadPack.ReadAllParameters()
                Else
                    Throw New System.Exception("Unable to identify Pack E-Load" & NL &
                                               "VISA Alias: " & My.Settings.VISA_ELoadB)
                End If
                IOQReport.PackEloadFound = True
            Catch ex As Exception
                EloadPack = Nothing
                Utility.ErrorHandler_General(ex, True)
                Initialize = False
                IOQReport.PackEloadFound = False
            End Try
        End If

        Try
            RelayDriver = New clsRelayDriver
            If RelayDriver.FindDevice Then
                RelayDriver.ClearAllBits()
            Else
                Throw New System.Exception("Unable to identify Relay Driver")
            End If
            IOQReport.RelayDriverFound = True
        Catch ex As Exception
            RelayDriver = Nothing
            Utility.ErrorHandler_General(ex, True)
            Initialize = False
            IOQReport.RelayDriverFound = False
        End Try

        Try
            DAQ = New HP34970A_VISA
            If DAQ.OpenVisaPort(My.Settings.VISA_DAQ) Then
                DAQ.ResetDAQ()
            Else
                Throw New System.Exception("Unable to identify Data Acquisition Unit" & NL &
                           "VISA Alias: " & My.Settings.VISA_DAQ)
            End If
            IOQReport.DAQFound = True
        Catch ex As Exception
            DAQ = Nothing
            Utility.ErrorHandler_General(ex, True)
            Initialize = False
            IOQReport.DAQFound = False
        End Try

        ' Initialize EV2400 device
        Try
            Me.EV2300 = New clsEv2300Comm
            Dim EV2300Name As String = "" ' If it's needed in the future
            Resp = Me.EV2300.OpenFirstFreeDevice(EV2300Name)
            If Not Resp Then
                ' Error occurred!!
                Throw New System.Exception("Unable to locate EV2300/EV2400 Device")
            End If
            IOQReport.EV2400Found = True
        Catch ex As Exception
            Utility.ErrorHandler_General(ex, True)
            Initialize = False
            IOQReport.EV2400Found = False
        End Try

        Return IOQReport.AllEquipmentFound
    End Function

    Public Sub CleanUp()
        'Turns off all equipment
        If PsPack IsNot Nothing Then PsPack.IsEnabled = False
        If EloadPack IsNot Nothing Then EloadPack.InputEnabledState = False

        If PsCell IsNot Nothing Then PsCell.IsEnabled = False
        If ELoadCell IsNot Nothing Then ELoadCell.InputEnabledState = False
        If PSAux IsNot Nothing Then Me.PSAux.IsEnabled = False
        If RelayDriver IsNot Nothing Then RelayDriver.ClearAllBits()

    End Sub
End Class
