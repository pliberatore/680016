﻿' Copyright 2017, iTECH
'
' Test groupsto support B00891LFTR "Lifewarmer" Battery PCA Functional Testing


Imports _680016_Generic.clsRelayDriver
Imports _680016_Generic.clsEv2300Comm

Public Class Test_bq78350
    Implements ITestFunction

    Public Sub New()
        Me.MenuIndicator = New ToolStripMenuItem
        Me.MenuIndicator.Text = Me.GroupName
        AddHandler MenuIndicator.Click, AddressOf RunTestGroup
    End Sub

    Public Property GroupName As String = "bq78350-R1 Testing" Implements ITestFunction.GroupName
    Public Property MenuIndicator As ToolStripMenuItem Implements ITestFunction.MenuIndicator
    Public Property TestingData As DataCollection Implements ITestFunction.TestingData
    Private R112Gain As Double = -1  ' Fixture gain. Calculate only once, if needed

    Public Function RunTestGroup() As Boolean Implements ITestFunction.RunTestGroup
        'AFE Test Group
        ' Verifies bq76940 AFE is operating
        Dim TestGroupTimer As New Stopwatch
        TestGroupTimer.Start()

        RunTestGroup = True

        Dim Tstep As Integer = 1
        Dim StepResult As Boolean

        Dim VcellNom As Double = 45.6 ' 3.8V per cell
        Dim VcellLL As Double = 43.3 ' Allow 5% variance
        Dim VcellUL As Double = 47.9

        Dim Resp As EV2300_ErrorCode

        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("T2 - bq78350 Test Group")
                    ' Should verify PCA insertion at this point
                    StepResult = True
                Case 2
                    AddStatusMessage("Power up PCA, " & VcellNom & "V", 1)
                    TestSetControl.PsCell.VoltageSet = VcellNom
                    TestSetControl.PsCell.CurrentSet = 5   ' Enough current
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_PS)
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_EL)
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_A)
                    TestSetControl.DAQ.OpenSwitch(220) ' Be sure to enable 3.3V for wake up
                    TestSetControl.DAQ.CloseSwitch(218) ' Apply Wake up to AFE
                    TestSetControl.DAQ.OpenSwitch(214) ' Protect relay, allow Channel 114 to measure TP14
                    Utility.Delay(200) ' Wait for equipment to settle in
                    TestSetControl.DAQ.OpenSwitch(218)

                    'Configure DAQ for PCA voltage measurments
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 114, 100) ' Cell stack voltage
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 117, 5) ' 2.5V REGOUT
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 116, 5) ' 3.3V
                    Dim ThisScanList() As Integer = {114, 117, 116}
                    TestSetControl.DAQ.SetScanList(ThisScanList)
                    Dim Redo As Boolean
                    ' Allow operator to reposition PCA if anything fails

                    Dim StackVolts As Double, RegOut As Double, V33 As Double
                    Do
                        TestSetControl.DAQ.ScanChannels(3, 1000) ' Scan three channels, one time each
                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(114, StackVolts) ' Get Cell Stack voltage from previous scan
                        StepResult = TestingData.AddMeasurement_Double("T1.0.1", "AFE-Cell Stack Voltage TP15", VcellLL, VcellUL, StackVolts, "V")

                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(117, RegOut) ' Get REGOUT voltage from last scan
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double("T.0.2", "AFE-REGOUT TP35", 2.25, 2.75, RegOut, "V")

                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(116, V33) ' Get 3.3V voltage from last scan
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double("T1.0.3", "AFE-REGOUT J7.1", 3.201, 3.399, V33, "V")

                        Resp = TestSetControl.bq76940.ReadDevice
                        AddStatusMessage("AFE Communications return code " & Resp & " - " & Resp.ToString, 1, Color.Black)
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.4", "AFE-Data Comm", 0, 0, Resp, "code")

                        AddStatusMessage("Record AFE calbration values", 1)
                        Dim TheGain As Integer = TestSetControl.bq76940.DeviceData.ADCGainuV
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.5", "AFE ADC Gain", 365, 396, TheGain, "uV")

                        Dim TheOffset As Integer = TestSetControl.bq76940.DeviceData.ADCOffsetmV
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.6", "AFE ADC Offset", 365, 396, TheOffset, "mV")

                        Redo = False
                        If Not StepResult Then
                            Select Case MsgBox("Initial Voltage Measurements Failed" & NL &
                                               "You may reseat PCA Under Test" & NL &
                                               "Would you like to redo the measurements", MsgBoxStyle.YesNo + MsgBoxStyle.Question, glo.Title)
                                Case MsgBoxResult.Yes
                                    Redo = True
                                Case MsgBoxResult.No
                                    Redo = False
                            End Select
                        End If
                    Loop While Redo

            End Select
            Tstep += 1
            RunTestGroup = RunTestGroup And StepResult Or True
        Loop While RunTestGroup And Tstep < 30
        Utility.AddStatusMessage(Me.GroupName & " Elapsed time=" & TestGroupTimer.ElapsedMilliseconds / 1000 & " seconds", 0, Color.DarkBlue)
    End Function
    Private CurrentChannelList() As Integer = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112} 'This is used in several places
    Private Sub MonitorCurrent(ScanCount As Integer)
        ' Configure twelve DAQ current channels
        ' Records current ScanCount times
        ' Call gets data from TestSetControl.DAQ.GetMeasurementsFromLastScan()
        With TestSetControl.DAQ
            .ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, CurrentChannelList, 0.1) ' Allows up to 1Amp in the fixture current shunts
            .ConfigureScaling(CurrentChannelList, 100, 0, "A")   ' 0.100 ohm current shunts in fixture. Gain = 1/R = 100
            If CurrentChannelList.Contains(112) Then .ConfigureScaling(112, R112Gain, 0, "A") ' R112 is a calibrated channel
            .SetScanList(CurrentChannelList)
            ' Now scan all twelve channels. 
            ' The AFE balancing duty cycle is 70% per 250ms. Be sure to scan enough times to catch balancing current on each cell
            .ScanChannels(ScanCount, 3000) '2000 is was too long!!
            ' That's all. The caller will pull the data from the DAQ
        End With
    End Sub
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements ITestFunction.AddKeyValue
        Throw New NotImplementedException()
    End Function

    Public Function AddKeyValue(KeyName As Integer, KeyValue As Object) As Boolean Implements ITestFunction.AddKeyValue
        Throw New NotImplementedException()
    End Function
End Class
Public Class Test_AFE
    Implements ITestFunction

    Public Sub New()
        Me.MenuIndicator = New ToolStripMenuItem
        Me.MenuIndicator.Text = Me.GroupName
        AddHandler MenuIndicator.Click, AddressOf RunTestGroup
    End Sub

    Public Property GroupName As String = "AFE Testing" Implements ITestFunction.GroupName
    Public Property MenuIndicator As ToolStripMenuItem Implements ITestFunction.MenuIndicator
    Public Property TestingData As DataCollection Implements ITestFunction.TestingData
    Private R112Gain As Double = -1  ' Fixture gain. Calculate only once, if needed

    Public Function RunTestGroup() As Boolean Implements ITestFunction.RunTestGroup
        'AFE Test Group
        ' Verifies bq76940 AFE is operating
        Dim TestGroupTimer As New Stopwatch
        TestGroupTimer.Start()

        RunTestGroup = True

        Dim Tstep As Integer = 1
        Dim StepResult As Boolean

        Dim VcellNom As Double = 45.6 ' 3.8V per cell
        Dim VcellLL As Double = 43.3 ' Allow 5% variance
        Dim VcellUL As Double = 47.9

        Dim Resp As EV2300_ErrorCode

        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("T1 - AFE Test Group")
                    ' Should verify PCA insertion at this point
                    StepResult = True
                Case 2
                    AddStatusMessage("Power up PCA, " & VcellNom & "V", 1)
                    TestSetControl.PsCell.VoltageSet = VcellNom
                    TestSetControl.PsCell.CurrentSet = 5   ' Enough current
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_PS)
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_EL)
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Cell_A)
                    TestSetControl.DAQ.OpenSwitch(220) ' Be sure to enable 3.3V for wake up
                    TestSetControl.DAQ.CloseSwitch(218) ' Apply Wake up to AFE
                    TestSetControl.DAQ.OpenSwitch(214) ' Protect relay, allow Channel 114 to measure TP14
                    Utility.Delay(200) ' Wait for equipment to settle in
                    TestSetControl.DAQ.OpenSwitch(218)

                    'Configure DAQ for PCA voltage measurments
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 114, 100) ' Cell stack voltage
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 117, 5) ' 2.5V REGOUT
                    TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 116, 5) ' 3.3V
                    Dim ThisScanList() As Integer = {114, 117, 116}
                    TestSetControl.DAQ.SetScanList(ThisScanList)
                    Dim Redo As Boolean
                    ' Allow operator to reposition PCA if anything fails

                    Dim StackVolts As Double, RegOut As Double, V33 As Double
                    Do
                        TestSetControl.DAQ.ScanChannels(3, 1000) ' Scan three channels, one time each
                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(114, StackVolts) ' Get Cell Stack voltage from previous scan
                        StepResult = TestingData.AddMeasurement_Double("T1.0.1", "AFE-Cell Stack Voltage TP15", VcellLL, VcellUL, StackVolts, "V")

                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(117, RegOut) ' Get REGOUT voltage from last scan
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double("T.0.2", "AFE-REGOUT TP35", 2.25, 2.75, RegOut, "V")

                        TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(116, V33) ' Get 3.3V voltage from last scan
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double("T1.0.3", "AFE-REGOUT J7.1", 3.201, 3.399, V33, "V")

                        Resp = TestSetControl.bq76940.ReadDevice
                        AddStatusMessage("AFE Communications return code " & Resp & " - " & Resp.ToString, 1, Color.Black)
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.4", "AFE-Data Comm", 0, 0, Resp, "code")

                        AddStatusMessage("Record AFE calbration values", 1)
                        Dim TheGain As Integer = TestSetControl.bq76940.DeviceData.ADCGainuV
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.5", "AFE ADC Gain", 365, 396, TheGain, "uV")

                        Dim TheOffset As Integer = TestSetControl.bq76940.DeviceData.ADCOffsetmV
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Int("T1.0.6", "AFE ADC Offset", 365, 396, TheOffset, "mV")

                        Redo = False
                        If Not StepResult Then
                            Select Case MsgBox("Initial Voltage Measurements Failed" & NL &
                                               "You may reseat PCA Under Test" & NL &
                                               "Would you like to redo the measurements", MsgBoxStyle.YesNo + MsgBoxStyle.Question, glo.Title)
                                Case MsgBoxResult.Yes
                                    Redo = True
                                Case MsgBoxResult.No
                                    Redo = False
                            End Select
                        End If
                    Loop While Redo


                Case 3
                    AddStatusMessage("T1.1 - Verify AFE Cell Voltages", 1)
                    StepResult = Me.DoT01_1 ' Record all values. The flow is cleaner with these measurements in a separate sub

                Case 4
                    Dim RefCurrent As Double
                    Dim RefVolts As Double
                    Dim Scanned() As Double = Nothing
                    Dim ThisScanList() As Integer = {112, 121} ' Only need these two channels
                    If R112Gain = -1 Then
                        AddStatusMessage("T1 - Calculate Fixture Current Shunt Gain", 2)
                        TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Pack_B)
                        TestSetControl.EloadPack.ConstantCurrentSetting = 0.9   ' Ch 121 can only handle up to 1 Amps
                        TestSetControl.EloadPack.InputEnabledState = True
                        TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Curr_DC, 121, "auto")
                        TestSetControl.DAQ.ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 112, "auto") ' TODO Be sure all scaling is cleared off
                        TestSetControl.DAQ.SetScanList(ThisScanList) ' Scan these two channels
                        'TestSetControl.DAQ.ScanChans(Scanned)
                        TestSetControl.DAQ.ScanChannels(1, 1000)
                        Try
                            ' Just in case anything goes wrong ...
                            RefCurrent = Scanned(1)
                        Catch ex As Exception
                            Utility.ErrorHandler_General(ex)
                            RefCurrent = Double.Epsilon ' Avoid Div-by-zero later on
                        End Try
                        Try
                            RefVolts = Scanned(0)
                        Catch ex As Exception
                            Utility.ErrorHandler_General(ex)
                            RefVolts = 0
                        End Try
                    End If
                    TestSetControl.RelayDriver.ClearBit_En(enBitFunctions.Pack_B)
                    TestSetControl.EloadPack.InputEnabledState = False
                    ' Set scaling for all current shunt measurements

                Case 5
                    ' Read the input current of all cells, with no balacing
                    AddStatusMessage("T1.2 - Verify cell currents, balancing off", 1)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H0) 'Be sure the balancing is OFF
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H0)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H0)
                    Call MonitorCurrent(10) 'TODO - Optimize scan count
                    StepResult = True
                    For i As Integer = 1 To 12
                        Dim Tnumber As String = "T1.2." & i.ToString
                        Dim AllMeasures() As Double
                        TestSetControl.DAQ.GetMeasurementsFromLastScan(CurrentChannelList(i - 1), AllMeasures)
                        Dim MaxVal As Double = AllMeasures.Max * 1000 'mAmps
                        Dim LL As Double =
                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double(Tnumber, "Balance Off, Cell Current " & i.ToString, 0, 0, MaxVal, "mA")
                    Next

                Case 6
                    ' Read the input current of all cells, with no balacing
                    AddStatusMessage("T1.3 - Verify cell currents, balancing 1, 5, 9", 1)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H1) 'Enable CB1
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H1) 'Enable CB6
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H1) 'Enable CB11
                    Call MonitorCurrent(10) 'TODO - Optimize scan count
                    Dim LL As Double = 33   ' mA. TODO limits???
                    Dim UL As Double = 37
                    StepResult = True
                    For i As Integer = 1 To 12
                        Dim Tnumber As String = "T1.3." & i.ToString
                        Dim AllMeasures() As Double
                        TestSetControl.DAQ.GetMeasurementsFromLastScan(CurrentChannelList(i - 1), AllMeasures)
                        Dim MaxVal = AllMeasures.Max

                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double(Tnumber, "Balance 1-5-9, Cell Current " & i.ToString, LL, UL, MaxVal, "V")
                    Next

                Case 7
                    ' Read the input current of all cells, with no balacing
                    AddStatusMessage("T1.4 - Verify cell currents, balancing 2, 6, 10", 1)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H2) 'Enable CB2
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H2) 'Enable CB7
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H2) 'Enable CB12
                    Call MonitorCurrent(10) 'TODO - Optimize scan count
                    Dim LL As Double = 33   ' mA. TODO limits???
                    Dim UL As Double = 37
                    StepResult = True
                    For i As Integer = 1 To 12
                        Dim Tnumber As String = "T1.4." & i.ToString
                        Dim AllMeasures() As Double
                        TestSetControl.DAQ.GetMeasurementsFromLastScan(CurrentChannelList(i - 1), AllMeasures)
                        Dim MaxVal = AllMeasures.Max

                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double(Tnumber, "Balance 2-6-10, Cell Current " & i.ToString, LL, UL, MaxVal, "V")
                    Next

                Case 8
                    ' Read the input current of all cells, with no balacing
                    AddStatusMessage("T1.5 - Verify cell currents, balancing 3, 7, 11", 1)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H4) 'Enable CB3
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H4) 'Enable CB8
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H4) 'Enable CB3
                    Call MonitorCurrent(10) 'TODO - Optimize scan count
                    Dim LL As Double = 33   ' mA. TODO limits???
                    Dim UL As Double = 37
                    StepResult = True
                    For i As Integer = 1 To 12
                        Dim Tnumber As String = "T1.5." & i.ToString
                        Dim AllMeasures() As Double
                        TestSetControl.DAQ.GetMeasurementsFromLastScan(CurrentChannelList(i - 1), AllMeasures)
                        Dim MaxVal = AllMeasures.Max

                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double(Tnumber, "Balance 3-7-11, Cell Current " & i.ToString, LL, UL, MaxVal, "V")
                    Next

                Case 9
                    ' Read the input current of all cells, with no balacing
                    AddStatusMessage("T1.6 - Verify cell currents, balancing 4, 8, 12", 1)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H10) 'Enable CB5  TODO ' Check 0x04 CB bits?
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H10) 'Enable CB10
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H10) 'Enable CB15
                    Call MonitorCurrent(10) 'TODO - Optimize scan count
                    Dim LL As Double = 33   ' mA. TODO limits???
                    Dim UL As Double = 37
                    StepResult = True
                    For i As Integer = 1 To 12
                        Dim Tnumber As String = "T1.6." & i.ToString
                        Dim AllMeasures() As Double
                        TestSetControl.DAQ.GetMeasurementsFromLastScan(CurrentChannelList(i - 1), AllMeasures)
                        Dim MaxVal = AllMeasures.Max

                        StepResult = StepResult And
                            TestingData.AddMeasurement_Double(Tnumber, "Balance 4-8-12, Cell Current " & i.ToString, LL, UL, MaxVal, "V")
                    Next
                    AddStatusMessage("T1.6 - Clear all cell balancing", 2)
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H1, &H0) 'Enable CB5  TODO ' Check 0x04 CB bits?
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H2, &H0) 'Enable CB10
                    Resp = TestSetControl.bq76940.WriteByteToRegister(&H3, &H0) 'Enable CB15
                Case 10
                    Dim ELoadSetting As Double = 3.0    ' More would be better
                    Dim TheCurrent As Double
                    Dim CoulCountVolts As Double
                    Dim CoulCountGain As Double

                    AddStatusMessage("T1.7 - Verify AFE Current Calibration", 1)
                    AddStatusMessage("T1.7.x - Set disch to " & ELoadSetting.ToString & " Amps")
                    ' Connect Pack_C to DUT. This will allow current to flow through sense resistor, regardless of FET state. Does not show in DAQ Ch121
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Pack_C)
                    TestSetControl.EloadPack.ConstantCurrentSetting = ELoadSetting   ' More current would be nice
                    TestSetControl.EloadPack.InputEnabledState = True ' Might have to avoid SCD/SCC errors
                    Delay(250)   ' Allow time for AFE to measure current
                    TestSetControl.DAQ.SetScanList(112) ' One channel only
                    TestSetControl.DAQ.ScanChannels(1, 1000)
                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(112, TheCurrent)
                    TestSetControl.bq76940.ReadDevice()
                    CoulCountVolts = TestSetControl.bq76940.DeviceData.CoulCounter_uV / 1000000
                    If CoulCountVolts = 0 Then CoulCountVolts = Double.Epsilon ' no div-by-zero errors!
                    CoulCountGain = TheCurrent / CoulCountVolts
                    ' Now report all values
                    StepResult = TestingData.AddMeasurement_Double("T1.7.1", "AFE Current Cal, Ref Current", -3015.0, -2895.0, TheCurrent * 1000, "mA", "0.0") ' Limits?
                    StepResult = StepResult And
                        TestingData.AddMeasurement_Double("T1.7.2", "AFE Current Cal, AFE Voltage", -9.744, -8.2869, CoulCountVolts * 1000, "mV", "0.0")
                    StepResult = StepResult And
                        TestingData.AddMeasurement_Double("T1.7.3", "AFE Current Cal, CC Gain", 323.3, 343.9, CoulCountGain, "A/V", "0.0")

                Case 11
                    Dim ELoadSetting As Double = 3.0    ' More would be better
                    Dim TheMeasurements() As Double = Nothing ' DAQ needed to measure Ch's 112, 117, 119
                    Dim Current As Double, DFetVolts As Double, CFetVolts As Double

                    AddStatusMessage("T1.8 - Verify AFE FET Control", 1)
                    AddStatusMessage("T1.8 - Enabling FETs", 2)
                    TestSetControl.bq76940.WriteByteToRegister(&H5, &H42)   ' Enable CC and DFET
                    ' Switch pack load to Pack_A to allow current thru FETs
                    TestSetControl.RelayDriver.SetBit_En(enBitFunctions.Pack_A)
                    ' Disconnect Pack_B. This is a Make-Before-Break operation
                    TestSetControl.RelayDriver.ClearBit_En(enBitFunctions.Pack_C)
                    Delay(500) 'It takes the FETs a long time to turn on without the CP_EN bit on the bq76200
                    ' Configure DAQ
                    With TestSetControl.DAQ
                        .ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 112, "auto")
                        .ConfigureScaling(112, R112Gain, 0, "A")
                        .ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 119, "auto")
                        .ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, 118, "auto")
                        Dim ScanList() As Integer = {112, 118, 119}
                        .SetScanList(ScanList)
                        .ScanChannels(2, 2000)
                    End With
                    ' Record values from the last scan
                    StepResult = True

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(112, Current)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.1", "Disch FET On Current", ELoadSetting * 0.95, ELoadSetting * 1.05, Current, "A")

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(119, DFetVolts)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.2", "Disch FET Drive, FET On, TP19", 15, 20, DFetVolts, "V")

                    TestSetControl.bq76940.WriteByteToRegister(&H5, &H40) ' FETs Off
                    Delay(1000) ' The data sheet didn't say how long it takes for the FETs to turn off
                    TestSetControl.DAQ.ScanChannels(1, 2000) ' All channels again

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(112, Current)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.3", "Disch FET Off Current", 0, 0, Current, "A")

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(119, DFetVolts)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.4", "Disch FET Drive, FET Off, TP19", 0, 0.1, DFetVolts, "V")
                    AddStatusMessage("T1.8 - Configure for Charge Testing")
                    TestSetControl.bq76940.WriteByteToRegister(&H5, &H41) 'CC and CFET on
                    With TestSetControl
                        .RelayDriver.SetBit_En(enBitFunctions.Cell_EL)
                        .EloadPack.InputEnabledState = False
                        .PsPack.VoltageSet = 48 ' V. Don't know the setting here...
                        .PsPack.CurrentSet = 1  ' Charge current
                        .RelayDriver.SetBit_En(enBitFunctions.Pack_PS)
                        Delay(500) ' Let FETs get turned on
                        .PsPack.IsEnabled = True ' Now charging
                        Delay(500) ' For good measure ...
                        .DAQ.ScanChannels(1, 2000)
                    End With
                    '
                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(112, Current)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.5", "Charge FET On Current", ELoadSetting * 0.95, ELoadSetting * 1.05, Current, "A")

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(118, CFetVolts)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.6", "Charge FET Drive, FET On, TP17", 15, 20, CFetVolts, "V")

                    TestSetControl.bq76940.WriteByteToRegister(&H5, &H40) ' FETs Off
                    Delay(1000) ' The data sheet didn't say how long it takes for the FETs to turn off
                    TestSetControl.DAQ.ScanChannels(1, 2000) ' All channels again

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(112, Current)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.7", "Charge FET Off Current", 0, 0, Current, "A")

                    TestSetControl.DAQ.GetSingleMeasurementsFromLastScan(118, CFetVolts)
                    StepResult = StepResult And TestingData.AddMeasurement_Double("T1.8.8", "Charge FET Drive, FET Off, TP17", 0, 0.1, CFetVolts, "V")
                Case 13
                    ' AFE COV Alarm Detection
                    ' Raise each cell voltage > threshold, verify charge stops
                    ' Probably not necessary, since the FG will need to do this test
                Case 14
                    ' AFE CUV Alarm Detection
                    ' Lower each cell voltage < threshold, verify discharge stops
                    ' Probably not necessary, since the FG will need to do this test
                Case 15
                    ' Any last minute configuration settings go here
                    ' These may not be necessary, since the bq78350 probably will set these values
            End Select
            Tstep += 1
            RunTestGroup = RunTestGroup And StepResult Or True
        Loop While RunTestGroup And Tstep < 30
        Utility.AddStatusMessage(Me.GroupName & " Elapsed time=" & TestGroupTimer.ElapsedMilliseconds / 1000 & " seconds", 0, Color.DarkBlue)
    End Function
    Private CurrentChannelList() As Integer = {101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112} 'This is used in several places
    Private Sub MonitorCurrent(ScanCount As Integer)
        ' Configure twelve DAQ current channels
        ' Records current ScanCount times
        ' Call gets data from TestSetControl.DAQ.GetMeasurementsFromLastScan()
        With TestSetControl.DAQ
            .ConfigureChannel(HP34970A_VISA.enDaqMeasurement.Volt_DC, CurrentChannelList, 0.1) ' Allows up to 1Amp in the fixture current shunts
            .ConfigureScaling(CurrentChannelList, 100, 0, "A")   ' 0.100 ohm current shunts in fixture. Gain = 1/R = 100
            If CurrentChannelList.Contains(112) Then .ConfigureScaling(112, R112Gain, 0, "A") ' R112 is a calibrated channel
            .SetScanList(CurrentChannelList)
            ' Now scan all twelve channels. 
            ' The AFE balancing duty cycle is 70% per 250ms. Be sure to scan enough times to catch balancing current on each cell
            .ScanChannels(ScanCount, 3000) '2000 is was too long!!
            ' That's all. The caller will pull the data from the DAQ
        End With
    End Sub
    Private Function DoT01_1() As Boolean
        DoT01_1 = True

        TestSetControl.bq76940.ReadDevice() ' Read all values at once
        Dim ThisVoltage As Double
        Dim Tnumber As String
        For CellNum As Integer = 1 To 3
            Tnumber = "T0.1." & CellNum.ToString
            ThisVoltage = TestSetControl.bq76940.DeviceData.Vcell_Volts(CellNum)
            DoT01_1 = DoT01_1 And
                TestingData.AddMeasurement_Double(Tnumber, "AFE Voltage, Cell " & CellNum.ToString, 3.61, 3.99, ThisVoltage, "V")
        Next
        Tnumber = "T0.1.4"
        DoT01_1 = DoT01_1 And
            TestingData.AddMeasurement_Int(Tnumber, "AFE ADC Raw, Cell 4", 0, 10, TestSetControl.bq76940.DeviceData.VCell_Raw(5), "counts")

        For CellNum As Integer = 5 To 8
            Tnumber = "T0.1." & CellNum.ToString
            ThisVoltage = TestSetControl.bq76940.DeviceData.Vcell_Volts(CellNum)
            DoT01_1 = DoT01_1 And
                TestingData.AddMeasurement_Double(Tnumber, "AFE Voltage, Cell " & CellNum.ToString, 3.61, 3.99, ThisVoltage, "V")
        Next
        Tnumber = "T0.1.9"
        DoT01_1 = DoT01_1 And
            TestingData.AddMeasurement_Int(Tnumber, "AFE ADC Raw, Cell 9", 0, 10, TestSetControl.bq76940.DeviceData.VCell_Raw(9), "counts")

        For CellNum As Integer = 10 To 13
            Tnumber = "T0.1." & CellNum.ToString
            ThisVoltage = TestSetControl.bq76940.DeviceData.Vcell_Volts(CellNum)
            DoT01_1 = DoT01_1 And
                TestingData.AddMeasurement_Double(Tnumber, "AFE Voltage, Cell " & CellNum.ToString, 3.61, 3.99, ThisVoltage, "V")
        Next
        Tnumber = "T0.1.14"
        DoT01_1 = DoT01_1 And
            TestingData.AddMeasurement_Int(Tnumber, "AFE ADC Raw, Cell 14", 0, 10, TestSetControl.bq76940.DeviceData.VCell_Raw(5), "counts")

        For CellNum As Integer = 15 To 15
            Tnumber = "T0.1." & CellNum.ToString
            ThisVoltage = TestSetControl.bq76940.DeviceData.Vcell_Volts(CellNum)
            DoT01_1 = DoT01_1 And
                TestingData.AddMeasurement_Double(Tnumber, "AFE Voltage, Cell " & CellNum.ToString, 3.61, 3.99, ThisVoltage, "V")
        Next
    End Function
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements ITestFunction.AddKeyValue
        Throw New NotImplementedException()
    End Function

    Public Function AddKeyValue(KeyName As Integer, KeyValue As Object) As Boolean Implements ITestFunction.AddKeyValue
        Throw New NotImplementedException()
    End Function
End Class