﻿' Copyright 2017, iTECH
' Philip Liberatore
' pliberatore@itecheng.com
Public Class TestSequencer
    ' Class to control test sequencing
    ' Multiple test classes may be run
    ' The sequence is defined at form start up
    Public Event TestSequenceStart()
    Public Event TestSequenceComplete(Result As Boolean)

    Public TestGroupsCollection As Collection

    Private WithEvents RunAllTestsMenuItem As System.Windows.Forms.ToolStripMenuItem
    Private RunSingleGroupMenu As New ToolStripMenuItem
    Public WithEvents btnRunAllTestsButton As System.Windows.Forms.Button
    Public TestingMenuItem As ToolStripMenuItem

    Private btnInProgressText As String = " Test In Progress"
    Private btnReadForStartText As String = "Start Test Sequence"
    Public AllTestingData As DataCollection

    Public Sub InitializeSequencer()
        Me.AllTestingData = New DataCollection ' Start this off new
        TestGroupsCollection = New Collection ' Clear this out

        RunAllTestsMenuItem = New ToolStripMenuItem
        RunAllTestsMenuItem.Checked = False
        RunAllTestsMenuItem.CheckState = CheckState.Unchecked

        RunAllTestsMenuItem.Text = "Run All Tests"
        btnRunAllTestsButton = New Button
        btnRunAllTestsButton.Text = " Run Test Sequence"

        Dim ThisTestGroup As ITestFunction
        'Initialize each test group
        ThisTestGroup = New Test_AFE
        ThisTestGroup.TestingData = AllTestingData
        TestGroupsCollection.Add(ThisTestGroup)

        TestGroupsCollection.Add(ThisTestGroup)
        ' Add more groups here, as needed
        ThisTestGroup = New Test_bq78350
        ThisTestGroup.TestingData = AllTestingData
        TestGroupsCollection.Add(ThisTestGroup)

        ' Build the TESTING menu structure
        TestingMenuItem = New ToolStripMenuItem ' Initialize the top menu item
        TestingMenuItem.Text = "Testing"
        ' Init the RunAll menu
        RunAllTestsMenuItem = New ToolStripMenuItem
        RunAllTestsMenuItem.Text = "Run All Tests"
        TestingMenuItem.DropDownItems.Add(RunAllTestsMenuItem) ' Add to menu
        RunSingleGroupMenu = New ToolStripMenuItem("Run Single Test Group")
        TestingMenuItem.DropDownItems.Add(New ToolStripSeparator)
        TestingMenuItem.DropDownItems.Add(RunSingleGroupMenu) ' Separate out the groups

        ' Add groups to RunSingleMenuGroupMenu
        For Each ThisTestGroup In TestGroupsCollection
            RunSingleGroupMenu.DropDownItems.Add(ThisTestGroup.MenuIndicator)
        Next

    End Sub
    Public Property ButtonTestInProgress As String
        Get
            Return btnInProgressText
        End Get
        Set(value As String)
            btnInProgressText = value
        End Set
    End Property
    Public Property ButtinReadyText As String
        Get
            Return btnReadForStartText
        End Get
        Set(value As String)
            btnReadForStartText = value
        End Set
    End Property
    Public Sub AddTestGroup(NewGroup As ITestFunction)

        NewGroup.MenuIndicator.Checked = False
        NewGroup.MenuIndicator.CheckOnClick = False
        RunAllTestsMenuItem.DropDownItems.Add(NewGroup.MenuIndicator)

        'Add to collection. This object will be executed when RunAll is clicked
        TestGroupsCollection.Add(NewGroup)
    End Sub

    Public Enum enFailAction
        Abort = 1
        Query = 2
        Ignore = 3
    End Enum
    Private pFailAction As enFailAction = enFailAction.Abort
    Public Property FailAction As enFailAction
        Get
            Return pFailAction
        End Get
        Set(value As enFailAction)
            Select Case value
                Case enFailAction.Abort, enFailAction.Ignore, enFailAction.Query
                    pFailAction = value
                Case Else
                    pFailAction = enFailAction.Abort
            End Select
        End Set
    End Property
    Public Sub RunAllPallets(sender As System.Object, e As System.EventArgs) Handles RunAllTestsMenuItem.Click, btnRunAllTestsButton.Click
        Me.RunAllTestsMenuItem.Enabled = False
        Me.btnRunAllTestsButton.Enabled = False
        Me.btnRunAllTestsButton.Text = btnInProgressText
        Utility.ClearStatusMessage()

        Dim TheTest As ITestFunction

        For Each TheTest In Me.TestGroupsCollection
            TheTest.TestingData.TestStatus = DataCollection.enTestStatus.Wait_For_Start
            TheTest.TestingData.MyStatusDisplay.MyDataGridView.Rows.Clear()
        Next
        ' Add Environ records to grid of each Test
        Call Me.InsertEnvironIntoGrids()
        My.Application.DoEvents()

        Dim ReRunTestGroup As Boolean
        Dim TestGroupPassed
        For Each TheTest In Me.TestGroupsCollection
            Do
                ReRunTestGroup = False
                TestGroupPassed = TheTest.RunTestGroup
                AddStatusMessage(TheTest.GroupName & " Complete   Result=" & IIf(TestGroupPassed, "Pass ", "Fail "))
                If Not TestGroupPassed Then
                    Select Case pFailAction
                        Case enFailAction.Abort
                            Exit Do ' Nothing else to do
                        Case enFailAction.Ignore
                            ReRunTestGroup = False
                        Case enFailAction.Query
                            Dim Answer As MsgBoxResult
                            Answer = MsgBox("Test Group Failed. What next?", MsgBoxStyle.AbortRetryIgnore, glo.Title)
                            Select Case Answer
                                Case MsgBoxResult.Abort
                                    Exit Do
                                Case MsgBoxResult.Retry
                                    ReRunTestGroup = True
                                Case MsgBoxResult.Ignore
                                    ' No change
                                Case Else
                                    ' No change
                            End Select
                    End Select
                End If
            Loop While ReRunTestGroup
            Dim FName As String
            FName = glo.Environ.Model & "_" &
                Format(CDate(TheTest.TestingData.StartTimeStamp), "yyyymmdd_HHmmss") & "_" &
                IIf(TestGroupPassed, "P_", "F_") &
                glo.SystemName & ".xml"
            FName = My.Computer.FileSystem.CombinePath("C:\T3SW\TestData", FName)
            TheTest.TestingData.WriteXMLDataFile(FName)
        Next

        Me.RunAllTestsMenuItem.Enabled = True
        Me.btnRunAllTestsButton.Enabled = True
        Me.btnRunAllTestsButton.Text = btnReadForStartText

    End Sub
    Private Sub InsertEnvironIntoGrids()
        Dim TheTestGroup As ITestFunction
        Dim Params() As String = {"*", "", "", "", "", ""}
        For Each TheTestGroup In TestGroupsCollection
            TheTestGroup.TestingData.AddEventRecord("Pod", glo.Environ.Pod)
            TheTestGroup.TestingData.AddEventRecord("Batch", glo.Environ.Batch, 0, False)
            TheTestGroup.TestingData.AddEventRecord("Model", glo.Environ.Model, 0, True)
            TheTestGroup.TestingData.AddEventRecord("EmpID", glo.Environ.EmpID, 0, False)
            TheTestGroup.TestingData.AddEventRecord("System", glo.Environ.System, 0, False)
            TheTestGroup.TestingData.AddEventRecord("Pocket", TestSetControl.DAQ.Serial, 0, False)
            TheTestGroup.TestingData.AddEventRecord("Software", My.Application.Info.AssemblyName, False)
            TheTestGroup.TestingData.AddEventRecord("Version", My.Application.Info.Version.ToString, False)
        Next
    End Sub
End Class
