﻿
Public Class Test_PcaSafety_Optimized
    Implements iTestFunction
    Private WithEvents mnuMenuIndi As ToolStripMenuItem

    Private WithEvents pTestingData As DataCollection

    Public Property TestingData As DataCollection Implements iTestFunction.TestingData
        Get
            Return pTestingData
        End Get
        Set(value As DataCollection)
            pTestingData = value
        End Set
    End Property

    Private pGroupName As String = "Cell Side Voltage Regulation"
    Public Property GroupName As String Implements iTestFunction.GroupName
        Get
            Return pGroupName
        End Get
        Set(value As String)
            pGroupName = value
            Me.mnuMenuIndi.Text = value
            Me.TestingData.MyStatusDisplay.Name = value
        End Set
    End Property

    Public Property MenuIndicator As System.Windows.Forms.ToolStripMenuItem Implements iTestFunction.MenuIndicator
        Get
            mnuMenuIndi.Text = GroupName
            Return mnuMenuIndi
        End Get
        Set(value As System.Windows.Forms.ToolStripMenuItem)
            mnuMenuIndi = value
        End Set
    End Property
    Private KeyValueList As New Collection
    Public Enum MyKeys
        Relay_Cell   'A  Panel Position
        Relay_Pack   'A  Panel Position
        '  
        PSCell_Vset_Nom   '3.5 V Nominal Cell Values
        PSCell_Iset_Nom   '3 V 
        ELCell_Iset_Nom   '0.2 A Cell Current Sink
        '  
        PSPack_Vset_Nom   '4.4 V 
        PSPack_Iset_Nom   '0.5 V 
        ELPack_Iset_Nom   '1 A 
        '  
        Config_101   'Volts  Configure DAQ Channel
        Config_102   'Volts  Configure DAQ Channel
        Config_103   'Volts  Configure DAQ Cha`1nnel
        Config_104   'Ohms  Configure DAQ Channel
        Config_105   'Ohms  Configure DAQ Channel
        '  
        Chan_Vcell   '101  DAQ Channel
        Chan_Vpack   '102  DAQ Channel
        Chan_ID   '103  DAQ Channel
        Chan_Fuse   '104  DAQ Channel
        Chan_FeedThru   '105  DAQ Channel
        '  
        COV_PsCell_Vmax   '4.35 V Cell Voltage for COV
        COV_PsCell_Step   '0.1 V  Step in this increment from nominal
        COV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_COV   '0.05 A Max allowable pack charge current during COV
        '  
        CUV_PsCell_Vmin   '4.35 V Cell Voltage for CUV
        CUV_PsCell_Step   '0.1 V  Step in this increment from nominal
        CUV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_CUV   '0.05 A Max allowable pack discharge current during CUV
        '  
        ElPack_OCD_Step   '0.1 A Step up load from nominal
        ElPack_OCD_Dwell   '100 msec 
        ElPack_OCD_min   '0.7 A Test limits. Mininum pack current that caused the OCD fault
        ElPack_OCD_Max   '1.3 A Test limits. Maximum pack current that caused the OCD fault
        '  
        PsPack_OCC_Step   '0.1 A Step up charge current from nominal
        PsPack_OCC_Dwell   '100 msec 
        PsPack_OCC_min   '0.7 A Test limits. Mininum pack current that caused the OCC fault
        PsPack_OCC_Max   '1.3 A Test limits. Maximum pack current that caused the OCC fault

    End Enum
    Public Function AddKeyValue(KeyName As Integer, Value As Object) As Boolean Implements iTestFunction.AddKeyValue
        Dim KeyEnum As MyKeys = KeyName
        Return AddKeyValue(KeyEnum.ToString, Value)
    End Function
    Private Function GetValue(KeyItem As MyKeys) As Object
        Try
            Return KeyValueList(KeyItem.ToString)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            Return Nothing
        End Try
    End Function
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements iTestFunction.AddKeyValue
        ' Add a key-value relationship
        ' Such as
        '       "VpackChan" = 101
        '       "CellBalanceHigh" = 204
        ' This allows the script to access the members by key name, rather than directly with number
        ' Example:
        '   Dim a As Integer = KeyValueList("VpackChan")
        ' Be sure KeyName appears in the Enum list
        '   Return False if it isn't, indicating an invalid key name
        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)

        If Utility.ArrayContains(KeyNameList, KeyName) Then
            If KeyValueList.Contains(KeyName) Then KeyValueList.Remove(KeyName)
            KeyValueList.Add(KeyValue, KeyName)
            Return True
        Else
            Return False
        End If

    End Function
    Public Function ListMyValues() As Data.DataTable
        On Error Resume Next
        ListMyValues = New Data.DataTable

        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)
        Dim KeyValueList() As Integer = [Enum].GetValues(TheEnum.GetType)

        With ListMyValues
            .Columns.Clear()
            .Columns.Add("Key")
            .Columns.Add("Value")
            .Columns.Add("EnumVal")

            For i As Integer = 0 To UBound(KeyNameList)
                TheEnum = i
                Dim TheObj As Object = Me.GetValue(TheEnum)
                Dim Fields() As String = {TheEnum.ToString, TheObj, i.ToString}
                .Rows.Add(Fields)
            Next
        End With
    End Function
    Public MyCellRelayBit As clsRelayDriver.enBitFunctions
    Public myPackRelayBit As clsRelayDriver.enBitFunctions

    Public Function RunTest() As Boolean Implements iTestFunction.RunTestGroup
        ' Executes the set sequence
        ' Just a ten second run of random numbers
        Me.pTestingData.StartNewTest()

        My.Application.DoEvents()

        Dim Rnd As New Random
        Dim StepResult As Boolean = True
        Dim Tstep As Integer = 1
        Dim SomeNumber As Double
        Dim CellBit As Integer
        Dim PackBit As Integer
        Dim CellVoltage As Double = 10    'V
        Dim CellSink As Double = 5  'A
        Dim PackVoltage As Double
        Dim PackCurrent As Double = 2 'A

        Dim Voltages() As Double = {3, 6, 9, 12, 15, 20}
        Dim Loads() As Double = {1, 2, 3}

        Dim ConfigMeter As Boolean = True
        RunTest = True

        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("Starting " & Me.pGroupName)
                    AddStatusMessage("Configuring Equipment")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.IsEnabled = False
                        .ELoadCell.InputEnabledState = False
                        .EloadPack.InputEnabledState = False
                        .RelayDriver.ClearAllBits()
                        Delay(200)

                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '.RelayDriver.SetBit(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(500)  ' Let the relays settle down
                        .RelayDriver.SetBit_En(MyCellRelayBit)
                        .RelayDriver.SetBit_En(myPackRelayBit)
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = Me.GetValue(MyKeys.PSCell_Iset_Nom)
                        .ELoadCell.ConstantCurrentSetting = GetValue(MyKeys.ELCell_Iset_Nom)

                        .PsPack.IsEnabled = False
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsPack.CurrentSet = Me.GetValue(MyKeys.PSPack_Iset_Nom)
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                    End With
                    Delay(200)
                    My.Application.DoEvents()
                Case 2
                    AddErrorMessage("Enable Cell Simulator. Wake up PCA")
                    With TestSetControl
                        .ELoadCell.InputEnabledState = True
                        Delay(100)
                        .PsCell.IsEnabled = True
                        .EloadPack.ConstantCurrentSetting = 0.1
                        .EloadPack.InputEnabledState = False
                        .PsPack.IsEnabled = True
                        Delay(200)

                        .PsPack.IsEnabled = True
                        Delay(300)
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom) + 0.3
                        'With .RelayDriver
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '    Delay(1000)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        'End With
                        ' Charge current now flowing
                        Delay(200)   ' wait a bit to set up
                        Dim IChgNom As Double
                        My.Application.DoEvents()
                        Dim VcellNom As Double
                        Dim sw As New Stopwatch
                        sw.Start()
                        Do
                            IChgNom = .PsPack.OutputCurrent
                            IChgNom = IIf(IChgNom < 0, 0, IChgNom)
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), VcellNom, "auto", True)
                            ' Record nominal values
                            StepResult = Me.TestingData.AddMeasurement_Double("T01", "Cell Voltage Nominal", 3.2, 3.6, VcellNom, "V", "0.000")
                            StepResult = StepResult And
                                Me.TestingData.AddMeasurement_Double("T03", "Charge Current Nominal", 0.15, 0.25, IChgNom, "A", "0.000")
                        Loop Until StepResult Or sw.ElapsedMilliseconds > 2000
                    End With
                Case 3
                    AddStatusMessage("Cell OverVoltage Test. Step up Vcell")
                    Dim Vcell As Double
                    Dim Ichg As Double
                    Dim ChargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 4.0    'starting point for COV
                    Dim FirstDaq As Boolean = True
                    With TestSetControl
                        ' Ramp up Charger Voltage limit
                        .PsPack.VoltageSet = 4.5
                        ' Raise cell voltage
                        .PsCell.VoltageSet = 4.35
                        ' Wait three seconds for COV to stop charge current
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(100)
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", FirstDaq)
                            Ichg = .PsPack.OutputCurrent
                            If Ichg < 0 Then Ichg = 0
                            FirstDaq = False
                            StepResult = TestingData.AddMeasurement_Double("T04", "COV Cell Voltage", 4.2, 4.4, Vcell, "V")
                            StepResult = StepResult And
                                TestingData.AddMeasurement_Double("T05", "COV Current", 0, Me.GetValue(MyKeys.Pack_Current_COV), Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With

                    'Do
                    '    VsetCell += Me.GetValue(MyKeys.COV_PsCell_Step)
                    '    TestSetControl.PsCell.VoltageSet = VsetCell
                    '    TestSetControl.PsPack.VoltageSet = VsetCell + 0.5
                    '    Delay(Me.GetValue(MyKeys.COV_PsCell_Dwell))
                    '    Ichg = TestSetControl.PsPack.OutputCurrent
                    '    Ichg = IIf(Ichg < 0, 0, Ichg)
                    '    TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                    '    CellVoltageIsPass = TestingData.AddMeasurement_Double("T04", "COV Cell Voltage", 4.2, 4.4, Vcell, "V")
                    '    ChargeIsPass = TestingData.AddMeasurement_Double("T05", "COV Current", 0, Me.GetValue(MyKeys.Pack_Current_COV), Ichg, "A")
                    'Loop Until ChargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.COV_PsCell_Vmax)
                    'StepResult = StepResult And CellVoltageIsPass And ChargeIsPass
                Case 4
                    AddStatusMessage("COV Recovery Test")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        Delay(200)
                        .EloadPack.InputEnabledState = True
                        Delay(100)
                        .EloadPack.InputEnabledState = False
                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.IsEnabled = True
                    End With
                    Delay(500)
                    Dim Irecover As Double = TestSetControl.PsPack.OutputCurrent
                    Irecover = IIf(Irecover < 0, 0, Irecover)
                    StepResult = TestingData.AddMeasurement_Double("T06", "COV Recovery Current", 0.15, 0.25, Irecover, "A")

                Case 5
                    AddStatusMessage("Nominal Discharge Test")
                    Dim IDsch As Double
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .ELoadCell.ConstantCurrentSetting = 0.3 'Take some load off the cell power supply
                        .EloadPack.ConstantCurrentSetting = Iset
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(100)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        IDsch = .EloadPack.GetInputCurrent()
                    End With
                    StepResult = TestingData.AddMeasurement_Double("T07", "Discharge Current Nominal", Iset - 0.1, Iset + 0.1, IDsch, "A")
                Case 6
                    AddStatusMessage("Cell UnderVoltage Testing. Step Down Vcell")
                    Dim Vcell As Double
                    Dim IDsch As Double
                    Dim DischargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 3.0    'starting point for COV

                    Do
                        VsetCell -= Me.GetValue(MyKeys.COV_PsCell_Step)
                        VsetCell = 2.5
                        TestSetControl.PsCell.VoltageSet = VsetCell

                        Delay(Me.GetValue(MyKeys.CUV_PsCell_Dwell))

                        IDsch = TestSetControl.EloadPack.GetInputCurrent
                        IDsch = IIf(IDsch < 0, 0, IDsch)
                        TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                        CellVoltageIsPass = TestingData.AddMeasurement_Double("T08", "CUV Cell Voltage", 2.4, 2.6, Vcell, "V")
                        DischargeIsPass = TestingData.AddMeasurement_Double("T09", "CUV Current", 0, Me.GetValue(MyKeys.Pack_Current_CUV), IDsch, "A")
                    Loop Until DischargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.CUV_PsCell_Vmin)
                    StepResult = StepResult And CellVoltageIsPass And DischargeIsPass
                Case 7
                    AddErrorMessage("Cell Undervoltage Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    TestSetControl.PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                    TestSetControl.PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                    Delay(100)   ' This might be enough to bring it back up
                    TestSetControl.PsPack.IsEnabled = True
                    Delay(100)
                    TestSetControl.PsPack.IsEnabled = False
                    TestSetControl.EloadPack.ConstantCurrentSetting = Iset
                    TestSetControl.EloadPack.InputEnabledState = True
                    Delay(500)
                    Dim CUVRecoveryAmps As Double = TestSetControl.EloadPack.GetInputCurrent
                    StepResult = TestingData.AddMeasurement_Double("T10", "CUV Recovery Current", Iset - 0.1, Iset + 0.1, CUVRecoveryAmps, "A")
                Case 9
                    AddStatusMessage("Overcurrent-Discharge")
                    ' Set load to 1.4Amps
                    ' wait for timeout
                    Dim MaxLoad As Double = 1.4 ' Constant
                    Dim Iset As Double = TestSetControl.EloadPack.ConstantCurrentSetting
                    Iset = 1.0
                    Dim Idisch As Double
                    Dim Vpack As Double
                    Dim FirstTime As Boolean = True
                    Dim Sw As New Stopwatch
                    Sw.Start()
                    Do
                        Iset += 0.1
                        If Iset > MaxLoad Then Iset = MaxLoad
                        TestSetControl.EloadPack.ConstantCurrentSetting = Iset
                        Delay(50)
                        Idisch = TestSetControl.EloadPack.GetInputCurrent
                        StepResult = TestingData.AddMeasurement_Double("T11", "Disch Current @ 1400mA", 0, 0.01, Idisch, "A")
                    Loop Until StepResult Or Sw.ElapsedMilliseconds > 5000
                    StepResult = StepResult And
                        TestingData.AddMeasurement_Double("T12", "OCD-Disch Trip", 0.7, 1.4, Iset, "A")

                    'Dim IPackMAX As Double = 3.0 'Quit trying if it doesn't get this far
                    'Dim Ipack As Double
                    'Dim Vpack As Double
                    'Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    'With TestSetControl
                    '    .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                    '    .PsCell.CurrentSet = 4.0  'Lots of current needed for OCD/OCC Testing
                    '    .ELoadCell.ConstantCurrentSetting = 0.3   'Not much sink needed for OCD
                    '    'Ramp up disch current until Ipack=0 or Ipack>3.8
                    '    Do
                    '        Iset += GetValue(MyKeys.ElPack_OCD_Step)
                    '        Iset = 1.4   ' Set to max value right off the bat
                    '        .EloadPack.ConstantCurrentSetting = Iset
                    '        Delay(GetValue(MyKeys.CUV_PsCell_Dwell))
                    '        .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vpack), Vpack, "auto", False)
                    '        Ipack = .EloadPack.GetInputCurrent
                    '        StepResult = TestingData.AddMeasurement_Double("T11", "OCD-Disch Trip", GetValue(MyKeys.ElPack_OCD_min), GetValue(MyKeys.ElPack_OCD_Max), Iset, "A")
                    '        StepResult = StepResult And _
                    '            TestingData.AddMeasurement_Double("T12", "OCD-Disch Current", 0, GetValue(MyKeys.ElPack_OCD_Max), Ipack, "A")
                    '    Loop Until StepResult Or Iset > Me.GetValue(MyKeys.ElPack_OCD_Max) + 0.5
                    '    .EloadPack.InputEnabledState = False
                    'End With
                Case 10
                    AddStatusMessage("OCD Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .PsPack.IsEnabled = True
                        Delay(500)
                        .PsPack.IsEnabled = False
                        .EloadPack.InputEnabledState = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim IDisch As Double = .EloadPack.GetInputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T13", "OCD Recovery Current", Iset - 0.1, Iset + 0.1, IDisch, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                        .EloadPack.InputEnabledState = False
                    End With
                Case 12
                    AddStatusMessage("Overcurrent-Charge")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Iset_Nom) + 0.6
                    Dim Ichg As Double
                    With TestSetControl
                        .EloadPack.InputEnabledState = False
                        .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = 4.0  ' Should be enough
                        .ELoadCell.ConstantCurrentSetting = 3.8 'Amps

                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.CurrentSet = Iset
                        .PsPack.IsEnabled = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Iset += GetValue(MyKeys.PsPack_OCC_Step)
                            If Iset > GetValue(MyKeys.PsPack_OCC_Max) Then Iset = GetValue(MyKeys.PsPack_OCC_Max)
                            .PsPack.CurrentSet = Iset
                            Delay(GetValue(MyKeys.PsPack_OCC_Dwell))
                            Ichg = .PsPack.OutputCurrent
                            If Ichg < 0 Then Ichg = 0
                            StepResult = TestingData.AddMeasurement_Double("T14", "OCC-Charge Trip", GetValue(MyKeys.PsPack_OCC_min), GetValue(MyKeys.PsPack_OCC_Max), Iset, "A")
                            StepResult = StepResult And
                                TestingData.AddMeasurement_Double("T15", "OCC-Charge Current", 0, 0.05, Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 5000
                    End With

                Case 13
                    AddStatusMessage("OCC Recovery")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Vset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        .EloadPack.InputEnabledState = False
                        Dim Sw As New Stopwatch
                        Dim IchgSet As Double = GetValue(MyKeys.PSPack_Iset_Nom)
                        .PsPack.CurrentSet = IchgSet
                        .PsPack.IsEnabled = True
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim Ichg As Double = .PsPack.OutputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T16", "OCC Recovery Current", IchgSet - 0.1, IchgSet + 0.1, Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With
            End Select
            My.Application.DoEvents()
            Tstep += 1
            RunTest = RunTest And StepResult
        Loop While Tstep < 20 And StepResult
        TestSetControl.CleanUp()
        My.Application.DoEvents()
        pTestingData.EndTest()
        Return pTestingData.TestStatus = DataCollection.enTestStatus.TEST_PASS
    End Function
    Private Sub ExecuteTestOnClick(sender As Object, e As EventArgs) Handles mnuMenuIndi.Click
        Call Me.RunTest()
    End Sub
    Public Sub New()
        mnuMenuIndi = New ToolStripMenuItem
        mnuMenuIndi.Text = Me.GroupName
        mnuMenuIndi.CheckOnClick = False
        Me.TestingData = New DataCollection
    End Sub
End Class
Public Class Test_PcaSafety_Optimized_NumberTwo
    Implements iTestFunction
    Private WithEvents mnuMenuIndi As ToolStripMenuItem

    Private pTestingData As New DataCollection

    Public Property TestingData As DataCollection Implements iTestFunction.TestingData
        Get
            Return pTestingData
        End Get
        Set(value As DataCollection)
            pTestingData = value
        End Set
    End Property
    Private pGroupName As String = "Cell Side Voltage Regulation"
    Public Property GroupName As String Implements iTestFunction.GroupName
        Get
            Return pGroupName
        End Get
        Set(value As String)
            pGroupName = value
            Me.mnuMenuIndi.Text = value
            Me.TestingData.MyStatusDisplay.Name = value
        End Set
    End Property

    Public Property MenuIndicator As System.Windows.Forms.ToolStripMenuItem Implements iTestFunction.MenuIndicator
        Get
            mnuMenuIndi.Text = GroupName
            Return mnuMenuIndi
        End Get
        Set(value As System.Windows.Forms.ToolStripMenuItem)
            mnuMenuIndi = value
        End Set
    End Property
    Private KeyValueList As New Collection
    Public Enum MyKeys
        Relay_Cell   'A  Panel Position
        Relay_Pack   'A  Panel Position
        '  
        PSCell_Vset_Nom   '3.5 V Nominal Cell Values
        PSCell_Iset_Nom   '3 V 
        ELCell_Iset_Nom   '0.2 A Cell Current Sink
        '  
        PSPack_Vset_Nom   '4.4 V 
        PSPack_Iset_Nom   '0.5 V 
        ELPack_Iset_Nom   '1 A 
        '  
        Config_101   'Volts  Configure DAQ Channel
        Config_102   'Volts  Configure DAQ Channel
        Config_103   'Volts  Configure DAQ Cha`1nnel
        Config_104   'Ohms  Configure DAQ Channel
        Config_105   'Ohms  Configure DAQ Channel
        '  
        Chan_Vcell   '101  DAQ Channel
        Chan_Vpack   '102  DAQ Channel
        Chan_ID   '103  DAQ Channel
        Chan_Fuse   '104  DAQ Channel
        Chan_FeedThru   '105  DAQ Channel
        '  
        COV_PsCell_Vmax   '4.35 V Cell Voltage for COV
        COV_PsCell_Step   '0.1 V  Step in this increment from nominal
        COV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_COV   '0.05 A Max allowable pack charge current during COV
        '  
        CUV_PsCell_Vmin   '4.35 V Cell Voltage for CUV
        CUV_PsCell_Step   '0.1 V  Step in this increment from nominal
        CUV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_CUV   '0.05 A Max allowable pack discharge current during CUV
        '  
        ElPack_OCD_Step   '0.1 A Step up load from nominal
        ElPack_OCD_Dwell   '100 msec 
        ElPack_OCD_min   '0.7 A Test limits. Mininum pack current that caused the OCD fault
        ElPack_OCD_Max   '1.3 A Test limits. Maximum pack current that caused the OCD fault
        '  
        PsPack_OCC_Step   '0.1 A Step up charge current from nominal
        PsPack_OCC_Dwell   '100 msec 
        PsPack_OCC_min   '0.7 A Test limits. Mininum pack current that caused the OCC fault
        PsPack_OCC_Max   '1.3 A Test limits. Maximum pack current that caused the OCC fault

    End Enum
    Public Function AddKeyValue(KeyName As Integer, Value As Object) As Boolean Implements iTestFunction.AddKeyValue
        Dim KeyEnum As MyKeys = KeyName
        Return AddKeyValue(KeyEnum.ToString, Value)
    End Function
    Private Function GetValue(KeyItem As MyKeys) As Object
        Try
            Return KeyValueList(KeyItem.ToString)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            Return Nothing
        End Try
    End Function
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements iTestFunction.AddKeyValue
        ' Add a key-value relationship
        ' Such as
        '       "VpackChan" = 101
        '       "CellBalanceHigh" = 204
        ' This allows the script to access the members by key name, rather than directly with number
        ' Example:
        '   Dim a As Integer = KeyValueList("VpackChan")
        ' Be sure KeyName appears in the Enum list
        '   Return False if it isn't, indicating an invalid key name
        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)

        If Utility.ArrayContains(KeyNameList, KeyName) Then
            If KeyValueList.Contains(KeyName) Then KeyValueList.Remove(KeyName)
            KeyValueList.Add(KeyValue, KeyName)
            Return True
        Else
            Return False
        End If

    End Function
    Public Function ListMyValues() As Data.DataTable
        On Error Resume Next
        ListMyValues = New Data.DataTable

        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)
        Dim KeyValueList() As Integer = [Enum].GetValues(TheEnum.GetType)

        With ListMyValues
            .Columns.Clear()
            .Columns.Add("Key")
            .Columns.Add("Value")
            .Columns.Add("EnumVal")

            For i As Integer = 0 To UBound(KeyNameList)
                TheEnum = i
                Dim TheObj As Object = Me.GetValue(TheEnum)
                Dim Fields() As String = {TheEnum.ToString, TheObj, i.ToString}
                .Rows.Add(Fields)
            Next
        End With
    End Function
    Public MyCellRelayBit As clsRelayDriver.enBitFunctions
    Public myPackRelayBit As clsRelayDriver.enBitFunctions

    Public Function RunTest() As Boolean Implements iTestFunction.RunTestGroup
        ' Executes the set sequence
        ' Just a ten second run of random numbers
        Me.pTestingData.StartNewTest()

        My.Application.DoEvents()

        Dim Rnd As New Random
        Dim StepResult As Boolean = True
        Dim Tstep As Integer = 1
        Dim SomeNumber As Double
        Dim CellBit As Integer
        Dim PackBit As Integer
        Dim CellVoltage As Double = 10    'V
        Dim CellSink As Double = 5  'A
        Dim PackVoltage As Double
        Dim PackCurrent As Double = 2 'A

        Dim Voltages() As Double = {3, 6, 9, 12, 15, 20}
        Dim Loads() As Double = {1, 2, 3}

        Dim ConfigMeter As Boolean = True
        RunTest = True

        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("Starting " & Me.pGroupName)
                    AddStatusMessage("Configuring Equipment")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.IsEnabled = False
                        .ELoadCell.InputEnabledState = False
                        .EloadPack.InputEnabledState = False
                        .RelayDriver.ClearAllBits()
                        Delay(200)

                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '.RelayDriver.SetBit(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(500)  ' Let the relays settle down
                        .RelayDriver.SetBit_En(MyCellRelayBit)
                        .RelayDriver.SetBit_En(myPackRelayBit)
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = Me.GetValue(MyKeys.PSCell_Iset_Nom)
                        .ELoadCell.ConstantCurrentSetting = GetValue(MyKeys.ELCell_Iset_Nom)

                        .PsPack.IsEnabled = False
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsPack.CurrentSet = Me.GetValue(MyKeys.PSPack_Iset_Nom)
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                    End With
                    Delay(200)
                    My.Application.DoEvents()
                Case 2
                    AddErrorMessage("Enable Cell Simulator. Wake up PCA")
                    With TestSetControl
                        .ELoadCell.InputEnabledState = True
                        Delay(100)
                        .PsCell.IsEnabled = True
                        .EloadPack.ConstantCurrentSetting = 0.1
                        .EloadPack.InputEnabledState = False
                        .PsPack.IsEnabled = True
                        Delay(200)

                        .PsPack.IsEnabled = True
                        Delay(300)
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom) + 0.3
                        'With .RelayDriver
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '    Delay(1000)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        'End With
                        ' Charge current now flowing
                        Delay(200)   ' wait a bit to set up
                        Dim IChgNom As Double
                        My.Application.DoEvents()
                        Dim VcellNom As Double
                        Dim sw As New Stopwatch
                        sw.Start()
                        Do
                            IChgNom = .PsPack.OutputCurrent
                            IChgNom = IIf(IChgNom < 0, 0, IChgNom)
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), VcellNom, "auto", True)
                            ' Record nominal values
                            StepResult = Me.TestingData.AddMeasurement_Double("T01", "Cell Voltage Nominal", 3.2, 3.6, VcellNom, "V", "0.000")
                            StepResult = StepResult And
                                Me.TestingData.AddMeasurement_Double("T03", "Charge Current Nominal", 0.15, 0.25, IChgNom, "A", "0.000")
                        Loop Until StepResult Or sw.ElapsedMilliseconds > 2000
                    End With
                Case 3
                    AddStatusMessage("Cell OverVoltage Test. Step up Vcell")
                    Dim Vcell As Double
                    Dim Ichg As Double
                    Dim ChargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 4.0    'starting point for COV
                    Dim FirstDaq As Boolean = True
                    With TestSetControl
                        ' Ramp up Charger Voltage limit
                        .PsPack.VoltageSet = 4.5
                        ' Raise cell voltage
                        .PsCell.VoltageSet = 4.35
                        ' Wait three seconds for COV to stop charge current
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(100)
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", FirstDaq)
                            Ichg = .PsPack.OutputCurrent
                            If Ichg < 0 Then Ichg = 0
                            FirstDaq = False
                            StepResult = TestingData.AddMeasurement_Double("T04", "COV Cell Voltage", 4.2, 4.4, Vcell, "V")
                            StepResult = StepResult And
                                TestingData.AddMeasurement_Double("T05", "COV Current", 0, Me.GetValue(MyKeys.Pack_Current_COV), Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With

                    'Do
                    '    VsetCell += Me.GetValue(MyKeys.COV_PsCell_Step)
                    '    TestSetControl.PsCell.VoltageSet = VsetCell
                    '    TestSetControl.PsPack.VoltageSet = VsetCell + 0.5
                    '    Delay(Me.GetValue(MyKeys.COV_PsCell_Dwell))
                    '    Ichg = TestSetControl.PsPack.OutputCurrent
                    '    Ichg = IIf(Ichg < 0, 0, Ichg)
                    '    TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                    '    CellVoltageIsPass = TestingData.AddMeasurement_Double("T04", "COV Cell Voltage", 4.2, 4.4, Vcell, "V")
                    '    ChargeIsPass = TestingData.AddMeasurement_Double("T05", "COV Current", 0, Me.GetValue(MyKeys.Pack_Current_COV), Ichg, "A")
                    'Loop Until ChargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.COV_PsCell_Vmax)
                    'StepResult = StepResult And CellVoltageIsPass And ChargeIsPass
                Case 4
                    AddStatusMessage("COV Recovery Test")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        Delay(200)
                        .EloadPack.InputEnabledState = True
                        Delay(100)
                        .EloadPack.InputEnabledState = False
                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.IsEnabled = True
                    End With
                    Delay(500)
                    Dim Irecover As Double = TestSetControl.PsPack.OutputCurrent
                    Irecover = IIf(Irecover < 0, 0, Irecover)
                    StepResult = TestingData.AddMeasurement_Double("T06", "COV Recovery Current", 0.15, 0.25, Irecover, "A")

                Case 5
                    AddStatusMessage("Nominal Discharge Test")
                    Dim IDsch As Double
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .ELoadCell.ConstantCurrentSetting = 0.3 'Take some load off the cell power supply
                        .EloadPack.ConstantCurrentSetting = Iset
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(100)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        IDsch = .EloadPack.GetInputCurrent()
                    End With
                    StepResult = TestingData.AddMeasurement_Double("T07", "Discharge Current Nominal", Iset - 0.1, Iset + 0.1, IDsch, "A")
                Case 6
                    AddStatusMessage("Cell UnderVoltage Testing. Step Down Vcell")
                    Dim Vcell As Double
                    Dim IDsch As Double
                    Dim DischargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 3.0    'starting point for COV

                    Do
                        VsetCell -= Me.GetValue(MyKeys.COV_PsCell_Step)
                        VsetCell = 2.5
                        TestSetControl.PsCell.VoltageSet = VsetCell

                        Delay(Me.GetValue(MyKeys.CUV_PsCell_Dwell))

                        IDsch = TestSetControl.EloadPack.GetInputCurrent
                        IDsch = IIf(IDsch < 0, 0, IDsch)
                        TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                        CellVoltageIsPass = TestingData.AddMeasurement_Double("T08", "CUV Cell Voltage", 2.4, 2.6, Vcell, "V")
                        DischargeIsPass = TestingData.AddMeasurement_Double("T09", "CUV Current", 0, Me.GetValue(MyKeys.Pack_Current_CUV), IDsch, "A")
                    Loop Until DischargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.CUV_PsCell_Vmin)
                    StepResult = StepResult And CellVoltageIsPass And DischargeIsPass
                Case 7
                    AddErrorMessage("Cell Undervoltage Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    TestSetControl.PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                    TestSetControl.PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                    Delay(100)   ' This might be enough to bring it back up
                    TestSetControl.PsPack.IsEnabled = True
                    Delay(100)
                    TestSetControl.PsPack.IsEnabled = False
                    TestSetControl.EloadPack.ConstantCurrentSetting = Iset
                    TestSetControl.EloadPack.InputEnabledState = True
                    Delay(500)
                    Dim CUVRecoveryAmps As Double = TestSetControl.EloadPack.GetInputCurrent
                    StepResult = TestingData.AddMeasurement_Double("T10", "CUV Recovery Current", Iset - 0.1, Iset + 0.1, CUVRecoveryAmps, "A")
                Case 9
                    AddStatusMessage("Overcurrent-Discharge")
                    Dim IPackMAX As Double = 3.0 'Quit trying if it doesn't get this far
                    Dim Ipack As Double
                    Dim Vpack As Double
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom) + 0.5
                    With TestSetControl
                        .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = 4.0  'Lots of current needed for OCD/OCC Testing
                        .ELoadCell.ConstantCurrentSetting = 0.3   'Not much sink needed for OCD
                        'Ramp up disch current until Ipack=0 or Ipack>3.8
                        Do
                            Iset += GetValue(MyKeys.ElPack_OCD_Step)
                            Iset = 1.4   ' Set to max value right off the bat
                            .EloadPack.ConstantCurrentSetting = Iset
                            Delay(GetValue(MyKeys.CUV_PsCell_Dwell))
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vpack), Vpack, "auto", False)
                            Ipack = .EloadPack.GetInputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T11", "OCD-Disch Trip", GetValue(MyKeys.ElPack_OCD_min), GetValue(MyKeys.ElPack_OCD_Max), Iset, "A")
                            StepResult = StepResult And
                                TestingData.AddMeasurement_Double("T12", "OCD-Disch Current", 0, 0.5, Ipack, "A")
                        Loop Until StepResult Or Iset > Me.GetValue(MyKeys.ElPack_OCD_Max) + 0.5
                        .EloadPack.InputEnabledState = False
                    End With
                Case 10
                    AddStatusMessage("OCD Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .PsPack.IsEnabled = True
                        Delay(500)
                        .PsPack.IsEnabled = False
                        .EloadPack.InputEnabledState = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim IDisch As Double = .EloadPack.GetInputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T13", "OCD Recovery Current", Iset - 0.1, Iset + 0.1, IDisch, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                        .EloadPack.InputEnabledState = False
                    End With
                Case 12
                    AddStatusMessage("Overcurrent-Charge")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Iset_Nom)
                    Dim Ichg As Double
                    With TestSetControl
                        .EloadPack.InputEnabledState = False
                        .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = 4.0  ' Should be enough
                        .ELoadCell.ConstantCurrentSetting = 3.8 'Amps
                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.CurrentSet = Iset
                        .PsPack.IsEnabled = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Iset += GetValue(MyKeys.PsPack_OCC_Step)
                            .PsPack.CurrentSet = Iset
                            Delay(GetValue(MyKeys.PsPack_OCC_Dwell))
                            Ichg = .PsPack.OutputCurrent
                            If Ichg < 0 Then Ichg = 0
                            StepResult = TestingData.AddMeasurement_Double("T14", "OCC-Charge Trip", GetValue(MyKeys.PsPack_OCC_min), GetValue(MyKeys.PsPack_OCC_Max), Iset, "A")
                            StepResult = StepResult And
                                TestingData.AddMeasurement_Double("T15", "OCC-Charge Current", 0, 0.5, Ichg, "A")
                        Loop Until StepResult Or Iset > GetValue(MyKeys.PsPack_OCC_Max) + 1
                    End With

                Case 13
                    AddStatusMessage("OCC Recovery")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Vset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        .EloadPack.InputEnabledState = False
                        Dim Sw As New Stopwatch
                        Dim IchgSet As Double = GetValue(MyKeys.PSPack_Iset_Nom)
                        .PsPack.CurrentSet = IchgSet
                        .PsPack.IsEnabled = True
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim Ichg As Double = .PsPack.OutputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T16", "OCC Recovery Current", IchgSet - 0.1, IchgSet + 0.1, Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With
            End Select
            My.Application.DoEvents()
            Tstep += 1
            RunTest = RunTest And StepResult
        Loop While Tstep < 20 And StepResult
        TestSetControl.CleanUp()
        My.Application.DoEvents()
        pTestingData.EndTest()
        Return pTestingData.TestStatus = DataCollection.enTestStatus.TEST_PASS
    End Function
    Private Sub ExecuteTestOnClick(sender As Object, e As EventArgs) Handles mnuMenuIndi.Click
        Call Me.RunTest()
    End Sub
    Public Sub New()
        mnuMenuIndi = New ToolStripMenuItem
        mnuMenuIndi.Text = Me.GroupName
        mnuMenuIndi.CheckOnClick = False
        Me.TestingData = New DataCollection
    End Sub
End Class

Public Class Test_PcaSafety_Limits
    Implements iTestFunction
    Private WithEvents mnuMenuIndi As ToolStripMenuItem

    Private pTestingData As New DataCollection

    Public Property TestingData As DataCollection Implements iTestFunction.TestingData
        Get
            Return pTestingData
        End Get
        Set(value As DataCollection)
            pTestingData = value
        End Set
    End Property
    Private pGroupName As String = "Cell Side Voltage Regulation"
    Public Property GroupName As String Implements iTestFunction.GroupName
        Get
            Return pGroupName
        End Get
        Set(value As String)
            pGroupName = value
            Me.mnuMenuIndi.Text = value
            Me.TestingData.MyStatusDisplay.Name = value
        End Set
    End Property

    Public Property MenuIndicator As System.Windows.Forms.ToolStripMenuItem Implements iTestFunction.MenuIndicator
        Get
            mnuMenuIndi.Text = GroupName
            Return mnuMenuIndi
        End Get
        Set(value As System.Windows.Forms.ToolStripMenuItem)
            mnuMenuIndi = value
        End Set
    End Property
    Private KeyValueList As New Collection
    Public Enum MyKeys
        Relay_Cell   'A  Panel Position
        Relay_Pack   'A  Panel Position
        '  
        PSCell_Vset_Nom   '3.5 V Nominal Cell Values
        PSCell_Iset_Nom   '3 V 
        ELCell_Iset_Nom   '0.2 A Cell Current Sink
        '  
        PSPack_Vset_Nom   '4.4 V 
        PSPack_Iset_Nom   '0.5 V 
        ELPack_Iset_Nom   '1 A 
        '  
        Config_101   'Volts  Configure DAQ Channel
        Config_102   'Volts  Configure DAQ Channel
        Config_103   'Volts  Configure DAQ Cha`1nnel
        Config_104   'Ohms  Configure DAQ Channel
        Config_105   'Ohms  Configure DAQ Channel
        '  
        Chan_Vcell   '101  DAQ Channel
        Chan_Vpack   '102  DAQ Channel
        Chan_ID   '103  DAQ Channel
        Chan_Fuse   '104  DAQ Channel
        Chan_FeedThru   '105  DAQ Channel
        '  
        COV_PsCell_Vmax   '4.35 V Cell Voltage for COV
        COV_PsCell_Step   '0.1 V  Step in this increment from nominal
        COV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_COV   '0.05 A Max allowable pack charge current during COV
        '  
        CUV_PsCell_Vmin   '4.35 V Cell Voltage for CUV
        CUV_PsCell_Step   '0.1 V  Step in this increment from nominal
        CUV_PsCell_Dwell   '100 ms msec between steps
        Pack_Current_CUV   '0.05 A Max allowable pack discharge current during CUV
        '  
        ElPack_OCD_Step   '0.1 A Step up load from nominal
        ElPack_OCD_Dwell   '100 msec 
        ElPack_OCD_min   '0.7 A Test limits. Mininum pack current that caused the OCD fault
        ElPack_OCD_Max   '1.3 A Test limits. Maximum pack current that caused the OCD fault
        '  
        PsPack_OCC_Step   '0.1 A Step up charge current from nominal
        PsPack_OCC_Dwell   '100 msec 
        PsPack_OCC_min   '0.7 A Test limits. Mininum pack current that caused the OCC fault
        PsPack_OCC_Max   '1.3 A Test limits. Maximum pack current that caused the OCC fault

    End Enum
    Public Function AddKeyValue(KeyName As Integer, Value As Object) As Boolean Implements iTestFunction.AddKeyValue
        Dim KeyEnum As MyKeys = KeyName
        Return AddKeyValue(KeyEnum.ToString, Value)
    End Function
    Private Function GetValue(KeyItem As MyKeys) As Object
        Try
            Return KeyValueList(KeyItem.ToString)
        Catch ex As Exception
            Utility.ErrorHandler_General(ex)
            Return Nothing
        End Try
    End Function
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements iTestFunction.AddKeyValue
        ' Add a key-value relationship
        ' Such as
        '       "VpackChan" = 101
        '       "CellBalanceHigh" = 204
        ' This allows the script to access the members by key name, rather than directly with number
        ' Example:
        '   Dim a As Integer = KeyValueList("VpackChan")
        ' Be sure KeyName appears in the Enum list
        '   Return False if it isn't, indicating an invalid key name
        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)

        If Utility.ArrayContains(KeyNameList, KeyName) Then
            If KeyValueList.Contains(KeyName) Then KeyValueList.Remove(KeyName)
            KeyValueList.Add(KeyValue, KeyName)
            Return True
        Else
            Return False
        End If

    End Function
    Public Function ListMyValues() As Data.DataTable
        On Error Resume Next
        ListMyValues = New Data.DataTable

        Dim TheEnum As MyKeys = MyKeys.Chan_FeedThru

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)
        Dim KeyValueList() As Integer = [Enum].GetValues(TheEnum.GetType)

        With ListMyValues
            .Columns.Clear()
            .Columns.Add("Key")
            .Columns.Add("Value")
            .Columns.Add("EnumVal")

            For i As Integer = 0 To UBound(KeyNameList)
                TheEnum = i
                Dim TheObj As Object = Me.GetValue(TheEnum)
                Dim Fields() As String = {TheEnum.ToString, TheObj, i.ToString}
                .Rows.Add(Fields)
            Next
        End With
    End Function
    Public MyCellRelayBit As clsRelayDriver.enBitFunctions
    Public myPackRelayBit As clsRelayDriver.enBitFunctions


    Public Function RunTest() As Boolean Implements iTestFunction.RunTestGroup
        ' Executes the set sequence
        ' Just a ten second run of random numbers
        Me.pTestingData.StartNewTest()

        My.Application.DoEvents()

        Dim Rnd As New Random
        Dim StepResult As Boolean = True
        Dim Tstep As Integer = 1
        Dim SomeNumber As Double
        Dim CellBit As Integer
        Dim PackBit As Integer
        Dim CellVoltage As Double = 10    'V
        Dim CellSink As Double = 5  'A
        Dim PackVoltage As Double
        Dim PackCurrent As Double = 2 'A

        Dim Voltages() As Double = {3, 6, 9, 12, 15, 20}
        Dim Loads() As Double = {1, 2, 3}

        Dim ConfigMeter As Boolean = True
        RunTest = True

        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("Starting " & Me.pGroupName)
                    AddStatusMessage("Configuring Equipment")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.IsEnabled = False
                        .ELoadCell.InputEnabledState = False
                        .EloadPack.InputEnabledState = False
                        .RelayDriver.ClearAllBits()
                        Delay(200)

                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '.RelayDriver.SetBit(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(500)  ' Let the relays settle down
                        .RelayDriver.SetBit_En(MyCellRelayBit)
                        .RelayDriver.SetBit_En(myPackRelayBit)
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = Me.GetValue(MyKeys.PSCell_Iset_Nom)
                        .ELoadCell.ConstantCurrentSetting = GetValue(MyKeys.ELCell_Iset_Nom)

                        .PsPack.IsEnabled = False
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsPack.CurrentSet = Me.GetValue(MyKeys.PSPack_Iset_Nom)
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                    End With
                    Delay(200)
                    My.Application.DoEvents()
                Case 2
                    AddErrorMessage("Enable Cell Simulator. Wake up PCA")
                    With TestSetControl
                        .ELoadCell.InputEnabledState = True
                        Delay(100)
                        .PsCell.IsEnabled = True
                        .EloadPack.ConstantCurrentSetting = 0.1
                        .EloadPack.InputEnabledState = False
                        .PsPack.IsEnabled = True
                        Delay(200)

                        .PsPack.IsEnabled = True
                        Delay(300)
                        .PsPack.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom) + 0.3
                        'With .RelayDriver
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Cell_EL)
                        '    Delay(1000)
                        '    .SetBit_En(clsRelayDriver.enBitFunctions.Pack_PS)
                        'End With
                        ' Charge current now flowing
                        Delay(200)   ' wait a bit to set up
                        Dim IChgNom As Double
                        My.Application.DoEvents()
                        Dim VcellNom As Double
                        Dim sw As New Stopwatch
                        sw.Start()
                        Do
                            IChgNom = .PsPack.OutputCurrent
                            IChgNom = IIf(IChgNom < 0, 0, IChgNom)
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), VcellNom, "auto", True)
                            ' Record nominal values
                            StepResult = Me.TestingData.AddMeasurement_Double("T01", "Cell Voltage Nominal", 3.2, 3.6, VcellNom, "V", "0.000")
                            StepResult = StepResult And _
                                Me.TestingData.AddMeasurement_Double("T03", "Charge Current Nominal", 0.15, 0.25, IChgNom, "A", "0.000")
                        Loop Until StepResult Or sw.ElapsedMilliseconds > 2000
                    End With
                Case 3
                    AddStatusMessage("Cell OverVoltage Test. Step up Vcell")
                    Dim Vcell As Double
                    Dim Ichg As Double
                    Dim ChargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 4.0    'starting point for COV

                    Do
                        VsetCell += Me.GetValue(MyKeys.COV_PsCell_Step)
                        TestSetControl.PsCell.VoltageSet = VsetCell
                        TestSetControl.PsPack.VoltageSet = VsetCell + 0.5
                        Delay(Me.GetValue(MyKeys.COV_PsCell_Dwell))
                        Ichg = TestSetControl.PsPack.OutputCurrent
                        Ichg = IIf(Ichg < 0, 0, Ichg)
                        TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                        CellVoltageIsPass = TestingData.AddMeasurement_Double("T04", "COV Cell Voltage", 4.2, 4.4, Vcell, "V")
                        ChargeIsPass = TestingData.AddMeasurement_Double("T05", "COV Current", 0, Me.GetValue(MyKeys.Pack_Current_COV), Ichg, "A")
                    Loop Until ChargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.COV_PsCell_Vmax)
                    StepResult = StepResult And CellVoltageIsPass And ChargeIsPass
                Case 4
                    AddStatusMessage("COV Recovery Test")
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .PsCell.VoltageSet = Me.GetValue(MyKeys.PSCell_Vset_Nom)
                        Delay(200)
                        .EloadPack.InputEnabledState = True
                        Delay(100)
                        .EloadPack.InputEnabledState = False
                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.IsEnabled = True
                    End With
                    Delay(500)
                    Dim Irecover As Double = TestSetControl.PsPack.OutputCurrent
                    Irecover = IIf(Irecover < 0, 0, Irecover)
                    StepResult = TestingData.AddMeasurement_Double("T06", "COV Recovery Current", 0.15, 0.25, Irecover, "A")

                Case 5
                    AddStatusMessage("Nominal Discharge Test")
                    Dim IDsch As Double
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .ELoadCell.ConstantCurrentSetting = 0.3 'Take some load off the cell power supply
                        .EloadPack.ConstantCurrentSetting = Iset
                        .RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_EL)
                        Delay(100)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        IDsch = .EloadPack.GetInputCurrent()
                    End With
                    StepResult = TestingData.AddMeasurement_Double("T07", "Discharge Current Nominal", Iset - 0.1, Iset + 0.1, IDsch, "A")
                Case 6
                    AddStatusMessage("Cell UnderVoltage Testing. Step Down Vcell")
                    Dim Vcell As Double
                    Dim IDsch As Double
                    Dim DischargeIsPass As Boolean, CellVoltageIsPass As Boolean
                    Dim VsetCell As Double = 3.0    'starting point for COV

                    Do
                        VsetCell -= Me.GetValue(MyKeys.COV_PsCell_Step)
                        TestSetControl.PsCell.VoltageSet = VsetCell

                        Delay(Me.GetValue(MyKeys.CUV_PsCell_Dwell))

                        IDsch = TestSetControl.EloadPack.GetInputCurrent
                        IDsch = IIf(IDsch < 0, 0, IDsch)
                        TestSetControl.DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vcell), Vcell, "auto", False)
                        CellVoltageIsPass = TestingData.AddMeasurement_Double("T08", "CUV Cell Voltage", 2.7, 2.9, Vcell, "V")
                        DischargeIsPass = TestingData.AddMeasurement_Double("T09", "CUV Current", 0, Me.GetValue(MyKeys.Pack_Current_CUV), IDsch, "A")
                    Loop Until DischargeIsPass Or TestSetControl.PsCell.VoltageSet > Me.GetValue(MyKeys.CUV_PsCell_Vmin)
                    StepResult = StepResult And CellVoltageIsPass And DischargeIsPass
                Case 7
                    AddErrorMessage("Cell Undervoltage Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    TestSetControl.PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                    TestSetControl.PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                    Delay(100)   ' This might be enough to bring it back up
                    TestSetControl.PsPack.IsEnabled = True
                    Delay(100)
                    TestSetControl.PsPack.IsEnabled = False
                    TestSetControl.EloadPack.ConstantCurrentSetting = Iset
                    TestSetControl.EloadPack.InputEnabledState = True
                    Delay(500)
                    Dim CUVRecoveryAmps As Double = TestSetControl.EloadPack.GetInputCurrent
                    StepResult = TestingData.AddMeasurement_Double("T10", "CUV Recovery Current", Iset - 0.1, Iset + 0.1, CUVRecoveryAmps, "A")
                Case 9
                    AddStatusMessage("Overcurrent-Discharge")
                    Dim IPackMAX As Double = 3.0 'Quit trying if it doesn't get this far
                    Dim Ipack As Double
                    Dim Vpack As Double
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = 4.0  'Lots of current needed for OCD/OCC Testing
                        .ELoadCell.ConstantCurrentSetting = 0.3   'Not much sink needed for OCD
                        'Ramp up disch current until Ipack=0 or Ipack>3.8
                        Do
                            Iset += GetValue(MyKeys.ElPack_OCD_Step)
                            .EloadPack.ConstantCurrentSetting = Iset
                            Delay(GetValue(MyKeys.CUV_PsCell_Dwell))
                            .DAQ.ReadDCVolts(Me.GetValue(MyKeys.Chan_Vpack), Vpack, "auto", False)
                            Ipack = .EloadPack.GetInputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T11", "OCD-Disch Trip", GetValue(MyKeys.ElPack_OCD_min), GetValue(MyKeys.ElPack_OCD_Max), Iset, "A")
                            StepResult = StepResult And _
                                TestingData.AddMeasurement_Double("T12", "OCD-Disch Current", 0, 0.5, Ipack, "A")
                        Loop Until StepResult Or Iset > Me.GetValue(MyKeys.ElPack_OCD_Max) + 0.5
                        .EloadPack.InputEnabledState = False
                    End With
                Case 10
                    AddStatusMessage("OCD Recovery")
                    Dim Iset As Double = GetValue(MyKeys.ELPack_Iset_Nom)
                    With TestSetControl
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .PsPack.IsEnabled = True
                        Delay(500)
                        .PsPack.IsEnabled = False
                        .EloadPack.InputEnabledState = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim IDisch As Double = .EloadPack.GetInputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T13", "OCD Recovery Current", Iset - 0.1, Iset + 0.1, IDisch, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With
                Case 12
                    AddStatusMessage("Overcurrent-Charge")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Iset_Nom)
                    Dim Ichg As Double
                    With TestSetControl
                        .PsCell.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom)
                        .PsCell.CurrentSet = 4.0  ' Should be enough
                        .ELoadCell.ConstantCurrentSetting = 3.8 'Amps
                        .PsPack.VoltageSet = GetValue(MyKeys.PSCell_Vset_Nom) + 0.5
                        .PsPack.CurrentSet = Iset
                        .PsPack.IsEnabled = True
                        Dim Sw As New Stopwatch
                        Sw.Start()
                        Do
                            Iset += GetValue(MyKeys.PsPack_OCC_Step)
                            .PsPack.CurrentSet = Iset
                            Delay(GetValue(MyKeys.PsPack_OCC_Dwell))
                            Ichg = .PsPack.OutputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T14", "OCC-Charge Trip", GetValue(MyKeys.PsPack_OCC_min), GetValue(MyKeys.PsPack_OCC_Max), Iset, "A")
                            StepResult = StepResult And _
                                TestingData.AddMeasurement_Double("T15", "OCC-Charge Current", 0, 0.5, Ichg, "A")
                        Loop Until StepResult Or Iset > GetValue(MyKeys.PsPack_OCC_Max) + 1
                    End With
                Case 13
                    AddStatusMessage("OCC Recovery")
                    Dim Iset As Double = GetValue(MyKeys.PSPack_Vset_Nom)
                    With TestSetControl
                        .PsPack.IsEnabled = False
                        .EloadPack.ConstantCurrentSetting = GetValue(MyKeys.ELPack_Iset_Nom)
                        .EloadPack.InputEnabledState = True
                        Delay(500)
                        .EloadPack.InputEnabledState = False
                        Dim Sw As New Stopwatch
                        Dim IchgSet As Double = GetValue(MyKeys.PSPack_Iset_Nom)
                        .PsPack.CurrentSet = IchgSet
                        .PsPack.IsEnabled = True
                        Sw.Start()
                        Do
                            Delay(500)
                            Dim Ichg As Double = .PsPack.OutputCurrent
                            StepResult = TestingData.AddMeasurement_Double("T16", "OCC Recovery Current", IchgSet - 0.1, IchgSet + 0.1, Ichg, "A")
                        Loop Until StepResult Or Sw.ElapsedMilliseconds > 3000
                    End With
            End Select
            My.Application.DoEvents()
            Tstep += 1
            RunTest = RunTest And StepResult
        Loop While Tstep < 20 And StepResult
        TestSetControl.CleanUp()
        My.Application.DoEvents()
        pTestingData.EndTest()
        Return pTestingData.TestStatus = DataCollection.enTestStatus.TEST_PASS
    End Function
    Private Sub ExecuteTestOnClick(sender As Object, e As EventArgs) Handles mnuMenuIndi.Click
        Call Me.RunTest()
    End Sub
    Public Sub New()
        mnuMenuIndi = New ToolStripMenuItem
        mnuMenuIndi.Text = Me.GroupName
        mnuMenuIndi.CheckOnClick = False
        Me.TestingData = New DataCollection
    End Sub
End Class