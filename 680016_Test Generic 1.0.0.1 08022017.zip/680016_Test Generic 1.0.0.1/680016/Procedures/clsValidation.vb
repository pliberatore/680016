﻿Public Class clsValidation
    Implements ITestFunction
    Private WithEvents mnuMenuIndi As ToolStripMenuItem

    Private pTestingData As New DataCollection

    Public Property TestingData As DataCollection Implements ITestFunction.TestingData
        Get
            Return pTestingData
        End Get
        Set(value As DataCollection)
            pTestingData = value
        End Set
    End Property
    Private pGroupName As String = "Cell Side Voltage Regulation"
    Public Property GroupName As String Implements ITestFunction.GroupName
        Get
            Return pGroupName
        End Get
        Set(value As String)
            pGroupName = value
            Me.mnuMenuIndi.Text = value
            Me.TestingData.MyStatusDisplay.Name = value
        End Set
    End Property

    Public Property MenuIndicator As System.Windows.Forms.ToolStripMenuItem Implements ITestFunction.MenuIndicator
        Get
            mnuMenuIndi.Text = GroupName
            Return mnuMenuIndi
        End Get
        Set(value As System.Windows.Forms.ToolStripMenuItem)
            mnuMenuIndi = value
        End Set
    End Property
    Private KeyValueList As New Collection
    Public Enum MyKeys
        ' Relay card channels 0~23
        CellSelectChan ' 0
        PackSelectChan ' 8

        VcellChan ' 101
        VpackChan ' 102

        PsCell_ISetNominal ' 3.5  'Amps
        ElCell_ISet ' 3    'Amps
        PsCell_VsetNominal ' 3.5 'V
        ElPack_IsetNom ' 0.5 'amp

        ' Cell Overvoltage Testing
        ' Ramp up PsCell until Ipack ' 0, as measured by PsPack
        PsPack_Vset ' 4.5  'Volts
        PsPack_Iset ' 0.5 'Amps

        PsCell_COV_Max ' 4.3    ' Volts. Max voltage to step up to
        PsCell_COV_Step ' 0.1     ' Volts. Step in this increment
        PsCell_COV_Dwell ' 100    'msec between steps
        Pack_Current_COV ' 0.1  'Amp. Max allowable pack current during COV
        CellVoltage_COV_Min ' 4.1   ' Volts
        CellVoltage_COV_Max ' 4.2   ' Volts

        'Cell Undervoltage
        ' Ramp down PsCell until Ipack ' 0, as measured by ElPack
        PsCell_CUV_Min ' 2.0  'V
        PsCell_CUV_Step ' 0.1   'V
        PSCell_CUV_Dwell ' 100  'msec
        Pack_Current_CUV ' 0.1 'Amp. Max allowable pack current during CUV
        CellVoltage_CUV_Min ' 4.1   ' Volts
        CellVoltage_CUV_Max ' 4.2   ' Volts

        'OverCurrent-Discharge
        ' Ramp up Ipack until Ipack=0
        ' Cell at nominal settings
        ElPack_OCD_Step ' 0.1   'A
        ElPack_OCD_Dwell ' 100  'msec
        ElPack_OCD_Max ' 2  '   Amp. Max discharge current before calling it a fail
        Pack_Current_OCD_min ' 1.8  'A. The pack current that caused OCD fault
        Pack_Current_OCD_max ' 1.8  'A. The pack current that caused OCD fault

        'OverCurrent-Charge
        ' Ramp up Ipack until Ipack=0
        ' Cell at nominal settings
        ElPack_OCC_Step ' 0.1   'A
        ElPack_OCC_Dwell ' 100  'msec
        ElPack_OCC_Max ' 2  '   Amp. Max discharge current before calling it a fail
        Pack_Current_OCC_min ' 1.8  'A. The pack current that caused OCD fault
        Pack_Current_OCC_max ' 1.8  'A. The pack current that caused OCD fault

    End Enum
    Public Function AddKeyValue(KeyName As Integer, Value As Object) As Boolean Implements ITestFunction.AddKeyValue
        Dim KeyEnum As cls1sSafetyOnly.MyKeys = KeyName
        Return AddKeyValue(KeyEnum.ToString, Value)
    End Function
    Private Function GetKeyValue(KeyItem As cls1sSafetyOnly.MyKeys) As Object
        Return KeyValueList(KeyItem.ToString)
    End Function
    Public Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean Implements ITestFunction.AddKeyValue
        ' Add a key-value relationship
        ' Such as
        '       "VpackChan" = 101
        '       "CellBalanceHigh" = 204
        ' This allows the script to access the members by key name, rather than directly with number
        ' Example:
        '   Dim a As Integer = KeyValueList("VpackChan")
        ' Be sure KeyName appears in the Enum list
        '   Return False if it isn't, indicating an invalid key name
        Dim TheEnum As MyKeys = MyKeys.CellSelectChan

        Dim KeyNameList() As String = [Enum].GetNames(TheEnum.GetType)
        For i As Integer = 0 To KeyNameList.GetUpperBound(0)
            KeyNameList(i) = KeyNameList(i).ToUpper
        Next
        If KeyNameList.Contains(KeyName.ToUpper) Then
            If KeyValueList.Contains(KeyName) Then KeyValueList.Remove(KeyName)
            KeyValueList.Add(KeyValue, KeyName)
        Else
            Return False
        End If

    End Function

    Public Function RunTest() As Boolean Implements ITestFunction.RunTestGroup
        ' Executes the set sequence
        ' Just a ten second run of random numbers
        Me.pTestingData.StartNewTest()

        My.Application.DoEvents()

        Dim Rnd As New Random
        Dim Result As Boolean = True
        Dim Tstep As Integer = 1
        Dim SomeNumber As Double
        Dim CellBit As Integer
        Dim PackBit As Integer
        Dim CellVoltage As Double = 10    'V
        Dim CellSink As Double = 5  'A
        Dim PackVoltage As Double
        Dim PackCurrent As Double = 2 'A

        Dim Voltages() As Double = {3, 6, 9, 12, 15, 20}
        Dim Loads() As Double = {1, 2, 3}

        Dim ConfigMeter As Boolean = True
        RunTest = True
        Do
            Select Case Tstep
                Case 1
                    AddStatusMessage("Starting " & Me.pGroupName)


                Case 2
                    ' set up equipment
                    TestSetControl.PsCell.VoltageSet = Voltages(0)
                    TestSetControl.PsCell.CurrentSet = 20 'Max

                    TestSetControl.EloadPack.ConstantCurrentSetting = Loads(0)

                    TestSetControl.RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_PS)
                    TestSetControl.RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_EL)

                    TestSetControl.RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Cell_A)
                    TestSetControl.RelayDriver.SetBit_En(clsRelayDriver.enBitFunctions.Pack_A)

                    TestSetControl.PsCell.IsEnabled = True
                    TestSetControl.EloadPack.InputEnabledState = True

                Case 3
                    Dim TestID As String
                    Dim Tnumber As Integer = 0
                    Dim TestName As String
                    Dim SourceVoltage As Double
                    Dim LoadCurrent As Double
                    Dim TheVoltage As Double
                    Dim IsFirstLoad As Boolean = True
                    Dim FirstCurrent As Double, FirstVoltage As Double
                    Dim VoltageDrop As Double
                    For Each SourceVoltage In Voltages
                        ConfigMeter = True
                        IsFirstLoad = True
                        For Each LoadCurrent In Loads
                            TestSetControl.PsCell.VoltageSet = SourceVoltage
                            TestSetControl.EloadPack.ConstantCurrentSetting = LoadCurrent
                            'Delay(100)
                            Tnumber += 1
                            TestSetControl.DAQ.ReadDCVolts(101, TheVoltage, "", ConfigMeter)
                            ConfigMeter = False
                            TestID = "T" & Format(Tnumber, "000")
                            TestName = "Source=" & SourceVoltage & "V  Load=" & LoadCurrent & "A"
                            If TheVoltage <> 9.9E+37 Then TestingData.AddMeasurement_Double(TestID, TestName, 0, 100, TheVoltage, "V", "0.000")
                            If IsFirstLoad Then
                                FirstCurrent = LoadCurrent
                                FirstVoltage = TheVoltage
                                IsFirstLoad = False
                            End If
                        Next
                        ' Now, report voltage drop
                        VoltageDrop = FirstVoltage - TheVoltage
                        TestName = "Regulation " & SourceVoltage & "V  Load" & LoadCurrent & "A"
                        Tnumber += 1
                        TestID = "T" & Format(Tnumber, "000")
                        TestingData.AddMeasurement_Double(TestID, TestName, 0, 1, VoltageDrop, "V", "0.000")
                    Next

                Case 4
                    ' Insert environment variables at the top of dgv
            End Select
            Tstep += 1
            RunTest = RunTest And Result
        Loop While Tstep < 20 And (Result = True Or Result = False)
        TestSetControl.CleanUp()
        My.Application.DoEvents()
        pTestingData.EndTest()
        Return pTestingData.TestStatus = DataCollection.enTestStatus.TEST_PASS
    End Function
    Private Sub ExecuteTestOnClick(sender As Object, e As EventArgs) Handles mnuMenuIndi.Click
        Call Me.RunTest()
    End Sub
    Public Sub New()
        mnuMenuIndi = New ToolStripMenuItem
        mnuMenuIndi.Text = Me.GroupName
        mnuMenuIndi.CheckOnClick = False
        Me.TestingData = New DataCollection
    End Sub
End Class
