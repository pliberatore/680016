﻿Imports System.Data

Public Class clsSequenceBuilder
    Public TestingData As TestSequencer

    Public Sub BuildSequence()
        ' Creates the iTestFunction objects in the sequencer
        ' For now, the iTestFunction source is hard-coded in this sub
        ' Later on, the source should be a source file. The format is not yet determined

        Utility.Sequencer = New TestSequencer ' Start fresh

        'Now init the sequencer

        Dim TheTest As ITestFunction
        ' Initialize each test group

        ' Initialize each test separately.

        ' The order in which the status indicators will be added to dgv
        Dim Rows() As Integer = {0, 0, 1, 1}
        Dim Cols() As Integer = {0, 1, 0, 1}
        For i As Integer = 1 To 1
            'TheTest = New cls1sSafetyOnly
            TheTest = New clsValidation
            'TheTest.TestingData.InitMe()
            TheTest.GroupName = TheTest.GroupName & " Pallet " & i.ToString
            ' Relay card channels 0~23
            'TheTest.AddKeyValue("CellSelectChan", i - 1) '1, 2, 3, 4
            'TheTest.AddKeyValue("PackSelectChan", i + 7) ' 8, 9, 10, 11
            'TheTest.AddKeyValue("VcellChan", 100 + 2 * i - 1) ' 101, 103, 105, 107
            'TheTest.AddKeyValue("VpackChan", 100 + 2 * i) ' 102, 104, 106, 108
            'Call InitializeCommonValues(TheTest)    ' Equipment setpoints, measurement limits, etc. All the same for each test group
            'frmTestSetControl.tlpStatusIndicators.Controls.Add(TheTest.TestingData.MyStatusDisplay)
            TheTest.TestingData.MyStatusDisplay.Dock = DockStyle.Fill
            'frmTestSetControl.tlpStatusIndicators.SetRowSpan(TheTest.TestingData.MyStatusDisplay, 2)
            'frmTestSetControl.tlpStatusIndicators.SetColumnSpan(TheTest.TestingData.MyStatusDisplay, 2)
            Sequencer.AddTestGroup(TheTest)
        Next
    End Sub
    Private SheetList() As String

    Public Function ParseTestFile(Filename As String) As Boolean
        ' Use this in case we're pulling data from an Excel file

        ParseTestFile = True
        Try
            Dim MyConnection As New System.Data.OleDb.OleDbConnection
            Dim DtSet As System.Data.DataSet
            Dim MyCommand As System.Data.OleDb.OleDbDataAdapter
            'MyConnection = New System.Data.OleDb.OleDbConnection _
            '            ("provider=Microsoft.Jet.OLEDB.4.0; Data Source='" & Filename & "';Extended Properties=Excel 8.0;")

            Dim XlsConn1 As String =
               "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Filename & ";" &
               "Extended Properties=" & Chr(34) & "Excel 8.0;HDR=NO;Mode=1;IMEX=1" & Chr(34) & ";" 'Read-only

            Dim XlsConn As String =
                "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Filename & ";" &
                "Extended Properties=" & Chr(34) & "Excel 12.0;HDR=NO;Mode=1;IMEX=1" & Chr(34) & ";" 'Read-only


            MyConnection.ConnectionString = XlsConn

            MyConnection.Open()
            ' Get the list of sheets
            Dim AllSheets As DataTable =
                MyConnection.GetOleDbSchemaTable(OleDb.OleDbSchemaGuid.Tables, Nothing)

            For Each SheetNameRow As DataRow In AllSheets.Rows
                Dim SheetName As String = SheetNameRow("TABLE_NAME")
                If SheetName.ToUpper.Trim.StartsWith("TEST") Then
                    If SheetList Is Nothing Then
                        ReDim SheetList(0)
                    Else
                        ReDim Preserve SheetList(UBound(SheetList) + 1)
                    End If
                    SheetList(UBound(SheetList)) = SheetName
                End If
            Next
            Array.Sort(SheetList)

            DtSet = New System.Data.DataSet
            Dim i As Integer
            For i = 0 To 3

                MyCommand = New System.Data.OleDb.OleDbDataAdapter _
                            ("select * from [" & SheetList(i) & "]", MyConnection)
                'MyCommand.TableMappings.Add("Table", "TestTable")
                Dim Dtable As New DataTable

                MyCommand.Fill(Dtable)
                DtSet.Tables.Add(Dtable)
            Next
            frmTestingForm.DataGridView1.DataSource = DtSet.Tables(0)
            frmTestingForm.DataGridView2.DataSource = DtSet.Tables(1)
            frmTestingForm.DataGridView3.DataSource = DtSet.Tables(2)
            frmTestingForm.DataGridView4.DataSource = DtSet.Tables(3)
            MyConnection.Close()

            ' Parse thru each of the four tables
            ' Submit each line to the data object in Sequencer
            ' The data object can accept to reject the line
            ' Column A: Key
            ' Column B: Value

            Sequencer = New TestSequencer
            Dim TheTest As ITestFunction

            For i = 0 To 3
                ' Add each est group 
                TheTest = New Test_AFE
                For Each TheRow As DataRow In DtSet.Tables(i).Rows
                    Try
                        Dim ThisKey As String = TheRow.Item(0).ToString.Trim
                        Dim ThisValue = TheRow(1)
                        Call TheTest.AddKeyValue(ThisKey, ThisValue)
                    Catch ex As Exception
                        MsgBox(ex.Message)
                    End Try
                Next
                'Add the test to sequencer
                Sequencer.AddTestGroup(TheTest)
            Next
            'frmTestingForm.DataGridView1.DataSource = AllGroups(0).ListMyValues
            'frmTestingForm.DataGridView2.DataSource = AllGroups(1).ListMyValues
            'frmTestingForm.DataGridView3.DataSource = AllGroups(2).ListMyValues
            'frmTestingForm.DataGridView4.DataSource = AllGroups(3).ListMyValues
        Catch ex As Exception
            MsgBox(ex.Message)
            ParseTestFile = False
        Finally
            frmTestingForm.Show()
        End Try
    End Function
End Class
