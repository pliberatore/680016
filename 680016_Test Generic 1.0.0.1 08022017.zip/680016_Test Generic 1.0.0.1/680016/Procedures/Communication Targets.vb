﻿' Communication Targets.vb
'   Copyright 2017, iTECH
'   Proprietary Information
'
' Contact:
'   pliberatore@itecheng.com
'
' Contains classes which provide data parsing to various TI and Dallas-Maxim devices
' TI products require the TestSetControl.EV2300 object to be initialized and available
' Dallas-Maxim products TBD
'

Public Class bq769x0_Comm
    '' Class with which to communicate with Texas Instruments "bq769x0 3-Series to 15-Series Cell Battery Monitor Family"
    ' TI Reference Data sheet: SLUSBK2C-October 2013-REVISED MAY 2016

    '   This class uses the EV2400 adapter. 
    '' Uses  TestSetControl.EV2300 class to generate trace events. 
    '

    Public Property EV2300 As clsEv2300Comm
    Public Property MyAddr As Short = &H11
    Public DeviceData As strDeviceData
    Public Event DataRead(NewData As strDeviceData, Response As clsEv2300Comm.EV2300_ErrorCode)
    Public Event FormVisibleChanged(NowVisible As Boolean)

    Public Structure strDeviceData
        Public SYS_STAT_0x00 As Byte
        Public CELLBAL1_0x01 As Byte
        Public CELLBAL2_0x02 As Byte
        Public CELLBAL3_0x03 As Byte
        Public SYS_CTRL1_0x04 As Byte
        Public SYS_CTRL2_0x05 As Byte
        Public PROTECT1_0x06 As Byte
        Public PROTECT2_0x07 As Byte
        Public PROTECT3_0x08 As Byte
        Public OV_TRIP_0x09 As Byte
        Public UV_TRIP_0x0A As Byte
        Public CC_CFG_0x0B As Byte

        Public Function CoulCounter_uV() As Double
            ' CC Reading (in uV) - [16-bit 2's Complement Value] x (8.44 uV/LSB)
            Dim TheAnswer As Double
            TheAnswer = CoulCounter_Raw() * 8.44
            Return TheAnswer
        End Function
        Public Function CoulCounter_Raw() As Short ' Signed!
            Dim HiByteAdd = &H32
            Dim LoByteAddr = &H33

            Dim HiByte As Byte = DataArr(HiByteAdd)
            Dim LoByte As Byte = DataArr(LoByteAddr)
            Dim TheAnswer As Short
            Call Utility.BytesToShort(HiByte, LoByte, TheAnswer)

            Return TheAnswer
        End Function
        Public Function Temperature(ByVal TS1_3 As Integer, ByRef VoltsTS As Double, ByRef Ohms As Double) As Boolean
            ' Vtsx = (ADC in Decimal) x 382 uV/LSB
            ' Rts = (10,000 * Vtsx) / (3.3 - Vtsx)
            Temperature = False
            If TS1_3 >= 1 And TS1_3 <= 3 Then
                VoltsTS = Temperature_Raw(TS1_3) * 382 / 1000000.0
                Ohms = (10000 * VoltsTS) / (3.3 - VoltsTS)
                Temperature = True
            End If
        End Function
        Public Function Temperature_Raw(TS1_3 As Integer) As UShort
            ' No error handling here.
            ' If an argument or DataArray is not valid, then the error has to be caught by the host caller

            Dim HiByteAdd = &H2A + 2 * TS1_3 ' &2C, &H2E, &H30
            Dim LoByteAddr = &H2B + 2 * TS1_3  ' &H2D, &H2F, &H31

            Dim HiByte As Byte = DataArr(HiByteAdd) And &H3F ' D7 and D6 are undefined in the data sheet, so mask them off
            Dim LoByte As Byte = DataArr(LoByteAddr)

            Dim TheAnswer As UShort = DataArr(HiByteAdd) * (2 ^ 8) ' Shift high byte into the answer
            TheAnswer = TheAnswer Or LoByte ' Add in low byte
            Return TheAnswer
        End Function
        Public Function BatteryVoltage_Raw() As UShort
            ' No error handling here.
            ' If an argument or DataArray is not valid, then the error has to be caught by the host caller
            Dim HiByteAdd = &H2A
            Dim LoByteAddr = &H2B

            Dim HiByte As Byte = DataArr(HiByteAdd)
            Dim LoByte As Byte = DataArr(LoByteAddr)

            Dim TheAnswer As UShort = HiByte * (2 ^ 8) ' Shift high byte into the answer
            TheAnswer = TheAnswer Or LoByte ' Add in low byte
            Return TheAnswer
        End Function
        Public Function BatteryVoltage_Volts() As Double
            ' V(cell) - GAIN x ADC(cell) + OFFSET
            ' GAIN is stored in uV/unit, while OFFSET is stored in mV units.
            Try
                Dim TheVal As Double
                ' Convert to Volts. Use the formula in the data sheet
                TheVal = 4 * Me.ADCGainuV / 1000000 * Me.BatteryVoltage_Raw + (12 * Me.ADCOffsetmV / 1000)
                Return TheVal
            Catch ex As Exception
                Return -1
            End Try
        End Function
        Public Function VCell_Raw(CellNumber1_15 As Integer) As UShort
            ' No error handling here.
            ' If an argument or DataArray is not valid, then the error has to be caught by the host caller
            Dim HiByteAdd = &HA + 2 * CellNumber1_15  ' &H0C, &H0E, &H10, &H12, ...
            Dim LoByteAddr = HiByteAdd + 1 ' &H0D, &H0F, &H11, &H13, ...

            Dim HiByte As Byte = DataArr(HiByteAdd) And &H3F ' D7 and D6 are undefined in the data sheet, so mask them off
            Dim LoByte As Byte = DataArr(LoByteAddr)

            Dim TheAnswer As UShort = HiByte * (2 ^ 8) ' Shift high byte into the answer
            TheAnswer = TheAnswer Or LoByte ' Add in low byte
            Return TheAnswer
        End Function
        Public Function Vcell_Volts(CellNunber1_15 As Integer) As Double
            ' V(cell) - GAIN x ADC(cell) + OFFSET
            ' GAIN is stored in uV/unit, while OFFSET is stored in mV units.
            Try
                Dim TheVal As Double
                ' Convert to Volts
                TheVal = Me.ADCGainuV / 1000000.0 * Me.VCell_Raw(CellNunber1_15) + Me.ADCOffsetmV / 1000
                Return TheVal
            Catch ex As Exception
                Return -1
            End Try
        End Function

        Public Function ADCOffsetmV() As Integer
            ' Byte &H51 is the signed-byte offset value that gets added into the voltage measurements
            ' The value is set by the TI factory
            ' Range is -128 to 127 mV
            ADCOffsetmV = Utility.Byte2SByte(DataArr(&H51))
        End Function
        Public Function ADCGainByte() As Byte
            Dim ADCGain20 As Byte
            ADCGain20 = DataArr(&H59) And &HE0  ' Mask off unwanted bits
            ADCGain20 = ADCGain20 / (2 ^ 5) ' Bits 2:0. Shift these to D2, D1, D0

            Dim ADCGain43 As Byte
            ADCGain43 = DataArr(&H50) And &HC ' Mask off unwanted bits
            ADCGain43 = ADCGain43 * (2 ^ 1) ' Gain bits 4 and 3 are in D3 and D2, respectively
            ' The gain bits should be lined up now. 'OR' the bites and return the correct value
            ADCGainByte = ADCGain43 Or ADCGain20
        End Function
        Public Function ADCGainuV() As Double
            ' Returns ADC Gain in uVolts
            ' From the datasheet
            '      GAIN = 365 uV/LSB + (ADCGAIN<4:0> in decimal) * (1 uV/LSB)
            ADCGainuV = 365 + ADCGainByte() * 1
        End Function
        Friend DataArr() As Byte
        Friend Sub ParseArray()
            ' Parse all bytes from into DataArr()
            SYS_STAT_0x00 = DataArr(&H0) ' just pass the bytes through.. Maybe mask off reserved bytes
            SYS_CTRL1_0x04 = DataArr(&H4)
            SYS_CTRL2_0x05 = DataArr(&H5)
            PROTECT1_0x06 = DataArr(&H6)
            PROTECT2_0x07 = DataArr(&H7)
            PROTECT3_0x08 = DataArr(&H8)
            OV_TRIP_0x09 = DataArr(&H9)
            UV_TRIP_0x0A = DataArr(&HA)
            CC_CFG_0x0B = DataArr(&HB)
            CELLBAL1_0x01 = DataArr(&H1)
            CELLBAL2_0x02 = DataArr(&H2)
            CELLBAL3_0x03 = DataArr(&H3)
            ' All the otehr values are parsed when called.
        End Sub
    End Structure
    Private WithEvents Bq769x00CommForm As New frmBq769x0Comm

    Public Function WriteByteToRegister(Addr As Short, ByteValue As Byte) As clsEv2300Comm.EV2300_ErrorCode
        ' Write a single byte to the target.
        ' Update CommForm
        Try
            If EV2300 Is Nothing Then
                EV2300 = TestSetControl.EV2300
            End If
            If EV2300.OpenDevice() Then
                ' Throw New System.Exception("bq769x0_Comm.ReadDevice: Unable to open Adapter")
            End If ' No errors if it's already open
            Dim ByArr(0) As Byte
            Dim V As Object = ByArr
            V(0) = ByteValue

            WriteByteToRegister = TestSetControl.EV2300.Bq80xRW1.I2CWriteBlock(Addr, V, 1, &H11)
        Catch ex As Exception
            WriteByteToRegister = clsEv2300Comm.EV2300_ErrorCode.iTECH_UnknownError
        Finally
            If Bq769x00CommForm Is Nothing Then Bq769x00CommForm = New frmBq769x0Comm
            Bq769x00CommForm.ByteWasWritten(Addr, ByteValue, WriteByteToRegister)
        End Try
    End Function


    Public Property CommunicationFormVisible As Boolean
        Get
            If Bq769x00CommForm Is Nothing Then Bq769x00CommForm = New frmBq769x0Comm
            Return Bq769x00CommForm.Visible
        End Get
        Set(value As Boolean)
            If Bq769x00CommForm Is Nothing Then Bq769x00CommForm = New frmBq769x0Comm
            Bq769x00CommForm.Visible = value
        End Set
    End Property
    Public Function ReadDevice() As clsEv2300Comm.EV2300_ErrorCode
        ' Reads all bytes in the device into DataArray()
        ' 
        ReadDevice = clsEv2300Comm.EV2300_ErrorCode.VB_NO_ERROR
        Dim V As Object ' A byte array, but the AxBq library needs an object (or varient if VB6)
        Try
            If EV2300 Is Nothing Then
                EV2300 = TestSetControl.EV2300
            End If
            If EV2300.OpenDevice() Then
                ' Throw New System.Exception("bq769x0_Comm.ReadDevice: Unable to open Adapter")
            End If ' No errors if it's already open
            ' Ev2400 is able to read all 96 bytes in one chunk.
            ' This functions, however, is structured like this to make it easier to read the bytes in smaller chunks, if necessary

            ReDim DeviceData.DataArr(95)   ' Number of bytes in bq769x0

            Dim BytesPerPage As Integer = 96
            Dim NumberOfPages As Integer = 1
            ReDim DeviceData.DataArr(NumberOfPages * BytesPerPage - 1)
            For Page = 0 To NumberOfPages - 1
                V = Nothing
                Dim Addr As Short = Page * BytesPerPage
                ReadDevice = TestSetControl.EV2300.Bq80xRW1.I2CReadBlock(Addr, V, BytesPerPage, &H11)
                ' Now append these bytes into DataArr()
                For BytePtr As Integer = 0 To UBound(V)
                    DeviceData.DataArr(BytesPerPage * Page + BytePtr) = V(BytePtr)
                Next
            Next
            ' No errors, so parse the array
            Call DeviceData.ParseArray()

        Catch ex As Exception
            ReadDevice = clsEv2300Comm.EV2300_ErrorCode.iTECH_UnknownError
        Finally
            If Bq769x00CommForm Is Nothing Then Bq769x00CommForm = New frmBq769x0Comm
            Bq769x00CommForm.IncomingData(DeviceData, ReadDevice)

            RaiseEvent DataRead(DeviceData, ReadDevice) ' In case anyone else is listening
        End Try
    End Function

    Private Sub Bq769x00CommForm_Activated(sender As Object, e As EventArgs) Handles Bq769x00CommForm.Activated
        '    Bq769x00CommForm.IncomingData(DeviceData, clsEv2300Comm.EV2300_ErrorCode.iTECH_UnknownError)
    End Sub
    Private Sub Bq769x00CommForm_Disposed(sender As Object, e As EventArgs) Handles Bq769x00CommForm.Disposed
        Bq769x00CommForm = Nothing
    End Sub

    Private Sub Bq769x00CommForm_VisibleChanged(sender As Object, e As EventArgs) Handles Bq769x00CommForm.VisibleChanged
        RaiseEvent FormVisibleChanged(Bq769x00CommForm.Visible)
    End Sub
End Class
