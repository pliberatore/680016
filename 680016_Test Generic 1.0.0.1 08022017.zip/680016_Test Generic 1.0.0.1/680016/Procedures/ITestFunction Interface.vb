﻿

Public Interface ITestFunction
    ' This interface defines the structure of the actual Test sequences
    Property GroupName() As String
    Property MenuIndicator() As ToolStripMenuItem 'main menu item
    Function RunTestGroup() As Boolean 'Returns TRUE if all tests pass, FAIL if any fail. Allows sequencer to ABORT/RETRY/IGNORE accordingly
    Property TestingData As DataCollection
    Function AddKeyValue(KeyName As String, KeyValue As Object) As Boolean
    Function AddKeyValue(KeyName As Integer, KeyValue As Object) As Boolean
End Interface