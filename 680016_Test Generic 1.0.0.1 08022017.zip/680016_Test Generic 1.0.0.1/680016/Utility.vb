﻿' Utility.vb
' Copyright 2017, iTECH
' Phil Liberatore
' pliberatore@itecheng.com
' Module containing variables and structures used in TEST3 applications.
' All items in this module are generally visible to the entire application
Module Utility
    Public Structure strucColors
        Public PassColor As Color '= Color.Green
        Public FailColor As Color '= Color.Red
        Public ErrorColor As Color '= Color.Yellow
        Public InProgressColor As Color '= Color.Magenta
        Public OnColor As Color
        Public OffColor As Color
        Public SkippedColor As Color
        Public WaitForStartColor As Color
        Public DefaultControlBackcolor As Color 'Window
        Friend Sub InitializeDefaults()
            Me.PassColor = Color.LightGreen
            Me.FailColor = Color.Red
            Me.ErrorColor = Color.Yellow
            Me.InProgressColor = Color.Wheat
            Me.OnColor = Color.DarkGreen
            Me.OffColor = Color.LightBlue
            Me.DefaultControlBackcolor = System.Drawing.SystemColors.Control
            Me.WaitForStartColor = Color.Goldenrod
            Me.SkippedColor = Color.DarkGray
        End Sub
    End Structure

    Public Structure strConfigFileParams
        Public Filename As String
        Public RequiredCrc32 As Long ' -1 ignores the CRC check
        Public Sub InitMe()
            Filename = ""
            RequiredCrc32 = -1
        End Sub
    End Structure

    Public Structure GlobalVarType
        'Structure containing basic information needed across the entire application
        Public Title As String
        Public Version As String ' Ensure all reporting of version have the same format

        Public ConfigFileParams As strConfigFileParams

        Public Colors As strucColors
        Public SystemName As String
        Public SystemDescription As String
        Public Environ As clsEnvironInfo

        Public Sub InitializeDefaults()
            'Me.Version = My.Application.Info.Version.Major.ToString & "." & My.Application.Info.Version.Minor.ToString.PadLeft(2, "0")
            Me.Version = My.Application.Info.Version.Major & My.Application.Info.Version.Minor & "-" & My.Application.Info.Version.MinorRevision & My.Application.Info.Version.Revision
            Me.Title = My.Application.Info.AssemblyName & "  Version: " & Me.Version
            Me.ConfigFileParams.InitMe()
            Me.Colors.InitializeDefaults()
            Me.Environ = New clsEnvironInfo

            Dim sComputer = "."
            'Computer Description is the System ID (TEST3-System2, TEST3-System3, etc.)
            Dim Obj = GetObject("winmgmts:\\" & sComputer & "\root\cimv2").InstancesOf("Win32_OperatingSystem")
            For Each x In Obj
                Me.SystemDescription = x.description.ToString
            Next
            Me.SystemName = My.Computer.Name
        End Sub
    End Structure
    Public glo As GlobalVarType

    Friend TestSetControl As New InstrumentControl
    Public Sequencer As New TestSequencer

    'Public ParamHandler As New ParameterHandler
    'Public Sequence As New Collection 'Contains only iOperationInformation

    Public Const NL As String = vbNewLine
    Public Const NL2 As String = NL & NL
    Public Const OK As String = "OK"

    Private MsgIndicators As New Collection

    Public Sub AddStatusMessageIndicator(ByVal TheIndicator As Windows.Forms.RichTextBox)
        RemoveStatusIndicator(TheIndicator) 'This ensures the indicator only appears once
        MsgIndicators.Add(TheIndicator)
    End Sub
    Public Sub RemoveStatusIndicator(ByVal RemoveThisIndicator As Windows.Forms.RichTextBox)
        Dim i As Integer
        Dim AllGone As Boolean
        Do
            AllGone = True
            For i = 1 To MsgIndicators.Count
                If MsgIndicators.Item(i) Is RemoveThisIndicator Then
                    MsgIndicators.Remove(i)
                    AllGone = False
                    Exit For
                End If
            Next
        Loop Until AllGone
    End Sub

    Public Sub AddErrorMessage(MessageToAdd As String)
        AddStatusMessage(MessageToAdd, 0)
    End Sub

    Public Sub AddWarningMessage(MessageToAdd As String)
        Dim Lns() As String = MessageToAdd.Split(NL)
        For Each Liney As String In Lns
            Call AddStatusMessage("Warning: " & Liney.Replace(NL, ""), 1, Color.OrangeRed)
            My.Application.DoEvents()
        Next
    End Sub
    Public Sub AddStatusMessage(ByVal MessageToAdd As String, ByVal Level As Integer)
        AddStatusMessage(MessageToAdd, Level, Color.Black)
    End Sub
    Public Sub AddStatusMessage(ByVal MessageToAdd As String, ByVal Level As Integer, ByVal TheColor As Color)
        For i As Integer = 1 To Level
            MessageToAdd = "... " & MessageToAdd
        Next
        MessageToAdd &= NL

        For Each MsgIndi As Windows.Forms.RichTextBox In MsgIndicators
            Dim StartPos As Integer = MsgIndi.Text.Length + 1

            MsgIndi.AppendText(MessageToAdd)
            MsgIndi.Select(StartPos, MessageToAdd.Length)
            MsgIndi.SelectionColor = TheColor
        Next
    End Sub
    Public Sub AddStatusMessage(ByVal MessageToAdd As String)
        Call AddStatusMessage(MessageToAdd, 0, Color.Black)
    End Sub
    Public Sub ClearStatusMessage()
        Dim RichTBox As New RichTextBox
        Dim TBox As New TextBox

        Dim TheItem As Object

        Dim TlenStart As Integer
        For Each TheItem In MsgIndicators
            Try
                'Perferred indicator
                RichTBox = TheItem
                TlenStart = RichTBox.TextLength
                RichTBox.AppendText("12345") 'Set color back to default
                RichTBox.Select(TlenStart, RichTBox.TextLength - TlenStart - 1)
                RichTBox.SelectionColor = Color.Black
                RichTBox.Clear()
            Catch ex As Exception
                Try
                    'Regular text box indicator
                    TBox = TheItem
                    TBox.Clear()
                Catch ex2 As Exception
                    TheItem.text = ""
                End Try
            End Try
        Next
    End Sub
    Public Sub ParseLimitsFromString(ByVal LimitsString As String, ByRef LowerLimit As Double, ByRef UpperLimit As Double)
        Try
            Dim Delim As String = ":"
            LimitsString = LimitsString.Replace("[", "").Replace("]", "").Replace("{", "").Replace("}", "") 'Take out brackets, if present
            Dim Vals() As String = LimitsString.Split(Delim)
            LowerLimit = Val(Vals(0))
            UpperLimit = Val(Vals(1)) 'Error out with format errors
        Catch ex As Exception
            Err.Raise(10001, Nothing, "Argument Format Error: " & LimitsString & " Expected: [LL:UL]")
        End Try

    End Sub
    Public Sub ErrorHandler_General(ByVal ex As Exception)
        ErrorHandler_General(ex, My.Settings.DisplayErrorMessagebox)
    End Sub
    Public Sub ErrorHandler_General(ByVal ex As Exception, ByVal DisplayMessagebox As Boolean)
        AddStatusMessage("Error: Source: " & ex.Source, 0)
        AddStatusMessage(ex.Message, 0)
        Dim TheMsg As String = ex.Source & NL & ex.Message
        If DisplayMessagebox Then
            MsgBox(TheMsg, MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, Err.Source)
        End If
    End Sub

    Public Sub ErrorHandler_General(ByVal ex As Exception, ByVal SourceFunct As String, ByVal DisplayMessagebox As Boolean)
        AddStatusMessage("Error: Source: " & ex.Source & " Message: " & ex.Message, 0)
        AddStatusMessage(ex.Message, 0)
        If DisplayMessagebox Then
            MsgBox(ex.Message, MsgBoxStyle.OkOnly + MsgBoxStyle.Critical, ex.Source)
        End If
    End Sub

    Public Sub DelaySec(ByVal Seconds As Double)
        Delay(Seconds * 1000)
    End Sub
    Public Sub Delay(ByVal millisecs As Long)
        Dim Sw As New Stopwatch
        Sw.Start()
        Do
            My.Application.DoEvents()
        Loop Until Sw.ElapsedMilliseconds >= millisecs
    End Sub
    Public Function InRange(ByRef value As Double, ByRef LL As Double, ByRef UL As Double) As Boolean
        InRange = value >= LL And value <= UL
    End Function
    Public Sub ArrayToUCase(ByRef TheArray() As String)
        Dim i As Integer
        For i = 0 To UBound(TheArray)
            TheArray(i) = TheArray(i).ToUpper.Trim
        Next
    End Sub
    Public Function Double2Int(ByRef Doub As Double) As Short
        'This avoids overflow
        Const Biggest As Short = &H7FFF
        Const Smallest As Short = -32768
        If Doub >= Biggest Then
            Double2Int = CShort(Biggest)
            Exit Function
        End If
        If Doub <= Smallest Then
            Double2Int = Smallest
            Exit Function
        End If
        Double2Int = CShort(Doub)
    End Function
    Public Sub String2ByArr(ByVal TheString As String, ByRef ByArr() As Byte)
        Dim i As Short

        ReDim ByArr(Len(TheString) - 1)
        For i = 1 To Len(TheString)
            ByArr(i - 1) = Asc(Mid(TheString, i, 1))
        Next
    End Sub
    Public Sub ShortToBytes(ByVal nWord As Short, ByRef msb As Byte, ByRef lsb As Byte)
        Dim NegSign As Boolean
        NegSign = False
        If nWord < 0 Then
            nWord = nWord + 32768
            NegSign = True
        End If
        msb = nWord \ 256
        lsb = nWord - msb * 256
        If NegSign Then
            msb = msb + &H80
        End If
    End Sub
    Public Sub ShortToBytesU(ByVal nWord As UInt16, ByRef msb As Byte, ByRef lsb As Byte)
        'Dim NegSign As Boolean
        'NegSign = False
        'If nWord < 0 Then
        '    nWord = nWord + 32768
        '    NegSign = True
        'End If
        msb = nWord \ 256
        lsb = nWord - msb * 256
        'If NegSign Then
        '    msb = msb + &H80
        'End If
    End Sub
    Public Function HexBytesToString(ByVal HexBytes As String) As String
        If HexBytes Is Nothing Then Return ""
        Dim Byts() As String
        HexBytesToString = ""
        Byts = Split(HexBytes.Trim)
        Dim By As String
        For Each By In Byts
            HexBytesToString = HexBytesToString & Chr(Val("&H" & By))
        Next

    End Function
    Public Sub BytesToShort(ByRef msb As Byte, ByRef lsb As Byte, ByRef nWord As Short)

        Dim lWord As Integer = msb
        lWord = lWord * (2 ^ 8)
        Dim sLsb As Short = lsb
        lWord = lWord Or sLsb
        If lWord > Short.MaxValue Then
            Dim Mask As Integer = 2 ^ 15
            lWord = lWord And Not Mask
            nWord = lWord
            nWord = nWord Or &H8000S
        Else
            nWord = lWord
        End If
    End Sub
    Public Sub Int2Bytes(ByVal iInt As Short, ByRef msb As Byte, ByRef lsb As Byte)
        lsb = CByte(iInt And &HFF)
        Dim TheBit As Short
        TheBit = iInt And &H8000
        iInt = iInt And &H7F00
        iInt = iInt / (2 ^ 8)
        If TheBit <> 0 Then iInt = iInt Or &H80 'Recover that bit
        msb = CByte(iInt)
    End Sub
    Public Sub Int2ByteArray(ByVal iInt As Short, ByRef ByArr() As Byte)
        Dim msb, lsb As Byte
        Call Int2Bytes(iInt, msb, lsb)
        ReDim ByArr(1)
        ByArr(0) = lsb
        ByArr(1) = msb
    End Sub
    Public Function Byte2Hex(ByRef bByte As Byte) As String
        Byte2Hex = Hex(bByte)
        If Len(Byte2Hex) < 2 Then Byte2Hex = "0" & Byte2Hex
    End Function
    Public Function Short2Hex(ByVal iInt As Short) As String
        Short2Hex = Hex(iInt)
        Do Until Len(Short2Hex) >= 4
            Short2Hex = "0" & Short2Hex
        Loop
    End Function
    Public Function Long2Hex(ByVal lLong As Integer) As String
        Long2Hex = Hex(lLong)
        Do Until Len(Long2Hex) >= 8
            Long2Hex = "0" & Long2Hex
        Loop
    End Function
    Public Function Double2Hex(ByVal TheDouble As Double) As String
        Dim lMax As Short
        Dim Umax As Short
        lMax = -32768
        Umax = &H7FFF
        If TheDouble < lMax Then TheDouble = lMax
        If TheDouble > Umax Then TheDouble = Umax
        TheDouble = System.Math.Round(TheDouble, 0)
        Double2Hex = Utility.Short2Hex(TheDouble)
    End Function
    Public Function ByteArr2String(ByRef ByArr() As Byte) As String
        If ByArr Is Nothing Then Return ""
        ByteArr2String = "" 'LL
        Dim By As Short
        For By = LBound(ByArr) To UBound(ByArr)
            ByteArr2String = ByteArr2String & Utility.Byte2Hex(ByArr(By)) & " "
        Next
    End Function
    Public Function UInt2Hex(ByVal Uintt As UInteger) As String
        Return Hex(Uintt)
    End Function
    Public Function Hex2UInt(ByVal ExSerial As String) As UInteger

        If ExSerial.ToLower.StartsWith("0x") Then ExSerial = Mid(ExSerial, 3)
        If ExSerial.ToLower.StartsWith("&h") Then ExSerial = Mid(ExSerial, 3)
        Dim sB1 As String = "&H" & Mid(ExSerial, 1, 1)
        Dim sB2 As String = "&H" & Mid(ExSerial, 2, 1)
        Dim sB3 As String = "&H" & Mid(ExSerial, 3, 1)
        Dim sB4 As String = "&H" & Mid(ExSerial, 4, 1)

        Dim Byt As Byte
        Byt = Val(sB1)
        Hex2UInt = Byt
        Hex2UInt = Hex2UInt * (2 ^ 4)

        Byt = Val(sB2)
        Hex2UInt = Hex2UInt Or Byt
        Hex2UInt = Hex2UInt * (2 ^ 4)

        Byt = Val(sB3)
        Hex2UInt = Hex2UInt Or Byt
        Hex2UInt = Hex2UInt * (2 ^ 4)

        Byt = Val(sB4)
        Hex2UInt = Hex2UInt Or Byt
        'Hex2UInt = Hex2UInt * (2 ^ 4)

    End Function
    Public Function ShortToUShort(ByVal TheShort As Short) As UShort
        'VS has trouble assigning if the Short is negative.
        'This maps bit-for-bit without regard to sign. 
        ShortToUShort = CUShort(TheShort And &H7FFFS)
        If TheShort < 0 Then
            ShortToUShort = ShortToUShort Or &H8000US
        End If
    End Function
    Public Function UShortToShort(ByVal TheUShort As UShort) As Short
        If (TheUShort And &H8000US) = UShortToShort Then
            'Positive Number
            Return TheUShort
        Else
            TheUShort = TheUShort And &H7FFFUS
            UShortToShort = TheUShort
            UShortToShort = UShortToShort Or &H8000S
        End If
    End Function
    Public Function ArrayContains(SearchArray() As String, KeyToFind As String) As Boolean
        ' Same function as Array.Contain(Key) as boolean in Framework 4.0
        ' However, FW 4.0 is not supported by the DalSemi stuff, so have to do it the hard way
        ' Case insensitive search
        For Each TestKey As String In SearchArray
            If TestKey.Trim.ToUpper = KeyToFind.Trim.ToUpper Then
                Return True
            End If
        Next
        Return False
    End Function
    Public Function ArrayContains(SearchArray() As Integer, Element As Integer) As Boolean
        For Each TestElement As Integer In SearchArray
            If TestElement = Element Then
                Return True
            End If
        Next
        Return False
    End Function
    'Byte/SByte Conversion
    'Byt(i) SByt(i) Hex(Byt(i) Hex(SByt(i)) 
    '  0       0        0       0
    '  1       1        1       1
    '  2       2        2       2
    '  3       3        3       3
    '  4       4        4       4
    '  5       5        5       5
    '  6       6        6       6
    '  7       7        7       7
    '  8       8        8       8
    '  9       9        9       9
    ' 10       10        A       A
    ' 11       11        B       B
    ' 12       12        C       C
    ' 13       13        D       D
    ' 14       14        E       E
    ' 15       15        F       F
    ' 16       16        10       10
    ' 17       17        11       11
    ' 18       18        12       12
    ' 19       19        13       13
    ' 20       20        14       14
    ' 21       21        15       15
    ' 22       22        16       16
    ' 23       23        17       17
    ' 24       24        18       18
    ' 25       25        19       19
    ' 26       26        1A       1A
    ' 27       27        1B       1B
    ' 28       28        1C       1C
    ' 29       29        1D       1D
    ' 30       30        1E       1E
    ' 31       31        1F       1F
    ' 32       32        20       20
    ' 33       33        21       21
    ' 34       34        22       22
    ' 35       35        23       23
    ' 36       36        24       24
    ' 37       37        25       25
    ' 38       38        26       26
    ' 39       39        27       27
    ' 40       40        28       28
    ' 41       41        29       29
    ' 42       42        2A       2A
    ' 43       43        2B       2B
    ' 44       44        2C       2C
    ' 45       45        2D       2D
    ' 46       46        2E       2E
    ' 47       47        2F       2F
    ' 48       48        30       30
    ' 49       49        31       31
    ' 50       50        32       32
    ' 51       51        33       33
    ' 52       52        34       34
    ' 53       53        35       35
    ' 54       54        36       36
    ' 55       55        37       37
    ' 56       56        38       38
    ' 57       57        39       39
    ' 58       58        3A       3A
    ' 59       59        3B       3B
    ' 60       60        3C       3C
    ' 61       61        3D       3D
    ' 62       62        3E       3E
    ' 63       63        3F       3F
    ' 64       64        40       40
    ' 65       65        41       41
    ' 66       66        42       42
    ' 67       67        43       43
    ' 68       68        44       44
    ' 69       69        45       45
    ' 70       70        46       46
    ' 71       71        47       47
    ' 72       72        48       48
    ' 73       73        49       49
    ' 74       74        4A       4A
    ' 75       75        4B       4B
    ' 76       76        4C       4C
    ' 77       77        4D       4D
    ' 78       78        4E       4E
    ' 79       79        4F       4F
    ' 80       80        50       50
    ' 81       81        51       51
    ' 82       82        52       52
    ' 83       83        53       53
    ' 84       84        54       54
    ' 85       85        55       55
    ' 86       86        56       56
    ' 87       87        57       57
    ' 88       88        58       58
    ' 89       89        59       59
    ' 90       90        5A       5A
    ' 91       91        5B       5B
    ' 92       92        5C       5C
    ' 93       93        5D       5D
    ' 94       94        5E       5E
    ' 95       95        5F       5F
    ' 96       96        60       60
    ' 97       97        61       61
    ' 98       98        62       62
    ' 99       99        63       63
    '100       100        64       64
    '101       101        65       65
    '102       102        66       66
    '103       103        67       67
    '104       104        68       68
    '105       105        69       69
    '106       106        6A       6A
    '107       107        6B       6B
    '108       108        6C       6C
    '109       109        6D       6D
    '110       110        6E       6E
    '111       111        6F       6F
    '112       112        70       70
    '113       113        71       71
    '114       114        72       72
    '115       115        73       73
    '116       116        74       74
    '117       117        75       75
    '118       118        76       76
    '119       119        77       77
    '120       120        78       78
    '121       121        79       79
    '122       122        7A       7A
    '123       123        7B       7B
    '124       124        7C       7C
    '125       125        7D       7D
    '126       126        7E       7E
    '127       127        7F       7F
    '128       -128        80       80
    '129       -127        81       81
    '130       -126        82       82
    '131       -125        83       83
    '132       -124        84       84
    '133       -123        85       85
    '134       -122        86       86
    '135       -121        87       87
    '136       -120        88       88
    '137       -119        89       89
    '138       -118        8A       8A
    '139       -117        8B       8B
    '140       -116        8C       8C
    '141       -115        8D       8D
    '142       -114        8E       8E
    '143       -113        8F       8F
    '144       -112        90       90
    '145       -111        91       91
    '146       -110        92       92
    '147       -109        93       93
    '148       -108        94       94
    '149       -107        95       95
    '150       -106        96       96
    '151       -105        97       97
    '152       -104        98       98
    '153       -103        99       99
    '154       -102        9A       9A
    '155       -101        9B       9B
    '156       -100        9C       9C
    '157       -99        9D       9D
    '158       -98        9E       9E
    '159       -97        9F       9F
    '160       -96        A0       A0
    '161       -95        A1       A1
    '162       -94        A2       A2
    '163       -93        A3       A3
    '164       -92        A4       A4
    '165       -91        A5       A5
    '166       -90        A6       A6
    '167       -89        A7       A7
    '168       -88        A8       A8
    '169       -87        A9       A9
    '170       -86        AA       AA
    '171       -85        AB       AB
    '172       -84        AC       AC
    '173       -83        AD       AD
    '174       -82        AE       AE
    '175       -81        AF       AF
    '176       -80        B0       B0
    '177       -79        B1       B1
    '178       -78        B2       B2
    '179       -77        B3       B3
    '180       -76        B4       B4
    '181       -75        B5       B5
    '182       -74        B6       B6
    '183       -73        B7       B7
    '184       -72        B8       B8
    '185       -71        B9       B9
    '186       -70        BA       BA
    '187       -69        BB       BB
    '188       -68        BC       BC
    '189       -67        BD       BD
    '190       -66        BE       BE
    '191       -65        BF       BF
    '192       -64        C0       C0
    '193       -63        C1       C1
    '194       -62        C2       C2
    '195       -61        C3       C3
    '196       -60        C4       C4
    '197       -59        C5       C5
    '198       -58        C6       C6
    '199       -57        C7       C7
    '200       -56        C8       C8
    '201       -55        C9       C9
    '202       -54        CA       CA
    '203       -53        CB       CB
    '204       -52        CC       CC
    '205       -51        CD       CD
    '206       -50        CE       CE
    '207       -49        CF       CF
    '208       -48        D0       D0
    '209       -47        D1       D1
    '210       -46        D2       D2
    '211       -45        D3       D3
    '212       -44        D4       D4
    '213       -43        D5       D5
    '214       -42        D6       D6
    '215       -41        D7       D7
    '216       -40        D8       D8
    '217       -39        D9       D9
    '218       -38        DA       DA
    '219       -37        DB       DB
    '220       -36        DC       DC
    '221       -35        DD       DD
    '222       -34        DE       DE
    '223       -33        DF       DF
    '224       -32        E0       E0
    '225       -31        E1       E1
    '226       -30        E2       E2
    '227       -29        E3       E3
    '228       -28        E4       E4
    '229       -27        E5       E5
    '230       -26        E6       E6
    '231       -25        E7       E7
    '232       -24        E8       E8
    '233       -23        E9       E9
    '234       -22        EA       EA
    '235       -21        EB       EB
    '236       -20        EC       EC
    '237       -19        ED       ED
    '238       -18        EE       EE
    '239       -17        EF       EF
    '240       -16        F0       F0
    '241       -15        F1       F1
    '242       -14        F2       F2
    '243       -13        F3       F3
    '244       -12        F4       F4
    '245       -11        F5       F5
    '246       -10        F6       F6
    '247       -9        F7       F7
    '248       -8        F8       F8
    '249       -7        F9       F9
    '250       -6        FA       FA
    '251       -5        FB       FB
    '252       -4        FC       FC
    '253       -3        FD       FD
    '254       -2        FE       FE
    '255       -1        FF       FF
    Public Function Byte2SByte(ByVal UnsignedByte8 As Byte) As SByte
        Byte2SByte = IIf(UnsignedByte8 < 128, UnsignedByte8, UnsignedByte8 - 256)
    End Function
    Public Function SByte2Byte(ByVal S8 As SByte) As Byte
        'Changes Signed_8 to Unsigned 8
        'Not pretty, but it works
        For SByte2Byte = Byte.MinValue To Byte.MaxValue
            If Hex(SByte2Byte) = Hex(S8) Then
                Exit Function
            End If
        Next
    End Function
    Public Function Hex16ToUShort(ByVal Hex16 As String) As UShort
        'Hex16 numbers to UShort
        'Return Val(Hex16 & "US") doesn't work. Returns an Overflow error if Hex16 > &8FFF
        'So .....
        Hex16 = Hex16.Trim.ToUpper.ToUpper.Replace("OX", "&H")
        Dim IsHex = Hex16.StartsWith("&H")
        Hex16 = Hex16.Replace("&H", "").PadLeft(4, "0")
        Hex16 = Right(Hex16, 4) 'Only four digits
        If IsHex Then Hex16 = "&H" & Hex16 'Put back the "&H", if it was there to begin with
        Dim iTmp As Short = Val(Hex16)

        Dim IsNeg As Boolean = (iTmp And &H8000) <> 0
        iTmp = iTmp And &H7FFF
        Dim usTmp As UShort = iTmp
        If IsNeg Then
            usTmp = usTmp Or &H8000US
        End If
        Return usTmp

    End Function
    Public Function ArraysAreSame(ByVal Arr1() As Byte, ByVal Arr2() As Byte) As Boolean
        If Arr1 Is Nothing Or Arr2 Is Nothing Then Return False
        If UBound(Arr1) = UBound(Arr2) Then
            Dim i As Integer
            For i = 0 To UBound(Arr1)
                If Arr1(i) <> Arr2(i) Then Return False
            Next
            Return True
        Else
            Return False
        End If
    End Function
    Public Function ArraysAreSame(ByVal Arr1() As Short, ByVal Arr2() As Short) As Boolean
        If UBound(Arr1) = UBound(Arr2) Then
            Dim i As Integer
            For i = 0 To UBound(Arr1)
                If Arr1(i) <> Arr2(i) Then Return False
            Next
            Return True
        Else
            Return True
        End If
    End Function
    Public Function NowFormatted() As String
        Return Format(Now, "MM/dd/yyyy hh:mm:ss")
    End Function
    Public Function RoundOff(ByRef Numbr As Double, ByVal Digits As Integer) As Double
        Numbr = Math.Round(Numbr, Digits)
        Return Numbr
    End Function
    Public Sub CopyArraySByteToSByte(ByRef BigArray() As SByte, ReadBuffer() As SByte)
        For Each Element As SByte In ReadBuffer
            If BigArray Is Nothing Then
                ReDim BigArray(0)
            Else
                ReDim Preserve BigArray(BigArray.GetUpperBound(0) + 1)  'Not elegant, but works well
            End If
            BigArray(BigArray.GetUpperBound(0)) = Element
        Next
    End Sub
    Public Sub CopyArraySByteToByte(ByRef BigArray() As Byte, ReadBuffer() As SByte)
        For Each Element As SByte In ReadBuffer
            If BigArray Is Nothing Then
                ReDim BigArray(0)
            Else
                ReDim Preserve BigArray(BigArray.GetUpperBound(0) + 1)  'Not elegant, but works well
            End If
            If Element >= 0 Then
                BigArray(BigArray.GetUpperBound(0)) = Element
            Else
                Element = Element And &H7F
                BigArray(BigArray.GetUpperBound(0)) = Element
                BigArray(BigArray.GetUpperBound(0)) = BigArray(BigArray.GetUpperBound(0)) Or &H80
            End If
        Next
    End Sub
End Module
Public Class clsMyLogw
    Private pLogFileName As String
    Public StartLogging As Boolean
    Public Sub New(ByVal LogFileName As String)
        On Error Resume Next
        pLogFileName = LogFileName
        'My.Computer.FileSystem.DeleteFile(LogFileName)
        'Call WriteEntry("********************* Opening Log File *********************" & NL)
    End Sub
    Public Sub WriteEntry(ByVal ByArr() As Byte, ByVal Message As String)
        If Not StartLogging Then Exit Sub
        On Error Resume Next
        Dim Stb As New System.Text.StringBuilder(Message)
        Stb.Append(" ")
        Dim i As Integer
        For i = 0 To UBound(ByArr)
            Stb.Append(Utility.Byte2Hex(ByArr(i)))
            Stb.Append(" ")
        Next
        WriteEntry(Stb.ToString)
    End Sub
    Public Sub WriteEntry(ByVal Message As String)
        If Not StartLogging Then Exit Sub
        On Error Resume Next
        Dim Stb As New System.Text.StringBuilder(Format(Now, "hh:mm:ss"))
        Stb.Append("--> ")
        Stb.Append(Message)
        Stb.Append(NL)
        My.Computer.FileSystem.WriteAllText(pLogFileName, Stb.ToString, True)
    End Sub
    Public Sub WriteException(ByVal Ex As Exception, ByVal Source As String)
        If Not StartLogging Then Exit Sub
        On Error Resume Next
        Dim Stb As New System.Text.StringBuilder(Format(Now, "hh:mm:ss"))
        Stb.Append(" *Exception* Source--> ")
        Stb.Append(Source)
        Stb.Append("--> ")
        Stb.Append(NL)
        Stb.Append(Ex.Message)
        My.Computer.FileSystem.WriteAllText(pLogFileName, Stb.ToString, True)
    End Sub
    Public Sub ClearLogFile()
        On Error Resume Next
        Kill(pLogFileName)
    End Sub
End Class