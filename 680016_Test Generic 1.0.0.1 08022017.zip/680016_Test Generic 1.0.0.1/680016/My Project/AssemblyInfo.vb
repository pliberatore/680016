﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("680016 Generic for bq78350")>
<Assembly: AssemblyDescription("p/n 680016")>
<Assembly: AssemblyCompany("iTECH")>
<Assembly: AssemblyProduct("TEST3 Control Application")>
<Assembly: AssemblyCopyright("Copyright ©  2017, iTECH")> 
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(True)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("36eba076-a93d-49a8-8cc5-535da8f6f1df")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("680.016.01.100")>
<Assembly: AssemblyFileVersion("680.016.01.100")>
