﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StatusIndicator
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.gbxPallet1 = New System.Windows.Forms.GroupBox()
        Me.tlpPallet = New System.Windows.Forms.TableLayoutPanel()
        Me.MyDataGridView = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.mnuDataGridPopup = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopySelectionToClipboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyAllToClipboardToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblPallet = New System.Windows.Forms.Label()
        Me.gbxPallet1.SuspendLayout()
        Me.tlpPallet.SuspendLayout()
        CType(Me.MyDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuDataGridPopup.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxPallet1
        '
        Me.gbxPallet1.Controls.Add(Me.tlpPallet)
        Me.gbxPallet1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gbxPallet1.Location = New System.Drawing.Point(0, 0)
        Me.gbxPallet1.Name = "gbxPallet1"
        Me.gbxPallet1.Size = New System.Drawing.Size(513, 366)
        Me.gbxPallet1.TabIndex = 1
        Me.gbxPallet1.TabStop = False
        Me.gbxPallet1.Text = "Pallet "
        '
        'tlpPallet
        '
        Me.tlpPallet.ColumnCount = 2
        Me.tlpPallet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpPallet.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.tlpPallet.Controls.Add(Me.MyDataGridView, 0, 1)
        Me.tlpPallet.Controls.Add(Me.lblPallet, 0, 0)
        Me.tlpPallet.Dock = System.Windows.Forms.DockStyle.Fill
        Me.tlpPallet.Location = New System.Drawing.Point(3, 16)
        Me.tlpPallet.Name = "tlpPallet"
        Me.tlpPallet.RowCount = 2
        Me.tlpPallet.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.53012!))
        Me.tlpPallet.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.46988!))
        Me.tlpPallet.Size = New System.Drawing.Size(507, 347)
        Me.tlpPallet.TabIndex = 0
        '
        'MyDataGridView
        '
        Me.MyDataGridView.AllowUserToAddRows = False
        Me.MyDataGridView.AllowUserToDeleteRows = False
        Me.MyDataGridView.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        Me.MyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MyDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4})
        Me.tlpPallet.SetColumnSpan(Me.MyDataGridView, 2)
        Me.MyDataGridView.ContextMenuStrip = Me.mnuDataGridPopup
        Me.MyDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MyDataGridView.Location = New System.Drawing.Point(3, 46)
        Me.MyDataGridView.Name = "MyDataGridView"
        Me.MyDataGridView.ReadOnly = True
        Me.MyDataGridView.Size = New System.Drawing.Size(501, 298)
        Me.MyDataGridView.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Column1"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        '
        'Column2
        '
        Me.Column2.HeaderText = "Column2"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        '
        'Column3
        '
        Me.Column3.HeaderText = "Column3"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        '
        'Column4
        '
        Me.Column4.HeaderText = "Column4"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'mnuDataGridPopup
        '
        Me.mnuDataGridPopup.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopySelectionToClipboardToolStripMenuItem, Me.CopyAllToClipboardToolStripMenuItem, Me.PrintReportToolStripMenuItem, Me.OpenReportToolStripMenuItem})
        Me.mnuDataGridPopup.Name = "mnuDataGridPopup"
        Me.mnuDataGridPopup.Size = New System.Drawing.Size(225, 92)
        '
        'CopySelectionToClipboardToolStripMenuItem
        '
        Me.CopySelectionToClipboardToolStripMenuItem.Name = "CopySelectionToClipboardToolStripMenuItem"
        Me.CopySelectionToClipboardToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.CopySelectionToClipboardToolStripMenuItem.Text = "Copy Selection To Clipboard"
        '
        'CopyAllToClipboardToolStripMenuItem
        '
        Me.CopyAllToClipboardToolStripMenuItem.Name = "CopyAllToClipboardToolStripMenuItem"
        Me.CopyAllToClipboardToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.CopyAllToClipboardToolStripMenuItem.Text = "Copy All to Clipboard"
        '
        'PrintReportToolStripMenuItem
        '
        Me.PrintReportToolStripMenuItem.Name = "PrintReportToolStripMenuItem"
        Me.PrintReportToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.PrintReportToolStripMenuItem.Text = "Print Report"
        '
        'OpenReportToolStripMenuItem
        '
        Me.OpenReportToolStripMenuItem.Name = "OpenReportToolStripMenuItem"
        Me.OpenReportToolStripMenuItem.Size = New System.Drawing.Size(224, 22)
        Me.OpenReportToolStripMenuItem.Text = "Open Report"
        '
        'lblPallet
        '
        Me.lblPallet.AutoSize = True
        Me.tlpPallet.SetColumnSpan(Me.lblPallet, 2)
        Me.lblPallet.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lblPallet.Font = New System.Drawing.Font("Book Antiqua", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPallet.Location = New System.Drawing.Point(3, 0)
        Me.lblPallet.Name = "lblPallet"
        Me.lblPallet.Size = New System.Drawing.Size(501, 43)
        Me.lblPallet.TabIndex = 1
        Me.lblPallet.Text = "PASS"
        Me.lblPallet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StatusIndicator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.gbxPallet1)
        Me.Name = "StatusIndicator"
        Me.Size = New System.Drawing.Size(513, 366)
        Me.gbxPallet1.ResumeLayout(False)
        Me.tlpPallet.ResumeLayout(False)
        Me.tlpPallet.PerformLayout()
        CType(Me.MyDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuDataGridPopup.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gbxPallet1 As System.Windows.Forms.GroupBox
    Friend WithEvents MyDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents mnuDataGridPopup As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyAllToClipboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PrintReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpenReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopySelectionToClipboardToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Public WithEvents lblPallet As System.Windows.Forms.Label
    Public WithEvents tlpPallet As System.Windows.Forms.TableLayoutPanel

End Class
