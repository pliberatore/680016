﻿' DataCollection.vb
' Copyright 2017 iTECH Corporation
' Phil Liberatore
' pliberatore@itecheng.com
' Proprietary Information
'

Public Class DataCollection
    ' Class to collect, record and present test data from an individual test sequence
    ' All existing data is lost when a new sequence is started.
    '
    '   Collect test data
    '   Present test data
    '       'GUI Grid
    '       Generate XML record
    '       Generate printed report
    '       Generate TXT report
    '   Track test time
    '   Calculate and present Test Status (PASS, FAIL)
    '   Present ProcessStatus (Test_InProgress, Test_ReadyToStart)
    '
    ' Measurement data is presented on the GUI in datagridview objects
    ' Two data grid are needed
    '   EventGrid contains general information relating to the test sequence

    ' Initialization - Typically performed during form load event
    '   Dim TestData as new DataCollection
    '   TestData.InitMe(MeasurementDataGridViewObject, EventDataGridViewObject)
    ' 
    ' Start test sequence - Typically performed by the test sequencer
    '   TestData.StartNewTest
    '
    ' Measurement Recording
    '   There are multiple methods for recorded data because the .Net overloading functions are not perfect
    '   All methods follow the same format
    '       AddMeasurement_<data type>(TestID, MeasurementName, LowLimit, Upper Limit, Measured Value, Units)
    '           TestData.AddMeasurement_Double (...)
    '           TestData.AddMeasurement_Boolean (...) etc
    '   Each new measurement will be recorded in the MeasurementGrid
    '   If the TestID already appears in the grid, the information will be updated. Multiple measurements with identical TestID's are not possible
    '
    ' End of test sequence
    '   TestData.endtest

    Public Serial_ID As String = ""

    Public WithEvents MyStatusDisplay As StatusIndicator

    Public Enum enTestStatus
        Wait_For_Start
        Testing_In_Progress
        TEST_PASS
        TEST_FAIL
        Skipped
    End Enum
    Public Function GetMeasuredValue(ByVal MeasurementID As String) As Double
        'Returns MeasuredValue of current MeasurementID
        Dim Row As Windows.Forms.DataGridViewRow
        For Each Row In MyStatusDisplay.MyDataGridView.Rows
            Try
                If Row.Cells("TestID").Value.ToString.Trim.ToUpper = MeasurementID.ToUpper.Trim Then
                    Return Row.Cells("Measured").Value()
                End If
            Catch ex As Exception
                Stop
            End Try
        Next
        AddStatusMessage("MeasurementID Not Found: " & MeasurementID, 3, glo.Colors.FailColor) 'Handle error in calling function
        AddStatusMessage("*** Test Will Fail! ***", 3, glo.Colors.FailColor)
        Err.Raise(1001, "", "Measurement ID not produce priot to calling function: " & MeasurementID)
        Return False
    End Function

    Private pTestStatus As enTestStatus
    Public Property TestStatus() As DataCollection.enTestStatus
        Get
            Return pTestStatus
        End Get
        Set(value As DataCollection.enTestStatus)
            'Check for a status change here TODO
            pTestStatus = value
            Me.MyStatusDisplay.lblPallet.Text = pTestStatus.ToString.Replace("_", " ")
            ' Set the color here
            Select Case pTestStatus
                Case enTestStatus.Wait_For_Start
                    MyStatusDisplay.lblPallet.BackColor = glo.Colors.waitforstartcolor
                Case enTestStatus.Skipped
                    MyStatusDisplay.lblPallet.BackColor = glo.Colors.skippedcolor
                Case enTestStatus.Testing_In_Progress
                    MyStatusDisplay.lblPallet.BackColor = glo.Colors.InProgressColor
                Case enTestStatus.TEST_PASS
                    MyStatusDisplay.lblPallet.BackColor = glo.Colors.PassColor
                Case enTestStatus.TEST_FAIL
                    MyStatusDisplay.lblPallet.BackColor = glo.Colors.FailColor

            End Select
        End Set
    End Property

    Public Function AddMeasurement_Double(ByVal TestID As String, ByVal TestName As String, ByVal LL As Double, ByVal UL As Double, ByVal MeasuredValue As Double, ByVal MeasUnits As String, Optional Formt As String = "0.000") As Boolean        'These pretty much add measurements to Datagrid
        'Required  Parameter list
        ' Params(0)=TestID
        'Params(1)=MeasurementID (String)
        'Params(2)=Lower Limit (Double)
        'Params(3)=Measured Value (Double)
        'Params(4)=Upper Limit (Double)
        'Params(5)=Units (String)
        'Params(6)=Result (String) 'Pass' 'Fail'
        If Formt Is Nothing Then Formt = ""

        MeasuredValue = Math.Round(MeasuredValue, 3)
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Format(LL, Formt)
        Params(3) = Format(MeasuredValue, Formt) 'round off?
        Params(4) = Format(UL, Formt)
        Params(5) = MeasUnits
        AddMeasurement_Double = Val(Params(3)) >= Val(Params(2)) And Val(Params(3)) <= Val(Params(4))
        Params(6) = IIf(AddMeasurement_Double, "PASS", "FAIL")

        AddMeasurementToGrid(Params)
    End Function
    Public Function AddMeasurement_Boolean(ByVal TestID As String, ByVal TestName As String, ByVal Passed As Boolean) As Boolean
        'These pretty much add measurements to Datagrid
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = "1"
        Params(3) = IIf(Passed, 1, 0)
        Params(4) = "1"
        Params(5) = "p/f"
        AddMeasurement_Boolean = Passed
        Params(6) = IIf(AddMeasurement_Boolean, "PASS", "FAIL")

        AddMeasurementToGrid(Params)
    End Function
    Public Function AddMeasurement_Byte(ByVal TestID As String, ByVal TestName As String, ByVal LL As Byte, ByVal UL As Byte, ByVal MeasuredValue As Byte) As Boolean
        'These pretty much add measurements to Datagrid
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Hex(LL).PadLeft(2, "0")
        Params(3) = Hex(MeasuredValue).PadLeft(2, "0") 'round off?
        Params(4) = Hex(UL).PadLeft(2, "0")
        Params(5) = "usByte8"
        AddMeasurement_Byte = Params(3) >= Params(2) And Params(3) <= Params(4)
        Params(6) = IIf(AddMeasurement_Byte, "PASS", "FAIL")
        AddMeasurementToGrid(Params)
    End Function
    Public Function AddMeasurement_SByte(ByVal TestID As String, ByVal TestName As String, ByVal LL As SByte, ByVal UL As SByte, ByVal MeasuredValue As SByte) As Boolean
        'These pretty much add measurements to Datagrid
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Hex(LL).PadLeft(2, "0")
        Params(3) = Hex(MeasuredValue).PadLeft(2, "0") 'round off?
        Params(4) = Hex(UL).PadLeft(2, "0")
        Params(5) = "usByte8"
        AddMeasurement_SByte = Params(3) >= Params(2) And Params(3) <= Params(4)
        Params(6) = IIf(AddMeasurement_SByte, "PASS", "FAIL")
        AddMeasurementToGrid(Params)
    End Function
    Public Function AddMeasurement_Hex16(ByVal TestID As String, ByVal TestName As String, ByVal LowLimit As UShort, ByVal UpLimit As UShort, ByVal MeasuredValue As UShort) As Boolean
        'These pretty much add measurements to Datagrid
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Hex(LowLimit).PadLeft(4, "0")
        Params(3) = Hex(MeasuredValue).PadLeft(4, "0") 'round off?
        Params(4) = Hex(UpLimit).PadLeft(4, "0")
        Params(5) = "HEX16"
        AddMeasurement_Hex16 = MeasuredValue >= LowLimit And MeasuredValue <= UpLimit
        Params(6) = IIf(AddMeasurement_Hex16, "PASS", "FAIL")
        AddMeasurementToGrid(Params)
    End Function

    Public Function AddMeasurement_UShort(ByVal TestID As String, ByVal TestName As String, ByVal LowLimit As UShort, ByVal UpLimit As UShort, ByVal MeasuredValue As UShort) As Boolean
        'These pretty much add measurements to Datagrid
        'Add data formats are Unsigned-16 bit
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Hex(LowLimit).PadLeft(4, "0")
        Params(3) = Hex(MeasuredValue).PadLeft(4, "0") 'round off?
        Params(4) = Hex(UpLimit).PadLeft(4, "0")
        Params(5) = "usHEX16"
        AddMeasurement_UShort = MeasuredValue >= LowLimit And MeasuredValue <= UpLimit
        Params(6) = IIf(AddMeasurement_UShort, "PASS", "FAIL")
        AddMeasurementToGrid(Params)

    End Function
    Public Function AddMeasurement_Int(ByVal TestID As String, ByVal TestName As String, ByVal LL As Integer, ByVal UL As Integer, ByVal MeasuredValue As Integer, Units As String) As Boolean
        'These pretty much add measurements to Datagrid
        Dim Params(6) As String
        Params(0) = TestID
        Params(1) = TestName
        Params(2) = Hex(LL).PadLeft(8, "0")
        Params(3) = Hex(MeasuredValue).PadLeft(8, "0") 'round off?
        Params(4) = Hex(UL).PadLeft(8, "0")
        Params(5) = Units
        AddMeasurement_Int = MeasuredValue >= LL And MeasuredValue <= UL
        Params(6) = IIf(AddMeasurement_Int, "PASS", "FAIL")
        AddMeasurementToGrid(Params)
    End Function
    Private Sub AddMeasurementToGrid(ByVal Params() As String)
        Me.MyStatusDisplay.AddMeasurementToGrid(Params)
    End Sub

    Public Sub AddEventRecord(FieldName As String, FieldValue As String, Optional RecordPositionIfNew As Integer = 0, Optional MakeRowVisible As Boolean = False)
        ' Add the EventRecord to grid. Update record if the record already exists
        If FieldName Is Nothing Then FieldName = ""
        If FieldValue Is Nothing Then FieldValue = ""

        Dim EventFields() As String = {"*", FieldName, "", FieldValue, "", "", ""}
        Dim RecordExists As Boolean
        Dim Row As DataGridViewRow

        For Each Row In MyStatusDisplay.MyDataGridView.Rows
            If Row.Cells(0).Value = "*" And Row.Cells(1).Value = FieldName Then
                RecordExists = True
                Row.Cells(3).Value = FieldValue
            End If
        Next

        If Not RecordExists Then
            ' Add a new record in RecordPosition
            MyStatusDisplay.MyDataGridView.Rows.Insert(RecordPositionIfNew, EventFields)
            MyStatusDisplay.MyDataGridView.Rows.Item(RecordPositionIfNew).Visible = MakeRowVisible
        End If

    End Sub
    Private Sub PrintTestReport()
        'Uses temp file for printing
        Dim TmpPrintFile As String
        TmpPrintFile = My.Computer.FileSystem.GetTempFileName()
        Try
            GenerateTextTestReport(TmpPrintFile)
        Catch ex As Exception

        Finally
            My.Computer.FileSystem.DeleteFile(TmpPrintFile)
        End Try

    End Sub
    Public Sub GenerateTextTestReport(ByVal TestReportFileName As String)

    End Sub
    Public Sub PrintTestReport(ByVal FailOnly As Boolean)
        ''Sends Fail report to default printer
        Dim Msg As New System.Text.StringBuilder("Nexergy Fail Report")
        'Msg.AppendLine(StartTimeStamp() & "  " & glo.AssemblyType & "  " & glo.ProcessStep_ID)
        'Msg.AppendLine("Serial: " & Serial_ID & "  Test Set ID: " & INIfile.SetID & "  Operator: " & frmTestMain.txtTesterID.Text)
        'Msg.AppendLine("SW Version: " & My.Application.Info.Version.ToString)
        Msg.AppendLine()

        Dim Rw As DataGridViewRow
        Dim MeasID As String, LL As String, UL As String, Val As String, Result, Units As String
        For Each Rw In MyStatusDisplay.MyDataGridView.Rows
            MeasID = Rw.Cells(0).Value.ToString
            LL = Rw.Cells(1).Value.ToString
            'Val = Rw.Cells(2).Value.ToString
            'Units = Rw.Cells(3).Value.ToString
            'Result = Rw.Cells(4).Value.ToString
            UL = Rw.Cells(2).Value.ToString
            Val = Rw.Cells(3).Value.ToString
            Units = Rw.Cells(4).Value.ToString
            Result = Rw.Cells(5).Value.ToString

            If Result = "FAIL" Or Not FailOnly Then
                Msg.AppendLine(MeasID & "     <" & LL & "> " & Val & " <" & UL & ">    " & Units)
            End If
        Next
        Dim Prtr As New myPrinter
        Prtr.DocTitle = "Test Fail Report"
        Prtr.PrintText(Msg.ToString)

    End Sub

    Public TestTimer As New Stopwatch
    Public dateStartingTime As Date
    Public Function StartTimeStamp() As String
        Return Format(dateStartingTime, "MM/dd/yyyy HH:mm:ss")
    End Function
    Public Sub StartNewTest()
        Me.TestStatus = enTestStatus.Testing_In_Progress

        dateStartingTime = Now
        TestTimer = New Stopwatch
        TestTimer.Start()
        MyStatusDisplay.MyDataGridView.Rows.Clear()
        AddStatusMessage("Start Sequence at " & StartTimeStamp())
        Me.AddEventRecord("Timestamp", StartTimeStamp, 0)
    End Sub
    Public Sub EndTest()
        'Stops timer
        TestTimer.Stop()
        Dim ElapTestTime As Double = Math.Round(TestTimer.ElapsedMilliseconds / 1000.0, 3)
        AddStatusMessage("Sequence Complete. " & Format(ElapTestTime, "0.000") & " seconds")

        'Look at all the records. Set Test_Pass or Test_Fail as appropriate
        TestStatus = enTestStatus.TEST_PASS
        For Each Row As DataGridViewRow In MyStatusDisplay.MyDataGridView.Rows
            If Row.Cells(0).Value <> "*" And Row.Cells(6).Value.ToString.ToUpper <> "PASS" Then
                TestStatus = enTestStatus.TEST_FAIL
            End If
        Next

        Me.AddEventRecord("Test Time", ElapTestTime, 0, True)
        Me.AddEventRecord("Test Group Result", IIf(TestStatus = enTestStatus.TEST_PASS, "PASS", "FAIL"), 0, True)
    End Sub
    'This section generates the XML data file 
    Private XMLString As System.Text.StringBuilder
    Public Sub AppendAttribToXMLString(ByVal AttName As String, ByVal value As String)
        XMLString.Append(AttName & "=" & Chr(34) & value & Chr(34) & " ")
    End Sub
    Public Sub WriteXMLDataFile(ByVal TargFile As String)
        'Dim EventSection As New Chilkat.Xml
        'Joseph's XLS Sheet statement looks like
        '    <?xml-stylesheet type="text/xsl" href="C:\test.xsl"?>
        'I am changing the "'s to single quote

        ' Create header for XML file
        Dim Col As DataGridViewColumn
        Dim Row As DataGridViewRow

        'Get the column names in the dgv
        ' These names will be field names for the MEASUREMENT table
        Dim Labls() As String
        Labls = Nothing
        For Each Col In MyStatusDisplay.MyDataGridView.Columns
            If Labls Is Nothing Then
                ReDim Labls(0)
            Else
                ReDim Preserve Labls(UBound(Labls) + 1)
            End If
            Labls(UBound(Labls)) = Col.Name
        Next

        XMLString = New System.Text.StringBuilder
        XMLString.AppendLine("<?xml version=Q1.0Q encoding=Qutf-8Q ?>")
        'XMLString.AppendLine("<?xml-stylesheet type=Qtext/xslQ href=Q" & glo.Environ.XmlStyleFile & "Q ?>  ")
        XMLString.AppendLine("<?xml-stylesheet type=Qtext/xslQ href=Q" & My.Settings.XmlStyleFile_XSL & "Q ?>  ")
        XMLString.AppendLine("")
        XMLString.Replace("Q", Chr(34))

        'Go thru the datagridview. Add any "*" in column 0 must be an EVENT record. Add this to the EVENT table.
        XMLString.Append("<EVENT ")

        Dim Labl As String
        For Each Row In MyStatusDisplay.MyDataGridView.Rows
            If Row.Cells(0).Value = "*" Then
                Call AppendAttribToXMLString(Row.Cells(1).Value.ToString.Replace(" ", ""), Row.Cells(3).Value.ToString)
            End If
        Next
        XMLString.AppendLine(">") ' close the line

        'Go thru the datagridview again. Any line without a "*" in column 0 must be a measurement line, so add this record to the MEASUREMENT table
        For Each Row In MyStatusDisplay.MyDataGridView.Rows
            If Row.Cells(0).Value <> "*" Then
                XMLString.Append("<MEASUREMENT ")
                For Each Labl In Labls
                    Call AppendAttribToXMLString(Labl, Row.Cells(Labl).Value.ToString)
                Next
                XMLString.AppendLine("> </MEASUREMENT>")
            End If
        Next

        'Finally, close out the <EVENT> tag
        XMLString.AppendLine("</EVENT>")

        Try
            If TargFile <> "" Then
                My.Computer.FileSystem.WriteAllText(TargFile, XMLString.ToString, False)
            End If
        Catch ex As Exception
            ex.Source = "DataCollection.WriteXMLDataFile"
            Utility.ErrorHandler_General(ex, True)
        End Try

    End Sub
    'This section generates a CSV data file
    Private CSVString As System.Text.StringBuilder 'Faster than concatenating strings
    Public Sub AppendAttribToCSVString(ByVal AttName As String, ByVal value As String)
        CSVString.AppendLine(AttName & "," & value)
    End Sub
    Public Sub WriteCSVDataFile(ByVal TargFile As String)

        CSVString = New System.Text.StringBuilder("")
        'If Me.JobJumber <> "" Then Call AppendAttribToCSVString("JobNumber", Me.JobJumber)
        'If Me.Serial_ID <> "" Then Call AppendAttribToCSVString("SerialID", Me.Serial_ID)

        'Call AppendAttribToCSVString("AssemblyType", ReportInfo.AssemblyType)
        'Call AppendAttribToCSVString("AssemblyVersion", ReportInfo.AssemblyVersion)
        'Call AppendAttribToCSVString("TestPlanID", ReportInfo.TestPlanID)
        'Call AppendAttribToCSVString("TestPlanVersion", ReportInfo.TestPlanVersion)

        Call AppendAttribToCSVString("Timestamp", Me.StartTimeStamp & ", " & "YYYYMMDD_hhmmss")
        Call AppendAttribToCSVString("Result", Me.TestStatus.ToString)
        Call AppendAttribToCSVString("ElapsedTime", (TestTimer.ElapsedMilliseconds / 1000).ToString & ", seconds")

        Call AppendAttribToCSVString("Generic_SW_Rev", My.Application.Info.Version.ToString)



        Dim Col As DataGridViewColumn
        Dim Labls() As String
        Labls = Nothing
        For Each Col In MyStatusDisplay.MyDataGridView.Columns
            If Labls Is Nothing Then
                ReDim Labls(0)

                ReDim Preserve Labls(UBound(Labls) + 1)
            End If
            Labls(UBound(Labls)) = Col.Name
        Next
        Dim HeadLine As New System.Text.StringBuilder
        For Each ColLbl As String In Labls
            HeadLine.Append(ColLbl & ", ")
        Next
        CSVString.AppendLine()
        CSVString.AppendLine(HeadLine.ToString)


        'Dim ProdMeas As Chilkat.Xml
        Dim i As Integer
        Dim ThisVal As String
        For Each Rw In MyStatusDisplay.MyDataGridView.Rows
            For i = 0 To UBound(Labls)
                'ProdMeas.AddAttribute(Labls(i), Rw.Cells(i).Value)
                ThisVal = Rw.Cells(i).Value.ToString
                CSVString.Append(ThisVal & ", ")
            Next
            CSVString.Remove(CSVString.Length - 2, 2) 'Knock off last delimiter
            CSVString.AppendLine()
        Next
        Try
            If TargFile <> "" Then
                My.Computer.FileSystem.WriteAllText(TargFile, CSVString.ToString, False)
            End If
        Catch ex As Exception
            ex.Source = "DataCollection.WriteCSVDataFile"
            Utility.ErrorHandler_General(ex, True)
        End Try

    End Sub

    Protected Class myPrinter
        Friend TextToBePrinted As String
        Friend DocTitle As String
        Public Sub PrintFile(ByVal FileName As String)
            Try
                Dim TheText As String = My.Computer.FileSystem.ReadAllText(FileName)
                PrintText(TheText)
            Catch ex As Exception

            End Try
        End Sub
        Public Sub PrintText(ByVal text As String)
            TextToBePrinted = text
            Dim prn As New Printing.PrintDocument
            Using (prn)
                AddHandler prn.PrintPage, _
                   AddressOf Me.PrintPageHandler
                prn.DocumentName = DocTitle
                prn.Print()
                RemoveHandler prn.PrintPage, _
                   AddressOf Me.PrintPageHandler
            End Using
        End Sub
        Private Sub PrintPageHandler(ByVal sender As Object, _
           ByVal args As Printing.PrintPageEventArgs)
            Dim myFont As New Font("Microsoft San Serif", 10)
            args.Graphics.DrawString(TextToBePrinted, _
               New Font(myFont, FontStyle.Regular), _
               Brushes.Black, 50, 50)
        End Sub
    End Class

    Public Sub New()
        MyStatusDisplay = New StatusIndicator

        Me.TestStatus = enTestStatus.Wait_For_Start ' Sync indicators
    End Sub
End Class
