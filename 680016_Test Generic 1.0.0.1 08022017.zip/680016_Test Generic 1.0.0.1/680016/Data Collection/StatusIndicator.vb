﻿Public Class StatusIndicator

    Private FailCellStyle As DataGridViewCellStyle
    Private PassCellStyle As DataGridViewCellStyle
   
    Public Shadows Property Name As String
        Get
            Return Me.gbxPallet1.Text
        End Get
        Set(value As String)
            Me.gbxPallet1.Text = value
        End Set
    End Property

    Public Sub AddMeasurementToGrid(Params() As String)
        'Required  Parameter list
        ' Params(0)=TestID
        'Params(1)=MeasurementID (String)
        'Params(2)=Lower Limit (Double)
        'Params(3)=Measured Value (Double)
        'Params(4)=Upper Limit (Double)
        'Params(5)=Units (String)
        'Params(6)=Result (String) 'Pass' 'Fail'
        'Params(7)=Timestamp' yyyy-mm-dd hh:mm:ss

        'Add datestamp
        If Params.GetUpperBound(0) < 7 Then ReDim Preserve Params(7)
        Params(7) = Format(Now, "yyyy-MM-dd HH:mm:ss")

        Dim ThisRow As Integer, ThisIsRepeatMeas As Boolean = False
        ' Utility2.AddStatusMessage("Adding " & Params(0))
        For ThisRow = 0 To MyDataGridView.Rows.Count - 1
            If MyDataGridView.Rows.Item(ThisRow).Cells(0).Value = Params(0).ToString Then
                ThisIsRepeatMeas = True
                Exit For
            End If
        Next
        If Not ThisIsRepeatMeas Then
            MyDataGridView.Rows.Add(Params)
            ThisRow = MyDataGridView.Rows.Count - 1
        Else
            'add values into present line
            MyDataGridView.Rows(ThisRow).SetValues(Params)
        End If

        'RR.SetValues(Params)
        If Params(6).ToUpper.Trim = "FAIL" Then
            MyDataGridView.Rows(ThisRow).Cells(3).Style = FailCellStyle
        Else
            MyDataGridView.Rows(ThisRow).Cells(3).Style = PassCellStyle
        End If
        'Scroll down
        Dim LastLine As Integer = MyDataGridView.Rows.GetLastRow(DataGridViewElementStates.None)
        'RR = .Rows.Item(RunNum)
        MyDataGridView.FirstDisplayedScrollingRowIndex = ThisRow
        'My.Application.DoEvents()
    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        With Me.MyDataGridView
            'Set up cell styles
            .RowHeadersVisible = False
            .DefaultCellStyle.Font = New Font(.DefaultCellStyle.Font.FontFamily, 8, FontStyle.Regular)
            .ColumnHeadersDefaultCellStyle.Font = New Font(.DefaultCellStyle.Font.FontFamily, 8, FontStyle.Bold)
            FailCellStyle = .DefaultCellStyle.Clone
            FailCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            FailCellStyle.Font = New Font(FailCellStyle.Font.FontFamily, FailCellStyle.Font.Size, FontStyle.Bold, FailCellStyle.Font.Unit) 'Make BOLD
            FailCellStyle.BackColor = Color.Yellow
            FailCellStyle.ForeColor = Color.Red

            PassCellStyle = .DefaultCellStyle.Clone
            PassCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
            PassCellStyle.Font = New Font(PassCellStyle.Font.FontFamily, PassCellStyle.Font.Size, FontStyle.Bold, PassCellStyle.Font.Unit) 'Make BOLD
            'PassCellStyle.BackColor = Color.Yellow
            PassCellStyle.ForeColor = Color.Green

            .Rows.Clear()
            .Columns.Clear()

            'Every column in the grid will be reported to the "PRODUCTMEASUREMENT" table. However, it is not necessary to show them to the operator
            .ColumnCount = 8
            .Columns(0).Name = "TestID" 'These are the field names that will reported in the XML data
            .Columns(0).HeaderText = "ID"
            .Columns(0).Visible = True
            .Columns(0).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(0).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(0).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(1).Name = "Measurement" 'These are the field names that will reported in the XML data
            .Columns(1).HeaderText = "Measurement"
            .Columns(1).Visible = True
            .Columns(1).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(1).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
            .Columns(1).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleLeft
            .Columns(1).AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill

            .Columns(2).Name = "Lower" 'These are the field names that will reported in the XML data
            .Columns(2).HeaderText = "Lower"
            .Columns(2).Visible = True
            .Columns(2).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(2).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(2).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(3).Name = "Measured" 'These are the field names that will reported in the XML data
            .Columns(3).HeaderText = "Measured"
            .Columns(3).Visible = True
            .Columns(3).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(3).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(3).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(3).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(4).Name = "Upper" 'These are the field names that will reported in the XML data
            .Columns(4).HeaderText = "Upper"
            .Columns(4).Visible = True
            .Columns(4).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(4).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(4).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(4).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(5).Name = "Units" 'These are the field names that will reported in the XML data
            .Columns(5).HeaderText = "Units"
            .Columns(5).Visible = True
            .Columns(5).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(5).CellTemplate.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(5).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(5).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(6).Name = "Result" 'These are the field names that will reported in the XML data
            .Columns(6).HeaderText = "Result"
            .Columns(6).Visible = True
            .Columns(6).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(6).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(6).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells

            .Columns(7).Name = "Timestamp" 'These are the field names that will reported in the XML data
            .Columns(7).HeaderText = "Timestamp"
            .Columns(7).Visible = False
            .Columns(7).SortMode = DataGridViewColumnSortMode.NotSortable
            .Columns(7).HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter
            .Columns(7).AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells
        End With
    End Sub

    Private Sub CopySelectionToClipboardToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CopySelectionToClipboardToolStripMenuItem.Click
        Clipboard.Clear()
        Me.MyDataGridView.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        Clipboard.SetDataObject(MyDataGridView.GetClipboardContent)
    End Sub
    Private Sub CopyToClipboardToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CopyAllToClipboardToolStripMenuItem.Click
        Clipboard.Clear()
        Me.MyDataGridView.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText
        MyDataGridView.SelectAll()
        Clipboard.SetDataObject(MyDataGridView.GetClipboardContent)
    End Sub
    Private Sub PrintReportToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles PrintReportToolStripMenuItem.Click
        MsgBox("Printing Not Yet Enabled")
    End Sub
    Private Sub OpenReportToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles OpenReportToolStripMenuItem.Click
        MsgBox("Data Report Not Yet Available")
    End Sub
End Class
