﻿Public Class clsEnvironInfo
    ' Strcture for controlling TEST3 Environment variables
    ' 
    ' All values are accessed with Environment.SetEvironmentVariable and EnvironmentGetEnvironmentVariable
    '
    'This class standardizes the interface to avoid misspellings
    ' PropTable contains a list of all properties and the associated values for all properties
    ' It is possible to bind <instance>.PropTable to a datagridview (or other object) to automatically monitor the environment values
    '
    ' If you add a property, be sure to invoke the "RaiseEvent PropertyChanged()" event so your new property will be automatically added to PropTable.
    '   pIgnoreEvents is needed property hande recursive calls with the PropertyChanged() event
    '
    Public Event PropertyChanged()

    Private pPropTable As New dsetTestGeneric.EnviornmentDataTableDataTable
    Private pIgnoreEvents As Boolean

    Public ReadOnly Property PropTable As dsetTestGeneric.EnviornmentDataTableDataTable
        Get
            Call Me.UpdateTable()
            Return pPropTable
        End Get
    End Property
    Private Sub UpdateTable() Handles Me.PropertyChanged
        If pIgnoreEvents Then Exit Sub 'This sub is called recursively.
        pIgnoreEvents = True
        ' Get a list of my properties
        ' Only string or boolean properties are accepted to reduce confusion
        Dim PropInfo As System.Reflection.PropertyInfo
        Dim PropInfoCollection() As System.Reflection.PropertyInfo = Me.GetType.GetProperties
        Dim PropName As String
        Dim PropValue As String

        Dim TheBool As Boolean = False
        Dim TheString As String = ""

        'For Each PropInfo In Params
        Dim txt As TextBox
        For i As Integer = 0 To PropInfoCollection.Length - 1
            PropInfo = PropInfoCollection(i)
            Try
                If PropInfo.PropertyType Is TheBool.GetType Then
                    PropName = PropInfo.Name
                    PropValue = PropInfo.GetValue(Me, Reflection.BindingFlags.GetProperty, Nothing, Nothing, Nothing)
                    'pPropTable.AddEnvironDataTableRow(Nam, PropValue)
                    UpdateTableField(PropName, PropValue)
                End If
                If PropInfo.PropertyType Is TheString.GetType Then
                    PropName = PropInfo.Name
                    PropValue = PropInfo.GetValue(Me, Reflection.BindingFlags.GetProperty, Nothing, Nothing, Nothing)
                    UpdateTableField(PropName, PropValue)
                End If
            Catch ex As Exception
                Stop
            End Try
        Next
        ' MsgBox(PropList.ToString)
        pIgnoreEvents = False
    End Sub
    Private Sub UpdateTableField(FieldName As String, FieldValue As String)
        ' Add Valu to Nam line. Add new line if necessary
        If FieldValue Is Nothing Then Exit Sub
        Dim Row As dsetTestGeneric.EnviornmentDataTableRow = Nothing
        For Each Row In pPropTable
            If Row.FieldName = FieldName Then
                Exit For
            Else
                Row = Nothing
            End If
        Next
        If Not Row Is Nothing Then
            ' Change value in existing row
            Row.FieldValue = FieldValue
        Else
            pPropTable.AddEnviornmentDataTableRow(FieldName, FieldValue)
        End If

    End Sub
    Public Property DSNE As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.DSNE)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.DSNE, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property DSNT As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.DSNT)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.DSNT, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property IsLoggedIn As Boolean
        Get
            Dim Valu As Object '= Environ(EnvironmentKeys.IsLoggedIn)
            Valu = Environment.GetEnvironmentVariable(EnvironmentKeys.IsLoggedIn)
            Return Valu = True.ToString.Trim.ToLower
        End Get
        Set(value As Boolean)
            Environment.SetEnvironmentVariable(EnvironmentKeys.IsLoggedIn, value.ToString)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property EmpID As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.EmpID)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.EmpID, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property EmpName As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.EmpName)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.EmpName, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property Batch As String
        Get
            Return Environ(EnvironmentKeys.Batch)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.Batch, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property Pod As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.Pod)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.Pod, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property System As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.System)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.System, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property TestClass As String
        Get
            Return Environment.GetEnvironmentVariable(EnvironmentKeys.TestClass)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.TestClass, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property Model As String
        Get
            Return Environ(EnvironmentKeys.Model)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.Model, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Public Property XmlStyleFile As String
        Get
            Return Environ(EnvironmentKeys.XmlStyleFle)
        End Get
        Set(value As String)
            Environment.SetEnvironmentVariable(EnvironmentKeys.XmlStyleFle, value)
            RaiseEvent PropertyChanged()
        End Set
    End Property
    Private pAdmin As Boolean
    Private pProgrammer As Boolean
    Private pTestEngin As Boolean
    Private ReworkOp As Boolean
    Private pOperat As Boolean

    Public Property APTRO As String
        Get
            Return Environ(EnvironmentKeys.APTRO)
        End Get
        Set(TheValue As String)
            ' Verify is string of 1's and 0's
            ' Raise error is not complient
            Try
                If TheValue.Length <> 5 Then
                    Throw New System.Exception("EnvironmentControl.APTRO.Set Invalid Length: " & TheValue)
                End If
            Catch ex As Exception
                Exit Property
            End Try
            Try
                Dim i As Integer
                Dim A, P, T, R, O As Boolean
                For i = 0 To 4
                    If TheValue.Substring(i, 1) <> "0" And TheValue.Substring(i, 1) <> "1" Then
                        Throw New System.Exception("EnvironmentControl.APTRO.Set Unexpected Character")
                    End If
                Next
                ' Write APTRO
                Environment.SetEnvironmentVariable(EnvironmentKeys.APTRO, TheValue)
                'Write the individual permission flags
                ' It is duplicate data, but may be useful for Test programs
                A = TheValue.Substring(0, 1) = "1"
                P = TheValue.Substring(1, 1) = "1"
                T = TheValue.Substring(2, 1) = "1"
                R = TheValue.Substring(3, 1) = "1"
                O = TheValue.Substring(4, 1) = "1"
                Environment.SetEnvironmentVariable(EnvironmentKeys.Permission_Admin, A.ToString)
                Environment.SetEnvironmentVariable(EnvironmentKeys.Permission_Programmer, P.ToString)
                Environment.SetEnvironmentVariable(EnvironmentKeys.Permission_TestEngineer, T.ToString)
                Environment.SetEnvironmentVariable(EnvironmentKeys.Permission_Rework, R.ToString)
                Environment.SetEnvironmentVariable(EnvironmentKeys.Permission_Operator, O.ToString)
                RaiseEvent PropertyChanged()
            Catch ex As Exception
                Utility.ErrorHandler_General(ex, True)
            End Try
        End Set
    End Property
    Public ReadOnly Property Permission_Admin As Boolean
        Get
            Return Environ(EnvironmentKeys.Permission_Admin).Trim.ToLower = True.ToString.ToLower
        End Get
    End Property
    Public ReadOnly Property Permission_Programmer As Boolean
        Get
            Return Environ(EnvironmentKeys.Permission_Programmer).Trim.ToLower = True.ToString.ToLower
        End Get
    End Property
    Public ReadOnly Property Permission_TestEngineer As Boolean
        Get
            Return Environ(EnvironmentKeys.Permission_TestEngineer).Trim.ToLower = True.ToString.ToLower
        End Get
    End Property
    Public ReadOnly Property Permission_Rework As Boolean
        Get
            Return Environ(EnvironmentKeys.Permission_Rework).Trim.ToLower = True.ToString.ToLower
        End Get
    End Property
    Public ReadOnly Property Permission_Operator As Boolean
        Get
            Return Environ(EnvironmentKeys.Permission_Operator).Trim.ToLower = True.ToString.ToLower
        End Get
    End Property

    Public Sub New()
        ' Lots of initializations to do
        With Me
            .APTRO = "11100"
            .DSNE = "DSNE"
            .DSNT = "SNST"
            .EmpID = "PL"
            .IsLoggedIn = False
            .Batch = "0"
            .System = My.Computer.Name
            .Pod = "B09xxx"
        End With
    End Sub


    Protected Structure EnvironmentKeys
        ' A structure to avoid problems with improperly named keys
        ' These environment variables are assigned
        '   Name                    Purpose
        '   DSNT                    Connection string to "TEST2" database
        '   DSNE                    Connection to EPICOR database
        '   IsLoggedIn              "True" if a user is currently logged in
        '   EmpID                   empid TheValue if logged in, "" otherwise
        '   EmpName                 EmployeeName if logged in, "" otherwise
        '   APTRO                   "00000" - "11111": User permission. "00000" if not logged in
        '  Permission_Admin         "True" or "False", as indicated in APTRO TheValue
        '  Permission_Programmer    "True" or "False", as indicated in APTRO TheValue
        '  Permission_TestEng       "True" or "False", as indicated in APTRO TheValue
        '  Permission_Rework        "True" or "False", as indicated in APTRO TheValue
        '  Permission_Operator        "True" or "False", as indicated in APTRO TheValue

        Public Shared Function Batch() As String
            Return "BATCH"
        End Function
        Public Shared Function Pod() As String
            Return "POD"
        End Function
        Public Shared Function System() As String
            Return "SYSTEM"
        End Function

        Public Shared Function DSNT() As String
            Return "DSNT"
        End Function
        Public Shared Function DSNE() As String
            Return "DSNE"
        End Function
        Public Shared Function IsLoggedIn() As String
            Return "IsLoggedIn"
        End Function
        Public Shared Function EmpID() As String
            Return "EmpID"
        End Function
        Public Shared Function EmpName() As String
            Return "EmpName"
        End Function
        Public Shared Function APTRO() As String
            Return "APTRO"
        End Function
        Public Shared Function Permission_Admin() As String
            Return "Permission_Admin"
        End Function
        Public Shared Function Permission_Programmer() As String
            Return "Permission_Programmer"
        End Function
        Public Shared Function Permission_TestEngineer() As String
            Return "Permission_TestEngineer"
        End Function
        Public Shared Function Permission_Rework() As String
            Return "Permission_Rework"
        End Function
        Public Shared Function Permission_Operator() As String
            Return "Permission_Operator"
        End Function
        Public Shared Function TestClass() As String
            Return "TestClass"
        End Function
        Public Shared Function Model() As String
            Return "Model"
        End Function
        Public Shared Function XmlStyleFle() As String
            Return "XMLStyleFile"
        End Function
    End Structure
End Class